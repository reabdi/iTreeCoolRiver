#include "InputMorphology.h"
#include <sstream>
Morphology::Morphology(Params* pm)
{
	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();
	totalCount = Discharge.size();

	std::ifstream readMorphology(CurrDir + "\\Morphology.dat");
	if (!readMorphology)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find Morphology.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "Morphology.dat could not be opened!" << std::endl;
		return;
	}


	fstream infile(CurrDir + "\\Morphology.dat");
	if (!infile.good()) {
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find Morphology.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "Cannot find Morphology.dat file" << std::endl;
		return;
	}
	std::cout << "Reading Morphology.dat file\n" << std::endl;

	std::string temp;
	int tempDummy = -1.0;
	
	double tempDistance = -99999;	// average velocity
	double tempArea = -99999;	    // Water depth in the section
	double tempWidth = -99999;       // cros sectional average
	double tempDepth = -99999;		// Stream width
	double tempDischarge = -99999;
	double tempRowNumber = -99999;
	double tempColNumber = -99999;
	double tempLongitude = -99999;
	double tempLatitude = -99999;
	double tempSlope = -99999;
	double tempZvalue = -99999;


	// getting the header line and the blank line out of the way
	//getline(readMorphology, temp);
	//getline(readVelocity, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	while (readMorphology.good())
	{
		getline(readMorphology, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			count.push_back(tempDummy);

			getline(readMorphology, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempDistance;
			Distance.push_back(tempDistance);

			getline(readMorphology, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> tempArea;
			Area.push_back(tempArea);

			getline(readMorphology, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> tempWidth;
			Width.push_back(tempWidth);

			getline(readMorphology, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> tempDepth;
			Depth.push_back(tempDepth);

			getline(readMorphology, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> tempDischarge;
			Discharge.push_back(tempDischarge);

			// for unsteady situation (Aug. 17)
			getline(readMorphology, temp, ',');
			std::istringstream temp10(temp);
			temp10 >> tempSlope;
			slope.push_back(tempSlope);

			getline(readMorphology, temp, ',');
			std::istringstream temp6(temp);
			temp6 >> tempRowNumber;
			RowNumber.push_back(tempRowNumber);

			getline(readMorphology, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> tempColNumber;
			ColNumber.push_back(tempColNumber);

			getline(readMorphology, temp, ',');
			std::istringstream temp8(temp);
			temp8 >> tempLongitude;
			Longitude.push_back(tempLongitude);

			getline(readMorphology, temp, ',');
			std::istringstream temp9(temp);
			temp9 >> tempLatitude;
			Latitude.push_back(tempLatitude);

			getline(readMorphology, temp, '\n');
			std::istringstream temp11(temp);
			temp11 >> tempZvalue;
			Z_value.push_back(tempZvalue);
		}
		else {
			getline(readMorphology, temp, '\n');
		}
	}
	totalCount = Discharge.size();
	readMorphology.close();

	std::cout << "Morphology.dat reading done\n" << std::endl;

}
