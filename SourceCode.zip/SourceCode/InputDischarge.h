#ifndef DISCHARGE_H
#define DISCHARGE_H
///////////////////////////////////////////////////////////////
//  Time.h - read shading variables from input file       //
//                                                           //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : May 2017
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <sstream>
#include "InputParams.h"


class Discharge {
private:
	std::vector<int> number;
	std::vector<double> dischargeDist;
	std::vector<double> dischargeValue1;


	int totalDischargeCount;
public:
	Discharge(Params* pm);
	~Discharge() {};

	double Qdistance(int i) { return dischargeDist[i]; }
	double Qdischarge1(int i) { return dischargeValue1[i]; }

	int get_Q_count() { return (totalDischargeCount - 1); }
};

#endif