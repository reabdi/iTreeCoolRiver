#include "InputDischarge.h"

Discharge::Discharge(Params* pm) {

	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();

	totalDischargeCount = dischargeValue1.size();

	std::ifstream readDischarge(CurrDir + "\\GW_Discharge.dat");
	if (!readDischarge)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find GW_Discharge.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "GW_Discharge.dat could not be opened!" << std::endl;
		//fileParseSuccess = false;
		return;
	}


	std::string temp;
	int tempDummy = -1.0;
	double tempDistanceQ = -99999;
	double tempDischarge = -99999;

	std::string startline;

	// getting the header line and the blank line out of the way
	// getline(readDischarge, temp);
	//getline(readWeather, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	while (readDischarge.good())
	{
		getline(readDischarge, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			number.push_back(tempDummy);
			getline(readDischarge, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempDistanceQ;
			dischargeDist.push_back(tempDistanceQ);
			getline(readDischarge, temp, '\n');
			std::istringstream temp2(temp);
			temp2 >> tempDischarge;
			dischargeValue1.push_back(tempDischarge);

		}
		else
		{
			getline(readDischarge, temp, '\n');
		}
	}
	totalDischargeCount = dischargeValue1.size();
	readDischarge.close();


}
