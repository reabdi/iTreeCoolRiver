#include "InputSteadyInflow.h"
#include <sstream>


SteadyInflow::SteadyInflow(Params* pm)
{
	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();
	totalCount = SteadyInflow_T1.size();

	std::ifstream readSteadyInflow(CurrDir + "\\SteadyInflow.dat");
	if (!readSteadyInflow)
	{
		std::cout << "SteadyInflow.dat could not be opened!" << std::endl;
		return;
	}

	std::string temp;
	int tempDummy = -1.0;

	double temp_inflowT_0 = -99999;
	double temp_inflowT_1 = -99999;
	double temp_inflowT_2 = -99999;
	double temp_inflowT_3 = -99999;
	double temp_inflowT_4 = -99999;
	double temp_inflowQ_0 = -99999;
	double temp_inflowQ_1 = -99999;
	double temp_inflowQ_2 = -99999;
	double temp_inflowQ_3 = -99999;
	double temp_inflowQ_4 = -99999;


	// reading in a CSV
	while (readSteadyInflow.good())
	{
		getline(readSteadyInflow, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			count.push_back(tempDummy);

			getline(readSteadyInflow, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> temp_inflowQ_0;
			SteadyInflow_Q0.push_back(temp_inflowQ_0);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> temp_inflowT_0;
			SteadyInflow_T0.push_back(temp_inflowT_0);
			
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> temp_inflowQ_1;
			SteadyInflow_Q1.push_back(temp_inflowQ_1);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> temp_inflowT_1;
			SteadyInflow_T1.push_back(temp_inflowT_1);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> temp_inflowQ_2;
			SteadyInflow_Q2.push_back(temp_inflowQ_2);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp6(temp);
			temp6 >> temp_inflowT_2;
			SteadyInflow_T2.push_back(temp_inflowT_2);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> temp_inflowQ_3;
			SteadyInflow_Q3.push_back(temp_inflowQ_3);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp8(temp);
			temp8 >> temp_inflowT_3;
			SteadyInflow_T3.push_back(temp_inflowT_3);
			getline(readSteadyInflow, temp, ',');
			std::istringstream temp9(temp);
			temp9 >> temp_inflowQ_4;
			SteadyInflow_Q4.push_back(temp_inflowQ_4);
			getline(readSteadyInflow, temp, '\n');
			std::istringstream temp10(temp);
			temp10 >> temp_inflowT_4;
			SteadyInflow_T4.push_back(temp_inflowT_4);

		}
		else {
			getline(readSteadyInflow, temp, '\n');
		}
	}
	totalCount = SteadyInflow_T1.size();
	readSteadyInflow.close();
}

