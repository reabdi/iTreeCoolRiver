#include "InputSolarData.h"


Solar::Solar(Params* pm)
{

	int StartDay = pm->get_starttime();
	int EndDay=pm->get_endtime();
	std::string currDir = pm->get_InputDir();
	int date =0;
	std::string HrMinSec;
	double tempDirSW=0;
	double tempDiffSW=0;
	double tempDownLW=0;
	double tempUpLW=0;
	double tempLatitude=0;
	std::string temphourAngle;
	std::string tempDecline;
	double ntemphourAngle=0.0;
	double ntempDecline=0.0;
	std::string temp;

	fstream infile(currDir+"\\SolarRadiation.dat");  
	if(!infile.good()){
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find SolarRadiation.dat file needed to run simulation.\n";
		logfile.close();
		std::cout<<"Cannot find SolarRadiation.dat file"<<std::endl;
		return;
	}
	std::cout<<"Reading SolarRadiation.dat file\n"<<std::endl; 

	// getting the header line and the blank line out of the way
	getline(infile, temp);
	bool insert = true;
	while (infile.good())
	{
		getline(infile, temp, ',');
		//std::cout << temp << " ";
		std::istringstream ss(temp);
		ss >> date;
		
		if (date <= EndDay && date >= StartDay)
		{

			getline(infile, temp, ',');
			//std::cout << temp << " ";
			std::istringstream time(temp);
			getline(infile, temp, ',');
			//std::cout << temp << " ";
			std::istringstream dirsw(temp);
			dirsw >> tempDirSW;
			//Added by Vamsi to avoid abnormal changes in DirSW value for consecutive time steps
			if (!DirSW.empty())
				if ((DirSW.back() - tempDirSW) > 250)
					tempDirSW = DirSW.back() - 250;
				else if ((DirSW.back() - tempDirSW) < -250.0)
					tempDirSW = DirSW.back() + 250;
			DirSW.push_back(tempDirSW);
			getline(infile, temp, '\n');
			//std::cout << temp << "\n";
			std::istringstream diffsw(temp);
			diffsw >> tempDiffSW;
			DiffSW.push_back(tempDiffSW);
			if (insert)
			{
				insert = false;
				DirSW.push_back(tempDirSW);
				DiffSW.push_back(tempDiffSW);
			}
		}
		else
		{
			getline(infile, temp);
		}
	}
	DirSW.push_back(tempDirSW);
	DiffSW.push_back(tempDiffSW);
	
	infile.close();
	std::cout<<"SolarRadiation.dat reading done\n"<<std::endl; 

	totalts=DirSW.size();
	
}





#ifdef TEST_INPUTSOLARDATA

void display(double data, std::string param)
{
	
		std::cout<<"\n"<<"param"<<": \t"<<data;

	
}

int main( int argc, char* argv[])
{
	cout << "\n  Testing Weather class "
          << "\n===================================\n";

	std::string Path="";
   
	if(argc>1)
	{
		for(int i = 1;i<argc;i++)
		Path.append(argv[i]);		
	}
	else
	{
    cout << "\n  please enter path on which to find iTreeTempConfig.xml file \n\n";
    return 1;
    } 
	
	
	Path.append("\\iTreeTempConfig.xml");
	Params pm(Path);
	WatershedData wshedData(pm);
   Solar sl(pm);
	double tair=sl.getCosAzimuth(5);	
	
	

}

#endif

