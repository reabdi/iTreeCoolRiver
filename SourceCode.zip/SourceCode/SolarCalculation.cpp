#include "SolarCalculation.h"

SolarCalculation::SolarCalculation(TemperatureInputs* input) :inp(input)
{
	SpaData = input->getSpData();
	pm = inp->getPM();
	startYear = pm->get_starttime();			// Reading the input files which have been read from the XML file
	int tempStartTime = startYear % 10000;
	startYear -= tempStartTime;
	startYear = startYear / 10000;

	int tempStartMonth = pm->get_starttime();
	int tempStartTime1 = tempStartMonth % 10000;
	int tempStartTime2 = tempStartMonth % 100;
	startMonth = (tempStartTime1 - tempStartTime2) / 100;

	startDay = pm->get_starttime();
	startDay = startDay % 100;

	latDeg = 0;
	latMin = 0;

	lngDeg = 0;
	lngMin = 0;

	Jday = 0;

	stdMeridian = pm->get_standardMeridian();
	SolarConst();
	DayOfYear();
	SolarDay();
}


/*void SolarCalculation::InitialCal()
{
startYear = pm->get_starttime();			// Reading the input files which have been read from the XML file
int tempStartTime = startYear % 10000;
startYear -= tempStartTime;

int tempStartMonth = pm->get_starttime();
int tempStartTime1 = tempStartMonth % 10000;
int tempStartTime2 = tempStartMonth % 100;
startMonth = tempStartTime1 - tempStartTime2;

//startDay = pm->get_starttime();
startDay = startDay % 100;

latDeg = SpaData->getyllcorner();
double fractpart, intpart;
fractpart = modf(latDeg, &intpart);
latDeg = intpart;
latMin = fractpart * 60;

lngDeg = SpaData->getxllcorner();
fractpart = modf(lngDeg, &intpart);
lngDeg = intpart;
lngMin = fractpart * 60;

stdMeridian = pm->get_standardMeridian();
}*/

/*****************************************************************************
Function name: SolarDay()

Purpose:	 This subroutine calculates daily solar values

Required:
int DayOfYear	  - day of year (January 1 is 1)
float Longitude        - site longitude (rad)
float Latitude         - site latitude (rad)
float StandardMeridian - longitude of time zone of standard meridian (rad)

Returns: void

Modifies:
float *NoonHour       - true solar noon (hr)
float *Declination    - solar Declination (rad)
float *HalfDayLength  - half-day length (hr)
float *Sunrise        - time of Sunrise (hr)
float *Sunset         - time of Sunset (hr)
float *TimeAdjustment - required adjustment to local time (hr)
float *SunEarthDist   - distance from sun to earth

Comments     : EXECUTE AT START OF EACH DAY
*****************************************************************************/
void SolarCalculation::SolarDay()
{
	float B;			/* coefficient for equation of time */
	float EqnOfTime;		/* adjustment for equation of time (min) */
	float LongitudeAdjust;	/* adjustment for longitude (min) */
	float CosineHalfDayLength;	/* cosine of the half-day length */
	float HalfDayLength;

	/* note need to check if day light savings time calculate adjustment for
	true solar time longitude adjustment add 4 min per degree away from
	StandardMeridian (4 min/degree * 180 degree/pi radian) */
	
	LongitudeAdjust = (MINPDEG * DEGPRAD) * (stdMeridian - Longitude);


	/* equation of time */
	B = (2.0 * PI * (Jday - 81)) / 364.;
	EqnOfTime = 9.87 * sin(2 * B) - 7.53 * cos(B) - 1.5 * sin(B);

	/* adjustment factor to convert local time to solar time
	solar time = local time + TimeAdjustment  */
	/* for example from GMT to the west coast of the us (PST) */
	/* is a -8 hour shift, i.e. PST = GMT-8 */
	TimeAdjustment = -(LongitudeAdjust + EqnOfTime) / MINPHOUR;


	/* solar Declinationation  */
	Declination = 0.4098 * sin(2 * PI * (284 + Jday) / DAYPYEAR);

	/* half-day length  */
	CosineHalfDayLength = -tan(Latitude) * tan(Declination);
	if (CosineHalfDayLength >= 1.0)
		HalfDayLength = PI;
	else
		HalfDayLength = acos(CosineHalfDayLength);

	/* convert HalfDayLength from radians to Hours
	1 radian = (180 deg / PI) * (1 hr / 15 degrees rotation) */
	HalfDayLength = HalfDayLength / RADPHOUR;

	/* solar time of Sunrise and Sunset  */
	Sunrise = NoonHour - HalfDayLength;
	Sunset = NoonHour + HalfDayLength;

	/* calculate the sun-earth distance */
	SunEarthDist = 1.0 + 0.033 * cos(RADPDEG * (360. * Jday / 365));
}


/*****************************************************************************
Function name: SolarHour()

Purpose: This subroutine calculates position of the sun as a function of
the time of day, the length of time the sun is above the horizon,
and the maximum radiation.

Required:
float Latitude		- site laditude (rad)
float LocalHour		- local time (hr)
float Dt			- length of current timestep (hr)
float NoonHour		- true solar noon (hr)
float Declination		- solar Declination (rad)
float Sunrise		- time of Sunrise (hr)
float Sunset		- time of Sunset (hr)
float TimeAdjustment	- required adjustment to convert local time
to solar time (hr)
float SunEarthDist          - distance from Sun to Earth

Returns: void

Modifies:
float SineSolarAltitude - sine of sun's SolarAltitude
int*DayLight	     - FALSE: measured solar radiation and the sun is
below the horizon.
TRUE: sun is above the horizon
float SolarTimeStep     - fraction of the timestep the sun is above the
horizon
float SunMax            - calculated solar radiation at the top of the
atmosphere (W/m^2)

Comments     : EXECUTE AT START OF EACH TIMESTEP
*****************************************************************************/
void SolarCalculation::SolarHour(int ts)
{

	//float SolarZenith;		/* sun zenith angle (rads) */
	float StartHour = 0;		/* currect Hour in solar time (hr) */
	float EndHour = 0;		/* mid-point of current solar Hour (hr) */
	float Hour;			/* angle of current "halfhr" from solar noon
						(rads) */

						/* NOTE THAT HERE Dt IS IN HOURS NOT IN SECONDS */

						/* all calculations based on hour, the solar corrected local time */
	float Dt = 1;				// The time step considered 1 hour

	float LocalHour = inp->getWeat()->getHour(ts);
	Hour = LocalHour + TimeAdjustment;

	//Hour = LocalHour + TimeAdjustment - stdMeridian;            //*******************************just test********

	if (Hour < 0)
		Hour += 24;
	if (Hour > 24)
		Hour -= 24;

	DayLight = FALSE;
	if ((Hour > Sunrise) && ((Hour - Dt) < Sunset))
		DayLight = TRUE;
		else {
			SolarAltitude = 0;
			SolarAzimuth = 0;
			 }
	if (DayLight == TRUE) {
		/* sun is above the horizon */

		if (Dt > 0.0) {
			/* compute average solar SolarAltitude over the timestep */
			StartHour = (Hour - Dt > Sunrise) ? Hour - Dt : Sunrise;
			EndHour = (Hour < Sunset) ? Hour : Sunset;

			/*  convert to radians  */
			StartHour = RADPHOUR * (StartHour - NoonHour);
			EndHour = RADPHOUR * (EndHour - NoonHour);
			SolarTimeStep = EndHour - StartHour;

			/*  determine the average geometry of the sun angle  */
			SineSolarAltitude = sin(Latitude) * sin(Declination)
				+ (cos(Latitude) * cos(Declination) * (sin(EndHour) - sin(StartHour))
					/ SolarTimeStep);
		}
		else {
			Hour = RADPHOUR * (Hour - NoonHour);
			SineSolarAltitude = sin(Latitude) * sin(Declination)
				+ (cos(Latitude) * cos(Declination) * cos(Hour));
		}

		SolarAltitude = asin(SineSolarAltitude);

		SolarZenith = PI / 2 - SolarAltitude;

		SolarAzimuth = ((sin(Latitude) * (SineSolarAltitude)-sin(Declination))
			/ (cos(Latitude) * sin(SolarZenith)));

		if (SolarAzimuth > 1.)
			SolarAzimuth = 1.;

		SolarAzimuth = acos(-(SolarAzimuth));

		if (Dt > 0.0) {
			if (fabs(EndHour) > fabs(StartHour)) {
				SolarAzimuth = 2 * PI - (SolarAzimuth);
			}
		}
		else {
			if (Hour > 0) {
				SolarAzimuth = 2 * PI - (SolarAzimuth);
			}
		}
		/*     printf("Solar Azimuth = %g\n", *SolarAzimuth*180./PI); */

		SunMax = SOLARCON * SunEarthDist * SineSolarAltitude;
	}



	// I used simplified methodology to calculate the dst, to get access the broaded version, we need to check the 
	// HFlux code's hflux_shortwave_refl routine. Reza
	int dst;
	if (startYear < 2007) {
		if ((startMonth >= 4) && (startMonth <= 11)) { dst = 1; }	// If the month is between April and October, true
		else { dst = 0; }				// If month is January, February, or December, false
	}
	else {
		if ((startMonth > 3) && (startMonth <= 11)) { dst = 1; }	// If the month is between April and October, true
		else { dst = 0; }	// If month is January, February, or December, false
	}
	double time_fract = LocalHour * (1.0 / 24.0);
	double t_dst;
	if (dst == 1) { t_dst = time_fract + 1.0 / 24.0; }
	else { t_dst = time_fract; }
 
	double t_gmt = t_dst + (-stdMeridian / 24);
	double A1 = round(startYear / 100.0);
	double B1 = 2 - A1 + round(A1 / 4.0);
	double t_jd = round(365.25*(startYear + 4716)) + round(30.6001*(startMonth + 1)) + startDay + B1 - 1524.5;
	double t_jdc = (t_jd + t_gmt - 2451545) / 36525;
	

	// Solar position relative to Earth
	double S = 21.448 - t_jdc*(46.815 + t_jdc*(0.00059 - (t_jdc*0.001813)));
	double O_ob_mean = 23 + ((26 + (S / 60)) / 60);
	double O_ob = O_ob_mean + 0.00256*cos(125.04 - 1934.136*t_jdc);
	double e_c = 0.016708634 - t_jdc*(0.000042037 + 0.0000001267*t_jdc);
	double o_as_mean = 357.52911 + t_jdc*(35999.05029 - 0.0001537*t_jdc);
	double tempVariable = floor((280.46646 + t_jdc*(36000.76983 + 0.0003032*t_jdc)) / 360.0);
	double o_ls_mean = (280.46646 + t_jdc*(36000.76983 + 0.0003032*t_jdc)) - (tempVariable * 360.0);

	double a = (o_as_mean * PI / 180);
	double b = sin(a);
	double c = sin(b * 2);
	double d = sin(c * 3);
	double O_cs = b *(1.914602 - t_jdc * (0.004817 + 0.000014*t_jdc)) + c*(0.019993 - 0.000101*t_jdc) + d*0.000289;
	double O_ls = o_ls_mean+ O_cs;
	double O_al = O_ls - 0.00569 - (0.00478*sin((125.04 - 1934.136*t_jdc)* PI / 180));
	double solar_dec = asin(sin(O_ob*PI / 180)*sin(O_al*PI / 180)) * 180 / PI;

	double A = pow((tan(O_ob * PI / 360)),2.0);
	double B = sin(2 * o_ls_mean * PI / 180);
	double C = sin(o_as_mean * PI / 180);
	double D = cos(2 * o_ls_mean * PI / 180);
	double E = sin(4 * o_ls_mean * PI / 180);
	double F = sin(2 * o_as_mean * PI / 180);

	double e_t = 4 * (A*B - 2 * e_c*C + 4 * e_c*A*C*D - 0.5*pow(A , 2.0)*E - (4.0 / 3.0)*pow(e_c,2.0) * F)*(180 / PI);
	double h = LocalHour;
	double roundLong = -15 * round(lngDeg / 15);
	double t_s = (h * 60) + 4 * (roundLong + lngDeg) + e_t;
	double o_ha = (t_s / 4 - 180) * PI / 180;
	double m = sin(Latitude) * sin(solar_dec*(PI / 180)) + (cos(Latitude) * cos(solar_dec*(PI/180)) * cos(o_ha));
	SolarZenithHFlux = acos(m);

	SolAzimuth.push_back(SolarAzimuth);
	SolAltitude.push_back(SolarAltitude);
	SolZenith.push_back(SolarZenithHFlux);
}

/*****************************************************************************
Function name: SolarConst()

Purpose      : this subroutine reads in site data, calculates constants,
and converts data from degrees to radians.

Required     :
float lat_deg           - latitude of site in degrees
float lat_min           - latitude of site in minutes
float lng_deg           - longitude of site in degrees
float lng_min           - longitude of site in minutes
float StandardMeridian - standard meridian for local time zone in
degrees

Returns      : void

Modifies     :
float Latitude         - latitude of site in radians
float Longitude        - longitude of site in radians
float StandardMeridian - standard meridian for local time zone (rads)

Comments     : EXECUTE ONCE BEFORE TIME LOOP
*****************************************************************************/
//void SolarCalculation::SolarConst(float lat_deg, float lat_min, float lng_deg, float lng_min)
void SolarCalculation::SolarConst()
{
	latDeg = pm->get_tar_lat();

	lngDeg = pm->get_tar_long();

	Latitude = (latDeg)* PI / 180.;
	Longitude = (lngDeg)* PI / 180.;

}

// Using the methodology in Calender.c file of the MHSVM model
/*****************************************************************************
DayOfYear()
*****************************************************************************/
int SolarCalculation::DayOfYear()
{
	int i;

	int DaysPerMonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	// To read the year, month and day of the start day fro the XML file:
	int Year = startYear;
	int Month = startMonth;
	int Day = startDay;

	if (IsLeapYear(Year))
		DaysPerMonth[1] = 29;
	else
		DaysPerMonth[1] = 28;

	for (i = 0, Jday = 0; i < (Month - 1); i++)
		Jday += DaysPerMonth[i];

	Jday += Day;

	return Jday;
}

/*****************************************************************************
IsLeapYear()
*****************************************************************************/
char SolarCalculation::IsLeapYear(int Year)
{
	Year = startYear;
	if ((Year % 4 == 0 && Year % 100 != 0) || Year % 400 == 0)
		return TRUE;
	return FALSE;
}

