#ifndef SHADINGPERCENTAGE_H
#define SHADINGPERCENTAGE_H
///////////////////////////////////////////////////////////////
//  SHADINGPERCENTAGE.h - read shading variables             //
//                                                           //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : June 2017
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Shading class declarations                          //
///////////////////////////////////////////////////////////////

class ShadingPercentage
{

private:
	vector<int> number;
	vector<double> distance;
	vector<double> SF;
	vector<double> SkyView;
	
	int totalShadingCount;

public:
	ShadingPercentage(Params* pm);
	~ShadingPercentage() {};

	int getNumber(int i) { return number[i]; }
	double getDistance(int i) { return distance[i]; }
	double getSF(int i) { return SF[i]; }
	double getSkyView(int i) { return SkyView[i]; }


	int getTotalShadingData() { return (totalShadingCount - 2); }

};

#endif
