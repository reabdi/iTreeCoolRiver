#ifndef TIME_H
#define TIME_H
///////////////////////////////////////////////////////////////
//  Time.h - read shading variables from input file       //
//                                                           //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : May 2017
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//               class declarations                          //
///////////////////////////////////////////////////////////////

class Time
{

private:
	std::vector<int> count;
	std::vector<double> TimeMin;

	int totalts;


public:
	Time(Params* pm);
	~Time() {};

	double getTime(int i) { return TimeMin[i]; }
	double getTotalTimeMin() { return (totalts - 2); }
};


#endif

