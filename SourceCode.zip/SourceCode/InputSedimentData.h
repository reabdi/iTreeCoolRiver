#ifndef SEDIMENT_H
#define SEDIMENT_H
///////////////////////////////////////////////////////////////
//  SEDIMENT.h - read shading variables from input file       //
//                                                           //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : May 2017
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Shading class declarations                          //
///////////////////////////////////////////////////////////////

class Sediment
{

private:
	vector<int> number;
	vector<double> distance;
	vector<double> depthOfMeas;
	vector<double> tEnd_temperature;
	vector<double> conductivity;
	vector<double> particleSize;
	vector<double> embeddedness;

	std::vector<std::string> sedType;

	int totalBedCount;

public:
	Sediment(Params* pm);
	~Sediment() {};

	int getNumber(int i) { return number[i]; }
	double getDistance(int i) { return distance[i]; }
	double getDepthOfMeas(int i) { return depthOfMeas[i]; }
	double getTn_bed(int i) { return tEnd_temperature[i]; }
	double getConductivity(int i) { return conductivity[i]; }
	double getParticleSize(int i) { return particleSize[i]; }
	double getEmbeddedness(int i) { return embeddedness[i]; }

	std::string getBedType(int i) { return sedType[i]; }

	int getTotalBedData() { return (totalBedCount - 2); }

};

#endif