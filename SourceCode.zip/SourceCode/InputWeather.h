#ifndef WEATHER_H
#define WEATHER_H
///////////////////////////////////////////////////////////////
//  WEATHER.h - read weather variables from airport weather  //
//              station record                               //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2010 Visual studio C++                     //
//  Application:  iTree-Temperature                          //
//  Author:       Yang Yang,  SUNY-ESF & USDA FS             //
//                yyang31@syr.edu                            //
///////////////////////////////////////////////////////////////
/*
    Module Operations:
	==================
    
      Maintenance History:
      ====================
      ver 1.0 : Sep 2013
        - first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Weather class declarations                            //
///////////////////////////////////////////////////////////////

class Weather
{

	private:	
		std::vector<int> date;
		std::vector<int> hour;
		std::vector<double> WindSp;                        
		std::vector<double> Tair;
		// added by Reza for testing the Dr. Lautz's work
		std::vector<double> Cloadiness;
		std::vector<double> Humidity;
		std::vector<double>	obsT_xo;
		std::vector<double> sedT;


		int totalts;


    public:
		Weather(Params* pm);
		~Weather(){};
	 
		double getWindSp(int i) {return WindSp[i];}
		double getTair(int i){return Tair[i];}
		int gettotalts(){return (totalts - 1);}
		int getTS() { return totalts; }
		int getHour(int i){return hour[i];}
		int getDate(int i) { return date[i]; }

		// added by Reza for testing the Dr. Lautz's work
		double getCloadiness(int i) { return Cloadiness[i]; }
		double getHumidity(int i) { return Humidity[i]; }
		double getObsT_x0(int i) { return obsT_xo[i]; }
		double getSedT(int i) { return sedT[i]; }
	
};


#endif