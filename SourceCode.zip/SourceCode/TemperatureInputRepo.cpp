#include "TemperatureInputRepo.h"

TemperatureInputs::TemperatureInputs(std::string XmlFilename)
{
	pm = new Params(XmlFilename);
	S = new Solar(pm);
	weat = new Weather(pm);
	SpData = new SpatialData(pm);
	//Added by Reza Abdi (Nov.16):
	shade = new Shading(pm);
	//Added by Reza Abdi (Apr.17):
	mor = new Morphology(pm);
	//Added by Reza Abdi (May 17):
	tim = new Time(pm);
	dis = new Discharge(pm);
	sed = new Sediment(pm);
	SP = new ShadingPercentage(pm);

	inf = new Inflow(pm);
	// Added by Reza Abdi (Dec. 17) for the updated version of the mdoel - HecRas inputs
	hr = new HecRas(pm);
	//si = new SteadyInflow(pm);

}