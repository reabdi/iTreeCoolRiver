#ifndef HECRAS_H
#define HECRAS_H
///////////////////////////////////////////////////////////////
//  HecRas.h - read HecRas outputs from the input file       //
//               for the section we want to run the code     //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2017 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reza.abdi85@gmail.com                      //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : Dec 2016
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       HecRas class declarations                           //
///////////////////////////////////////////////////////////////

class HecRas
{
private:
	std::vector<int> count;

	std::vector<double> dist;
	std::vector<double> totalQ;
	std::vector<double> chElev;
	std::vector<double> waterSurElev;
	std::vector<double> velChnl;
	std::vector<double> xArea;
	std::vector<double> topWidth;
	std::vector<double> waterSurSlope;
	std::vector<double> wettedPerimeter;

	int totalCount;

public:
	HecRas(Params* pm);
	~HecRas() {};

	double getDist(int i) { return dist[i]; }
	double getTotalQ(int i) { return totalQ[i]; }
	double getChElev(int i) { return chElev[i]; }
	double getWaterSurElev(int i) { return waterSurElev[i]; }
	double getVelChnl(int i) { return velChnl[i]; }
	double getXArea(int i) { return xArea[i]; }
	double getTopWidth(int i) { return topWidth[i]; }
	double getWaterSurSlope(int i) { return waterSurSlope[i]; }
	double getWettedPerimeter(int i) { return wettedPerimeter[i]; }


	int getCount() { return (totalCount - 2); }

};

#endif

