#include "InputShadingPercentage.h"
#include <sstream>
ShadingPercentage::ShadingPercentage(Params* pm) {

	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();

	totalShadingCount = SF.size();

	std::ifstream readShadingPercentage(CurrDir + "\\ShadingPercent.dat");
	if (!readShadingPercentage)
	{
		std::cout << "ShadingPercent.dat could not be opened!" << std::endl;
		//fileParseSuccess = false;
		return;
	}


	std::string temp;
	int tempDummy = -1.0;
	double tempDistance = -99999;
	double tempSF = -99999;
	double tempSkyView = -99999;

	std::string startline;

	// getting the header line and the blank line out of the way
	// getline(readBedData, temp);
	// getline(readWeather, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	while (readShadingPercentage.good())
	{
		getline(readShadingPercentage, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			number.push_back(tempDummy);
			getline(readShadingPercentage, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempDistance;
			distance.push_back(tempDistance);

			getline(readShadingPercentage, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> tempSF;
			SF.push_back(tempSF);

			getline(readShadingPercentage, temp, '\n');
			std::istringstream temp5(temp);
			temp5 >> tempSkyView;
			SkyView.push_back(tempSkyView);
		}
		else
		{
			getline(readShadingPercentage, temp, '\n');
		}
	}
	totalShadingCount = SF.size();
	readShadingPercentage.close();


}