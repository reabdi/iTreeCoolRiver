#ifndef STEADYINFLOW_H
#define STEADYINFLOW_H
///////////////////////////////////////////////////////////////
//  SteadyInflow.h - read steady inflows from the input file //
//               for the section we want to run the code     //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2017 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reza.abadi85@gmail.com                     //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : Dec 2016
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       SteadyInflow class declarations                     //
///////////////////////////////////////////////////////////////

class SteadyInflow
{
private:
	std::vector<int> count;
	std::vector<double> SteadyInflow_Q0;
	std::vector<double> SteadyInflow_T0;
	std::vector<double> SteadyInflow_Q1;
	std::vector<double> SteadyInflow_Q2;
	std::vector<double> SteadyInflow_Q3;
	std::vector<double> SteadyInflow_Q4;
	std::vector<double> SteadyInflow_T1;
	std::vector<double> SteadyInflow_T2;
	std::vector<double> SteadyInflow_T3;
	std::vector<double> SteadyInflow_T4;


	int totalCount;

public:
	SteadyInflow(Params* pm);
	~SteadyInflow() {};


	double getInflowT0_HR(int i) { return SteadyInflow_T0[i]; }
	double getInflowT1_HR(int i) { return SteadyInflow_T1[i]; }
	double getInflowT2_HR(int i) { return SteadyInflow_T2[i]; }
	double getInflowT3_HR(int i) { return SteadyInflow_T3[i]; }
	double getInflowT4_HR(int i) { return SteadyInflow_T4[i]; }
	double getInflowQ0_HR(int i) { return SteadyInflow_Q0[i]; }
	double getInflowQ1_HR(int i) { return SteadyInflow_Q1[i]; }
	double getInflowQ2_HR(int i) { return SteadyInflow_Q2[i]; }
	double getInflowQ3_HR(int i) { return SteadyInflow_Q3[i]; }
	double getInflowQ4_HR(int i) { return SteadyInflow_Q4[i]; }



	int getCount_HR() { return (totalCount - 2); }

};

#endif

