//////////////////////////////////////////////////////////////////////////	
//  TemperaturePrime.h - performs temperature modeling analysis         //
//
//  Language:     2013 Visual studio C++								//
//  Application:  iTreeHydro											//
//  Author:       Yang Yang,  SUNY-ESF & USDA FS, yyang31@syr.edu		//
//				  Pallavi Iyengar, piyengar@syr.edu						//
/////////////////////////////////////////////////////////////////////////
/*

Module Operations:
==================
ConfigureHydro class -concept based on Dr. Jim Fawcett's Parser class see
http://www.lcs.syr.edu/faculty/fawcett/handouts/CSE687/code/Parser/

The class contains a set of temperate/hydrological processes/operations/calculations. 
For each step in a time series, it orchestrates their execution on a grid of topographical indices/cells.

***** NOTE ******

The output is written out after each cell and timestep processing. 

The class makes sure that each of the cells hold values of only the current and previous timestep,
by deleting the timestep values older than the previous one.

Public Interface:
=================

Temperature(TemperatureRepo *repo, TemperatureInputs *input, TemperatureOutputWriter *writer);
virtual void run(int timeSteps, int numberOfCells);

Build Process:
==============
Required files
- TemperaturePrime.cpp, IProcess.h, TemperatureInputRepo.h, TemperatureOutputRepo.h, IOuputWriter.h, TemperatureOutputWriter.h
Build commands
- devenv hydroprime.sln

Maintenance History:
====================
ver 1.0 : Aug 2012
- first release

====================
ver 2.0 : May 2015
- second release
- Integration with iTree Hydro

*/

#pragma once

#include "TemperatureInputRepo.h"
#include "InputParams.h"			// Added by Reza Abdi (Jun. 17)

/*
Contains the equivalent implementation of HydroHeatSimulation::HydroHeatSimulation() of the Temperature Module.
The output is written out after each call and timestep processing.
Also, the class makes sure that the cells hold only values of the current and previous timestep.
*/

class Temperature 
{
public:
	Temperature() {};
	~Temperature() {};

	Temperature(TemperatureInputs *input) : inp(input) {}
	void run();

private:

	void twoDwriter(int sizeX, int sizeY, vector<vector<double>>& vector, string title, string OutputDir);
	int totalTimesteps;
	TemperatureInputs* inp;
};

