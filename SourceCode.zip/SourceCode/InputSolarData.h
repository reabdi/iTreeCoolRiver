#ifndef INPUTSOLAR_H
#define INPUTSOLAR_H
///////////////////////////////////////////////////////////////
//  SOLAR.h - read in solar data and calculate the angles    //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2010 Visual studio C++                     //
//  Application:  iTree-Temperature                          //
//  Author:       Yang Yang,  SUNY-ESF & USDA FS             //
//                yyang31@syr.edu                            //
///////////////////////////////////////////////////////////////
/*
    Module Operations:
	==================
    
      Maintenance History:
      ====================
      ver 1.0 :Aug 2013
        - first release

*/


/* partial of SolarRadiation.txt, the angles are in Radian
yyyymmdd      Hr:Min:Sec  DirSW(W/m^2)  DiffSW(W/m^2)  DownLW(W/m^2) UpLW(W/m^2)    Latitude   hourAngle  Decline
20100101      00:00:00      0.00          0.00          303.68        303.68        0.7513        -3.1343       -0.4024
20100101      01:00:00      0.00          0.00          303.68        303.68        0.7513        -2.8725       -0.4024
20100101      02:00:00      0.00          0.00          303.68        303.68        0.7513        -2.6107       -0.4024
20100101      03:00:00      0.00          0.00          303.68        303.68        0.7513        -2.3489       -0.4024
20100101      04:00:00      0.00          0.00          300.94        300.94        0.7513        -2.0871       -0.4024
20100101      05:00:00      0.00          0.00          301.22        301.22        0.7513        -1.8253       -0.4024
20100101      06:00:00      0.00          0.00          301.22        301.22        0.7513        -1.5635       -0.4024
20100101      07:00:00      0.00          0.00          301.22        301.22        0.7513        -1.3017       -0.4024
20100101      08:00:00      0.00          19.05         298.49        298.49        0.7513        -1.0399       -0.4024
20100101      09:00:00      0.00          47.93         298.76        298.76        0.7513        -0.7781       -0.4024
20100101      10:00:00      0.00          85.83         298.76        298.76        0.7513        -0.5163       -0.4024
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <sys/stat.h>
#include "InputParams.h"

///////////////////////////////////////////////////////////////
//      Solar class declarations                            //
///////////////////////////////////////////////////////////////


class Solar
{

	private:
		//DirSW(W / m ^ 2), DiffSW(W / m ^ 2)
		vector<double> DirSW;   //incoming direct short wave radiation  W/m^2, which is not corrected by any angle, so it may have values for 24hour
		vector<double> DiffSW;  //incoming diffuse short wave radiation  W/m^2

	int totalts;


    public:
		Solar(Params* pm);
		~Solar(){};
	
        double getDirSW(int i) {return DirSW[i];}
		double getDiffSW(int i){return DiffSW[i];}
		int gettotalts(){return totalts;}
		

	
};


#endif