#pragma once
///////////////////////////////////////////////////////////////
//  InputRepo.h - Class to take charge of all the inputs     //
//                                                           //
//  Language:     2010 Visual studio C++                     //
//  Platform:     DELL                                       //
//  Application:  iTree-Temperature                           //
//  Author:       Yang Yang,  SUNY-ESF & USDA FS             //
//                yyang31@syr.edu                            //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 :  Feb 2014
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <stdio.h>
#include "InputParams.h"
#include "InputSolarData.h"
#include "InputWeather.h"
#include "InputSpatialData.h"
#include "InputShadingInfo.h"    // Added by Reza Abdi (Nov.16) 
#include "InputMorphology.h"		 // Added by Reza Abdi (Apr. 17)
#include "InputTime.h"				// Added by Reza (May 17)
#include "InputDischarge.h"
#include "InputSedimentData.h"
#include "InputShadingPercentage.h"
#include "inputInflow.h"			// Added by Reza (Aug. 17)
#include "InputHecRas.h"			// Added by Reza for applying the input files of the HecRas run for the updated version of the model (Jan. 18)
#include "InputSteadyInflow.h"

///////////////////////////////////////////////////////////////
//    InputRepo class declarations                           //
///////////////////////////////////////////////////////////////

class TemperatureInputs
{

public:

	Params* pm;
	Solar* S;
	//RefWeather* RW;
	Weather* weat;
	SpatialData* SpData;
	//Added by Reza Abdi (Nov.16):
	Shading* shade;
	//Added by Reza Abdi (Dec.16):
	Morphology* mor;

	//Added by Reza Abdi (May 17):
	Time* tim;
	Discharge* dis;
	Sediment* sed;

	ShadingPercentage* SP;

	Inflow* inf;
	//Added by Reza Abdi (Jan. 18)
	HecRas* hr;
	SteadyInflow* si;

	TemperatureInputs(std::string XmlFilename);
	~TemperatureInputs()
	{
		delete pm;
		delete S;
		//RefWeather* RW;
		delete weat;
		delete SpData;
		//Added by Reza Abdi (Nov.16):
		delete shade;
		//Added by Reza Abdi (Dec.16):
		delete mor;

		//Added by Reza Abdi (May 17):
		delete tim;
		delete dis;
		delete sed;

		delete SP;

		delete inf;
		delete hr;
		delete si;
	
	};
	Params* getPM(){ return pm; }
	Solar* getS(){
		return S;
	}
	Weather* getWeat(){
		return weat;
	}
	SpatialData* getSpData(){
		return SpData;
	}
	//Added by Reza Abdi (Nov.16):
	Shading* getShade() {
		return shade;
	}
	//Added by Reza Abdi (Dec.16):
	Morphology* getMor() {
		return mor;
	}

	Time* getT() {
		return tim;
	}

	Discharge* getDis() {
		return dis;
	}
	Sediment* getSed() {
		return sed;
	}
	ShadingPercentage* getSP() {
		return SP;
	}
	Inflow* getInf() {
		return inf;
	}

	//Added by Reza Abdi (Jan. 18)
	HecRas* getHecRas() { return hr; }
	SteadyInflow* getStdInf() { return si; }
};

