#include "InputHecRas.h"
#include <sstream>

HecRas::HecRas(Params* pm)
{
	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();
	totalCount = dist.size();

	fstream infile(CurrDir + "\\HecRasData.dat");
	if (!infile.good()) {
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find HecRasData.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "Cannot find HecRasData.dat file" << std::endl;
		return;
	}
	//std::cout << "Reading HecRasData.dat file\n" << std::endl;

	std::string temp;
	double tempDummy = -1.0;

	double temp_dist = -99999;
	double temp_totalQ = -99999;
	double temp_chElev = -99999;
	double temp_waterSurElev = -99999;
	double temp_velChnl = -99999;
	double temp_xArea = -99999;
	double temp_topWidth = -99999;
	double temp_waterSurSlope = -99999;
	double temp_wettedPerimeter = -99999;

	// getting the header line and the blank line out of the way
	getline(infile, temp);

	// reading in a CSV
	while (infile.good())
	{
		getline(infile, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			count.push_back(tempDummy);

			getline(infile, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> temp_dist;
			dist.push_back(temp_dist);
			getline(infile, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> temp_totalQ;
			totalQ.push_back(temp_totalQ);
			getline(infile, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> temp_chElev;
			chElev.push_back(temp_chElev);
			getline(infile, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> temp_waterSurElev;
			waterSurElev.push_back(temp_waterSurElev);
			getline(infile, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> temp_velChnl;
			velChnl.push_back(temp_velChnl);
			getline(infile, temp, ',');
			std::istringstream temp6(temp);
			temp6 >> temp_xArea;
			xArea.push_back(temp_xArea);
			getline(infile, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> temp_topWidth;
			topWidth.push_back(temp_topWidth);
			getline(infile, temp, ',');
			std::istringstream temp8(temp);
			temp8 >> temp_waterSurSlope;
			waterSurSlope.push_back(temp_waterSurSlope);
			getline(infile, temp, '\n');
			std::istringstream temp9(temp);
			temp9 >> temp_wettedPerimeter;
			wettedPerimeter.push_back(temp_wettedPerimeter);

		}
		else {
			getline(infile, temp, '\n');
		}
	}
	totalCount = dist.size();
	infile.close();
}

