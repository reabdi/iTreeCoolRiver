/////////////////////////////////////////////////////////////////////////////////////////////////
// Node.cpp  - Create a Node data type, to be used by trees. Implements Node.h.                 //
// version 1.4                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:         Basic Data Structure for building a XML Tree                           //
// Author:              Sanyam Chaudhary , with many ideas from Help_Node code                      //
//                      provided by Dr.Fawcett                                                 //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////


#include"Node.h"

//--------------------------------------------Constructors for class Node--------------------------------------------------------

Node::Node()
{
	this->NodeName = " No Node Name is set yet";
	this->Nodetype = " No Node type is set yet";
	this->isVisited() = false;
}

Node::Node(std::string NodeType, std::string NodeName)
{
	this->Nodetype = NodeType;
	this->NodeName = NodeName;
	this->isVisited() = false;
}

//-----------------------------Desttuctor of the Node, deletes the attached Children as well---------------------------------/

Node::~Node()
{
	for (int i = 0; i<this->CountChildren(); i++)
	{
		delete this->Children[i];
	}

}

//--------As N-Ary tree is traversed using a MARKING scheme, isVisited() is used to supply the bool value of visited----------

bool& Node::isVisited()
{
	return visited;
}


//-----------------------------------------------Finds the Next UnMarked Child in the Tree-------------------------------------


Node * Node::NextUnmarkedChild()
{
	vector<Node *>::iterator itr = Children.begin();
	int i = 0;
	while (itr != Children.end())
	{
		if (!(this->Children[i]->isVisited()))
		{
			return this->Children[i];
		}
		itr++;
		i++;
	}
	return 0;
}

//----------------------Set the NodeName, In Case of TextBody as nodetype, it gives text as NodeName-----------------------

void Node::setNodeName(string Name)
{
	this->NodeName = Name;
}

// -------------------------<returns the node name>-----------------------------------------------

string Node::getNodeName()
{
	return this->NodeName;
}

//---------<sets the Nodetype, passed as a string, among{Element, TextNode, PreProcessingInstruction, XMLComment} >-------------------------------
// NOTE : Nodeypes could have been made different classes with added functionality , or enum in the very least, but i realized it quite late in the project>


void Node::setNodetype(std::string Nodetype)
{
	(this->Nodetype) = Nodetype;
}

//-------------------------<returns the Nodetype>--------------------------------------------------

string Node::getNodetype()
{
	return this->Nodetype;
}

//-------------------------<Adds a Child>----------------------------------------------------------

void Node::AddChild(Node* Child)
{
	(this->Children).push_back(Child);
}

//------------------------returns the number of children a Node have>-------------------------------

int Node::CountChildren()
{
	return (this->Children).size();
}


//-----------------------<Adds the attributes, to a given Node>------------------------------------

void Node::AddAttributes(string Name, string Value)
{
	Attributes.push_back(std::make_pair(Name, Value));
}

//---------------------------<Display the attributes of a Node, used by Display Node below>--------

void Node::ShowAttributes()
{
	vector<pair<string, string>>::iterator current = this->Attributes.begin();
	while (current != this->Attributes.end())
	{
		cout << "Name: " << current->first << endl;
		cout << "Value: " << current->second << endl;
		current++;
	}
}

//---------------------------< Adds a text body to the Node, in case type is NodeType>-------------

void Node::AddTextBody(std::string textbody)
{
	(this->NodeName) = textbody;
}

//---------------------------< Displays the Node with all information>----------------------------
void Node::DisplayNode()
{
	if (this->getNodetype() != "Document")
	{

		cout << "Nodetype: " << this->getNodetype() << endl;
		cout << "NodeName: " << this->getNodeName() << endl;
		cout << "Number of Children: " << this->Children.size() << endl;
		cout << "Its Attributes " << endl;
		this->ShowAttributes();
		if (this->Nodetype == "TextBody")
		{
			cout << "TextBody: " << this->NodeName << endl;

		}
		cout << endl;
	}

}

//---------------------< returns a Node Pointer to the ith child>------------------------------------

Node * Node::GetChild(int i)
{
	if (i<this->CountChildren())
		return this->Children[i];
	else
		return 0;

}

//-------------<erases the child from the Children vector at specified position---------------------

bool Node::RemoveChild(int indexChild)
{
	vector<Node *>::iterator itr = this->Children.begin();
	itr += indexChild;
	if (indexChild<this->CountChildren())
	{
		this->Children.erase(itr);
		return true;
	}
	return false;

}
//-----------<returns the count of attributes>-------------------------------------------------

int Node::CountAttributes()
{
	return this->Attributes.size();
}

//-----------<returns the first child element with the tag name>-------------------------------------------------
Node* Node::getChildByTagName(string tagName)
{
	for (Node* child : Children)
	{
		if (child->NodeName == tagName)
		{
			return child;
		}
	}
	return nullptr;
}
//--------< Returns an attribute pair with specified index>-------------------------------------

pair<string, string>Node::GetAttributes(int index)
{
	vector<pair<string, string>>::iterator current = this->Attributes.begin();
	if (index<this->CountAttributes())
	{
		return Attributes[index];
	}

	pair<string, string> end;
	end.first = "end";
	end.second = "end";
	return end;

}


// test stub for Node 

#ifdef TEST_NODE

//-------------------------This is just the function which was made to TEST the connected nodes----
// ------------------------It does not have any ROLE in the project but testing connected nodes.

void WalkTree(Node * pParent)
{

	pParent->DisplayNode();
	for (int i = 0; i <= pParent->CountChildren(); i++)
	{
		pParent->isVisited() = true;
		Node * curr = pParent->NextUnmarkedChild();
		if (curr != 0)
		{
			WalkTree(curr);
		}
	}

}

void main() {
	cout << "================================" << endl;
	cout << "===== Testing Node Class =======" << endl << endl;
	Node * root = new Node;
	root->setNodetype("Element");
	root->AddAttributes("Lecture", "CSE687");
	root->AddTextBody("This is a test node");
	Node *child = new Node;
	child->setNodetype("Element");
	child->AddAttributes("Lecture", "CSE681");
	child->AddTextBody("This is a child test node");
	Node * child1 = new Node;
	child1->AddTextBody("This is the body of a Child1 node");
	child1->setNodetype("TextBody");
	Node* GrandChild1 = new Node;
	GrandChild1->setNodetype("TextBody");
	GrandChild1->AddTextBody("This is a grand child of child node");
	child->AddChild(GrandChild1);
	Node* GrandChild11 = new Node;
	GrandChild11->setNodetype("TextBody");
	GrandChild11->AddTextBody("This is a grand child of child1 Node");
	child1->AddChild(GrandChild11);
	root->AddChild(child);
	root->AddChild(child1);
	child.DisplayNode();
	root.DisplayNode();
}

#endif
