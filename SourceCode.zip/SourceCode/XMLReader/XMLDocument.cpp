#include "XMLDocument.h"



/////////////////////////////////////////////////////////////////////////////////////////////////
// XMLDocument.cpp  -   This module is the EXECUTIVE of the project and uses all other modules //                                             //
//                      to demonstrate the project requirement. Implements XMLDocument.h
// version 1.2                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:        Builds an XML tree from a string or a file and demonstrates req.       //                        //
// Author:              Sanyam Chaudhary                                                      //
//                                                                                             //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////

XMLDocument::XMLDocument(void)
{
}

XMLDocument::~XMLDocument(void)
{
}

//----------------------<Builds a tree for a given filename>---------------------------------------
Node * XMLDocument::Load(std::string filename)
{
	try
    {
      Toker toker(filename.c_str());
	 toker.setMode(Toker::xml);
      XmlParts parts(&toker);
	Document  = new Node("Document"," ");
	ScopeStack.push(Document);
  // parts.verbose();                 // uncomment to show token details
    while(parts.get())
	{
		  XMLDocument::CreateNode(ScopeStack.top(),parts);
	 }
    }

	catch(std::exception ex)
    {
      std::cout << "\n  " << ex.what() << "\n\n";
	 exit(1);
    }
	
	return Document;
}

Node * XMLDocument::ParseString(std::string filename)
{
	try
    {
      Toker toker(filename.c_str(),false);
	 toker.setMode(Toker::xml);
      XmlParts parts(&toker);
	Document  = new Node("Document"," ");
	ScopeStack.push(Document);
  // parts.verbose();                 // uncomment to show token details
    while(parts.get())
	{
		  XMLDocument::CreateNode(ScopeStack.top(),parts);
	 }
    }

	catch(std::exception ex)
    {
      std::cout << "\n  " << ex.what() << "\n\n";
	 exit(1);
    }
	
	return Document;
}

//----<This function is used to FORMAT comments and banners so as to be processed by web browsers>----------

std::string XMLDocument::ShowComment(XmlParts &parts)
{  string result; 
	for(int i=0; i<parts.length()-1;i++)
	{ 	if(parts[i]=="<")
	       result = result+parts[i]+parts[i+1];
	else if(parts[i]=="!"||parts[i]=="?"||parts[i]=="--")
		  result +=parts[i+1];
	else
            result = result +" "+parts[i+1];
	}
	return result;
}

//-----------------------------<Recursive function, create nodes using XmlParts>--------------------

void XMLDocument::CreateNode(Node * pParent, XmlParts parts)
{  try
  {
	if(parts[0]=="<")
	{	int i =1;
	    if(parts[i]=="!")
		{    Node * CommentNode = new Node("XmlComment",XMLDocument::ShowComment(parts));
			pParent->AddChild(CommentNode);
		}
		else if(parts[i]=="?")
		{    Node * PreProcessingInstruction = new Node("PreProcessingInstruction",XMLDocument::ShowComment(parts));
			pParent->AddChild(PreProcessingInstruction);
		}
		else if(parts[i]=="/")
		  ScopeStack.pop();
		else
		{	Node * Element = new Node;
			Element->setNodetype("Element");
			Element->setNodeName(parts[i]);
			if(parts[parts.length()-2]!="/")
			  ScopeStack.push(Element);
			i++;
			//if(parts[i]!=">")
			 while(i<parts.length() && parts[i]!=">")
			   {	Element->AddAttributes(parts[i],parts[i+2]);
				i+=3;
				if(i>=parts.length() || parts[i]==">" || parts[i]=="/")
					break;
			 }			
			pParent->AddChild(Element);
		}
	}
	else
	{	Node * textNode = new Node("TextNode",parts.show());
		pParent->AddChild(textNode);
	}
}
catch(std::exception e)
{
	cout<<e.what()<<endl;
	exit(1);
}
}

#ifdef TEST_XMLDOCUMENT

int main(int argc, char* argv[])
{ try{ string filename;
	  string XMLString = "<?xml version=\"1.0\" ?><!-- XML test case --><LectureNote Id=\"CSE681\" ><title id=\"Sanyam\">XML Example #1</title><reference><title>Programming Microsoft .Net</title><author>Jeff Prosise<note Company=\"Wintellect\"/></author><publisher>Microsoft Press</publisher><date>2002</date><page>608</page></reference><comment id = \"testId\">Description of PCDATA</comment></LectureNote>";
	  Tree t,tString;
	  XMLDocument doc;
	  Node * root = NULL;
	  Node * rootString = NULL;
	  if(argc < 2)
       {WinTools_Extracts::FileHandler fh;
	   string file = "../XmlDocument/input.xml";
	   filename=fh.getFullPath(file);
	   root=doc.Load(filename);
	   t.setRoot(root);
	   rootString=doc.ParseString(XMLString);
	   tString.setRoot(rootString);
	  }
	  else if(argv[1][0]=='<'||argv[1][1]=='<')
	  { for(int i=1; i<argc; ++i)
         {std::cout << "\n  Processing String " << argv[i];
          std::cout << "\n  " << std::string(16 + strlen(argv[i]),'-') << "\n\n";
          filename+=string(argv[i]);
         }
	   root=doc.ParseString(filename);
	   t.setRoot(root);
	  }	 
       else
       { for(int i=1; i<argc; ++i)
         {std::cout << "\n  Processing file " << argv[i];
          std::cout << "\n  " << std::string(16 + strlen(argv[i]),'-') << "\n\n";
          filename+=string(argv[i]);
	    }
		root=doc.Load(filename);
		t.setRoot(root);         
       }
	XmlWrite xw;
	cout<<endl<<"=====================Displaying the Tree====================================="<<endl<<endl;
	xw.Write(t.GetRoot());
	t.AddChild("testTag",t.GetElementById("testId"));
     cout<<endl<<"========Displaying the Tree after adding a TestTag, to parent with id testId"<<endl<<endl;
	xw.Write(t.GetRoot());
	t.RemoveElement("testTag");//also could have done t.Remove((t.GetElementByTagName("testTag")[0]));
	cout<<endl<<"=======Displaying the tree after deleting the just added child================="<<endl<<endl;
	xw.Write(t.GetRoot());
	cout<<endl<<"===Now writing the xml to a file named output.xml in my project directory==="<<endl;
	xw.WriteToFile(t.GetRoot());
	if(rootString!=NULL)
	{XmlWrite xw;
	cout<<endl<<endl<<"------------------Displaying the Tree using XMLSTRING------------------------"<<endl<<endl;
	xw.Write(tString.GetRoot());
	tString.AddChild("testTag",tString.GetElementById("testId"));
     cout<<endl<<"========Displaying the Tree after adding a TestTag, to parent with id testId"<<endl<<endl;
	xw.Write(tString.GetRoot());
	tString.RemoveElement("testTag");//also could have done t.Remove((t.GetElementByTagName("testTag")[0]));
	cout<<endl<<"=======Displaying the tree after deleting the just added child================="<<endl<<endl;
	xw.Write(tString.GetRoot());
	}	 
   }catch(std::exception e)
	{   cout<<e.what();
		exit(1);
	}
}

#endif

