#include "StreamTemperature.h"


StreamTemperature::StreamTemperature(TemperatureInputs *inp, SolarCalculation* solarCal) :inp(inp), solarCal(solarCal)
{
	pm = inp->getPM();
	SpaData = inp->getSpData();
	TI = new SlopeCal(inp);
}

void StreamTemperature::clear()
{
	solarSW_Dir_LI2D.clear();
	solarSW_Diff_LI2D.clear();
	aitTemp_LI2D.clear();
	rela_humidity_LI2D.clear();
	windSp_LI2D.clear();
	cloudiness_LI2D.clear();
	hourlyTime.clear();
	SWreflVec.clear();
	adjustedDirSW_E.clear();
	adjustedDirSW_W.clear();
	adjustedDiffSW_E.clear();
	adjustedDiffSW_W.clear();
	atmLW.clear();
	lcLW.clear();
	backLW.clear();
	latent.clear();
	sensible.clear();
	bed.clear();
	BankH_E_LI.clear();
	TreeH_E_LI.clear();
	BankH_W_LI.clear();
	TreeH_W_LI.clear();
	BuildH_E_LI.clear();
	BuildH_W_LI.clear();
	CanDist_E_LI.clear();
	CanDist_W_LI.clear();
	BanDist_E_LI.clear();
	BanDist_W_LI.clear();
	BuildDist_E_LI.clear();
	BuildDist_W_LI.clear();
	Buff_E_LI.clear();
	Buff_W_LI.clear();
	elev_LI.clear();
	StrAzimuth_LI.clear();
	colNum_Dist.clear();
	rowNum_Dist.clear();
	LongValue_Dist.clear();
	latValue_Dist.clear();
	SolAzimuth_LI.clear();
	SolAltitude_LI.clear();
	SF_LI.clear();
	SkyToView_LI.clear();
	secWidth_LI.clear();
	secDepth_LI.clear();
	secSlope_LI.clear();
	secArea_LI.clear();
	Z_LI.clear();
	heat_flux_2D.clear();
	SWDir_2D.clear();
	SWDiff_2D.clear();
	SW_2D.clear();
	LW_2D.clear();
	atmLW_2D.clear();
	LCLW_2D.clear();
	backLW_2D.clear();
	Latent_2D.clear();
	Sensible_2D.clear();
	Bed_2D.clear();
	T.clear();  // T: temperature array
	delete TI;

	fluxxx.clear();
	tNew.clear();
	////// added by Reza, Jun. 17
	//SkyV_E.clear();
	//SkyV_W.clear();
	//VSAEast.clear();
	//TSAEast.clear();
	//BSAEast.clear();
	//VSAWest.clear();
	//TSAWest.clear();
	//BSAWest.clear();

	////// ANALYSING THE ENTERIOR RESULTS AND VECTOR - REZA
	//a_c.clear();
	//b_c.clear();
	//c_c.clear();
	//o.clear();
	//p.clear();
	//q.clear();
	//o_c.clear();
	//p_c.clear();
	//q_c.clear();
	//d.clear();
	//g.clear();
	//k.clear();
	//m.clear();
	//a.clear();
	//b.clear();
	//c.clear();
	//depth_total.clear();
	//width_total.clear();
	//area_total.clear();
	//wp_total.clear();
	//ksed1.clear();
	//t_minBased.clear();

	//Q_half_min1.clear();
	//volume1.clear();
	//discharge_time1.clear();


	//A.clear();
	//x.clear();
	//b_copy.clear();



	//delta_t.clear();
	//S1.clear();
	//S2.clear();
	//SkyToView_UnsE.clear();
	//SkyToView_UnsW.clear();
	//SF_LI_Uns.clear();
	//SWreflVec_Uns.clear();
	//SolAzimuth_LI_Uns.clear();
	//SolAltitude_LI_Uns.clear();
	//Flag_SkipNode.clear();
	//Q.clear();
	//Temp_unsteady.clear();
	//depth_unsteady.clear();
	//AreaX.clear();
	//velocity_unsteady.clear();
	//inflow_Rate.clear();
	//inflow_Temp.clear();
	//Q_minBased.clear();
	//inflow_Q_2_min.clear();
	//inflow_Q_3_min.clear();
	//Tobs_minBased.clear();
	//inflow_temp_2_temp.clear();
	//inflow_temp_3_temp.clear();
	//width_unsteady.clear();
	//Pw_unsteady.clear();
	//Rh_unsteady.clear();
	//Z_unsteady.clear();
	//n_unsteady.clear();
	//s_unsteady.clear();
	//width_UnsTotal.clear();
	//discharge_Unsteady.clear();
	//Q_GW.clear();
	//Temp_GW.clear();
	//depth_AvgUns.clear();
	//Q_In.clear();
	//T_In.clear();
	//T_trib_shift.clear();
	//conductivity_Uns.clear();
	//particleSize_Uns.clear();
	//embeddedness_Uns.clear();
	//Hyporheic_Exchange.clear();
	//BedTn_LI_Uns.clear();
	//hyp_Slope_Uns.clear();
	//dispersion.clear();
	//T_unsTemporary.clear();

	Flux_Total.clear();
	Flux_Conduction.clear();
	Flux_Evaporation.clear();
	Flux_Convection.clear();
	FLux_AtmLW.clear();
	Flux_LCLW.clear();
	Flux_BackLW.clear();
	Flux_LW.clear();
	Flux_DirSW.clear();
	Flux_DiffSW.clear();
	Flux_SW.clear();
 
	depth_Uns.clear();

	hour_Flux_Total.clear();
	hour_Flux_Conduction.clear();
	hour_Flux_Evaporation.clear();
	hour_Flux_Convection.clear();
	hour_FLux_AtmLW.clear();
	hour_Flux_LCLW.clear();
	hour_Flux_BackLW.clear();
	hour_Flux_LW.clear();
	hour_Flux_DirSW.clear();
	hour_Flux_DiffSW.clear();
}

void StreamTemperature::AddLogComment(std::string comment)
{
	std::ofstream logfile("log.txt", ios::app);
	logfile << comment;
	logfile << "\n";
	logfile.close();
}

void StreamTemperature::skyViewE() {
	VSAEast.resize(TotalDist);
	TSAEast.resize(TotalDist);
	BSAEast.resize(TotalDist);
	SkyV_E.resize(TotalDist);
	// VSA in the calculations, Eq. #8 in Sun et al., (2015) the answer would be in radians
	for (int i = 0; i < TotalDist; i++) {
		// VSA in the calculations, Eq. #8 in Sun et al., (2015) the answer would be in radians
		double VSA_Temp;
		if (max(BanDist_E_LI[i], CanDist_E_LI[i]) == 0) { VSA_Temp = 0; }
		else {
			VSA_Temp = atan((BankH_E_LI[i] + TreeH_E_LI[i]) / max(BanDist_E_LI[i], CanDist_E_LI[i]));
		}
		VSAEast[i] = VSA_Temp;

		double TSA_Temp;
		if (min(BanDist_E_LI[i], CanDist_E_LI[i]) == 0) { TSA_Temp = 0; }
		else {
			TSA_Temp = atan(BankH_E_LI[i] / min(BanDist_E_LI[i], CanDist_E_LI[i]));
		}
		TSAEast[i] = TSA_Temp;

		double BSA_Temp;
		if (max(BanDist_E_LI[i], BuildDist_E_LI[i]) == 0) { BSA_Temp = 0; }
		else {
			BSA_Temp = atan((BankH_E_LI[i] + BuildH_E_LI[i]) / max(BanDist_E_LI[i], BuildDist_E_LI[i]));
		}
		BSAEast[i] = BSA_Temp;

		double MaxSky = maxValue(VSA_Temp, TSA_Temp, BSA_Temp);

		double Sky_Temp = (180 - (2 * MaxSky)) / 180;
		SkyV_E[i] = Sky_Temp;
	}

}

void StreamTemperature::skyViewW() {

	VSAWest.resize(TotalDist);
	TSAWest.resize(TotalDist);
	BSAWest.resize(TotalDist);
	SkyV_W.resize(TotalDist);
	// VSA in the calculations, Eq. #8 in Sun et al., (2015) the answer would be in radians
	for (int i = 0; i < TotalDist; i++) {
		// VSA in the calculations, Eq. #8 in Sun et al., (2015) the answer would be in radians
		double VSA_Temp;
		if (max(BanDist_W_LI[i], CanDist_W_LI[i]) == 0) { VSA_Temp = 0; }
		else {
			VSA_Temp = atan((BankH_W_LI[i] + TreeH_W_LI[i]) / max(BanDist_W_LI[i], CanDist_W_LI[i]));
		}
		VSAWest[i] = VSA_Temp;

		double TSA_Temp;
		if (min(BanDist_W_LI[i], CanDist_W_LI[i])) { TSA_Temp = 0; }
		else {
			TSA_Temp = atan(BankH_W_LI[i] / min(BanDist_W_LI[i], CanDist_W_LI[i]));
		}
		TSAWest[i] = TSA_Temp;

		double BSA_Temp;
		if (max(BanDist_W_LI[i], BuildDist_W_LI[i]) == 0) { BSA_Temp = 0; }
		else {
			BSA_Temp = atan((BankH_W_LI[i] + BuildH_W_LI[i]) / max(BanDist_W_LI[i], BuildDist_W_LI[i]));
		}
		BSAWest[i] = BSA_Temp;

		double MaxSky = maxValue(VSA_Temp, TSA_Temp, BSA_Temp);

		double Sky_Temp = (180 - (2 * MaxSky)) / 180;
		SkyV_W[i] = Sky_Temp;
	}

}

// Calculating the sky view factor adjusted by riparian vegetation buffer considering Eastern info
void StreamTemperature::netSolarDiffRadE(const vector<double> &SolDiffSW, int timeStep)
{
	adjustedDiffSW_E.clear();
	adjustedDiffSW_E.resize(TotalDist);
	switch (SolvingMethod)
	{
	case 1:
		// added by Reza for testing the Dr. Lautz's work: HFlux
		// I'diffuse in the calculations, Eq. #8 in Sun et al., 2015 for East side
		for (int i = 0; i < TotalDist; i++) {

			adjustedDiffSW_E[i] = SolDiffSW[timeStep] * SkyV_E[i] * (1 - SWreflVec[timeStep]);
		}
		break;

	case 2:
		// Using the fix coverage values
		for (int i = 0; i < TotalDist; i++) {

			adjustedDiffSW_E[i] = SolDiffSW[timeStep] * (1 - SF_LI[i]) * (1 - SWreflVec[timeStep]);
		}
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");
	}

}

// Calculating the sky view factor adjusted by riparian vegetation buffer considering Western info
void StreamTemperature::netSolarDiffRadW(const vector<double> &SolDiffSW, int timeStep)
{
	adjustedDiffSW_W.clear();
	adjustedDiffSW_W.resize(TotalDist);
	switch (SolvingMethod)
	{
	case 1:
		// added by Reza for testing the Dr. Lautz's work: HFlux
		// I'diffuse in the calculations, Eq. #8 in Sun et al., 2015 for East side
		for (int i = 0; i < TotalDist; i++) {

			adjustedDiffSW_W[i] = SolDiffSW[timeStep] * SkyV_W[i] * (1 - SWreflVec[timeStep]);
		}
		break;

	case 2:
		// Using the fix coverage values
		for (int i = 0; i < TotalDist; i++) {

			adjustedDiffSW_W[i] = SolDiffSW[timeStep] * (1 - SF_LI[i]) * (1 - SWreflVec[timeStep]);
		}
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");
	}

}


// Calculating the effective shading width for East side
double StreamTemperature::effectiveShadingE(const vector<double> &SolDirE, int dist, int ts)
{

	int col = colNum_Dist[dist] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row = rowNum_Dist[dist] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int totCols = SpaData->getcols();
	int index = row * totCols + col;

	slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
	aspect = TI->getAspect(index);

	double delta1;
	double delta2;
	double avgPath;
	double solarPhi;
	double shadowLengthE;
	double extinctCoeff;
	double effShadowLengthE;

	double Canbuffer = Buff_E_LI[dist];

	//Eq. #3 in Sun et al., (2015)
	if (SolAltitude_LI[ts] == 0) { shadowLengthE = 0; }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAEast[dist], BSAEast[dist], TSAEast[dist]);
		if (VSAEast[dist] == MaxSky) {
			shadowLengthE = (BankH_E_LI[dist] + TreeH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}
		else if (BSAEast[dist] == MaxSky) {
			shadowLengthE = (BankH_E_LI[dist] + BuildH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}
		else {
			shadowLengthE = (BankH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}
	}

	/* Now I am going to calculate the delta1 and delta2 to calcualte the amount of effective shading
	Eq. #4 & 5 in Sun et al., 2015*/

	if (SolAltitude_LI[ts] == 0) { delta1 = -(BankH_E_LI[dist] + secWidth_LI[dist]); }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAEast[dist], BSAEast[dist], TSAEast[dist]);
		if (VSAEast[dist] == MaxSky) {
			delta1 = ((BankH_E_LI[dist] + TreeH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_E_LI[dist] + secWidth_LI[dist]);
		}
		else if (BSAEast[dist] == MaxSky) {
			delta1 = ((BankH_E_LI[dist] + BuildH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_E_LI[dist] + secWidth_LI[dist]);
		}
		else {
			delta1 = (BankH_E_LI[dist] *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_E_LI[dist] + secWidth_LI[dist]);
		}
	}
	if (SolAltitude_LI[ts] == 0) { delta2 = -(secWidth_LI[dist]); }
	else
	{
		double MaxSky = maxValue(VSAEast[dist], BSAEast[dist], TSAEast[dist]);
		if (VSAEast[dist] == MaxSky) {
			delta2 = ((BankH_E_LI[dist] + TreeH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}
		else if (BSAEast[dist] == MaxSky) {
			delta2 = ((BankH_E_LI[dist] + BuildH_E_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}
		else {
			delta2 = (BankH_E_LI[dist] *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}

	}

	solarPhi = (cos(SolAltitude_LI[ts]) * fabs(sin(SolAzimuth_LI[ts] - StrAzimuth_LI[dist])));

	/* calculating the radiation extinction coefficient which is estimated as a function of LAI.
	Reference: http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract;  DeWalle (2010) */


	//Eq. #1 in Sun et al., (2015) and Sridhar et al. (2004)

	// The next two variables for calculating the extinction coefficient should be shortwave instead longwave based on the following paper
	double abovVegRadiation = SolDirE[ts] * (1 - SWreflVec[ts]) * ((sin(slope) * cos(SolAltitude_LI[ts]) * cos(SolAzimuth_LI[ts] -
		aspect)) + (cos(slope) * sin(SolAltitude_LI[ts])));

	double vegRadiation = SolDirE[ts] * (1 - SWreflVec[ts]);			// Direct shortwave radiation based on the Sridhar et al. 2004 ---> Eqn. 6 & 8

																		// Link address to Sridhar et al. (2004): 
																		//http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2004.tb01019.x/abstract
																		// Calculating the extinction coefficient based on (DeWalle, 2010 --> Eqn. 2)
																		// DeWalle (2010): http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract
	if (vegRadiation <= 0 || abovVegRadiation <= 0)
		extinctCoeff = 0;
	else
		extinctCoeff = -(log(abovVegRadiation / vegRadiation) / CanopyLAI);


	// caclulating the overhanging shade (like I3 in Ning Sun's work uisng following methodology:
	// http://ascelibrary.org/doi/abs/10.1061/%28ASCE%290733-9372%281998%29124%3A4%28304%29

	double overHangW_E = 0;
	double canDens = pm->get_can_dens();
	if (((0.1 * TreeH_E_LI[dist]) - CanDist_E_LI[dist]) < secWidth_LI[dist]) {
		overHangW_E = ((0.1 * TreeH_E_LI[dist]) - CanDist_E_LI[dist]) * canDens;
	}
	else {
		overHangW_E = secWidth_LI[dist] * canDens;
	}


	// calculating of the average path (Lavg) based on the table 1 of  Sun et al., (2015)
	// (1) No shade
	if (VSAEast[dist] > max(TSAEast[dist], BSAEast[dist])) {
		if ((delta1 <= 0.0) && (delta2 <= 0.0)) { avgPath = 0; }
		// (2) Partial shade, sun above buffer canopy
		else if ((delta1 <= 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * delta2) / solarPhi); }
		// (3) Partial shade, sun below buffer canopy
		else if ((delta1 <= 0.0) && (delta2 > Canbuffer)) { avgPath = ((0.5 * Canbuffer) / solarPhi); }
		// (4) Full shade, sun above buffer canopy
		else if ((delta1 > 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * (delta1 + delta2)) / solarPhi); }
		// (5) Full shade, sun partially below buffer canopy
		else if ((delta1 <= Canbuffer) && (delta2 > Canbuffer)) { avgPath = ((0.5 * (delta1 + Canbuffer)) / solarPhi); }
		// (6) Full shade, sun entirely below buffer canopy
		else if ((delta1 > Canbuffer) && (delta2 > Canbuffer)) { avgPath = (Canbuffer / solarPhi); }
		//Eq. #6 in Sun et al., (2015)
		// The shadow length as the initial value for shadow (Eq. #6 in Sun et al., 2015) for Eastern side
		if (shadowLengthE < CanDist_E_LI[dist]) { effShadowLengthE = 0; }
		else {
			effShadowLengthE = ((shadowLengthE - CanDist_E_LI[dist] - overHangW_E)
				* (1 - exp(-(extinctCoeff * avgPath))));
		}
	}
	else {
		if (shadowLengthE < BuildDist_E_LI[dist]) { effShadowLengthE = 0; }
		effShadowLengthE = shadowLengthE - BuildDist_E_LI[dist] - overHangW_E;
	}

	return effShadowLengthE;
}


// Calculating the effective shading width for West side
double StreamTemperature::effectiveShadingW(const vector<double> &SolDirW, int dist, int ts)
{

	int col = colNum_Dist[dist] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row = rowNum_Dist[dist] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int totCols = SpaData->getcols();
	int index = row * totCols + col;

	slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
	aspect = TI->getAspect(index);

	double delta1;
	double delta2;
	double avgPath;
	double solarPhi;
	double shadowLengthW;
	double extinctCoeff;
	double effShadowLengthW;

	double Canbuffer = Buff_W_LI[dist];

	//Eq. #3 in Sun et al., (2015)
	if (SolAltitude_LI[ts] == 0) { shadowLengthW = 0; }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAWest[dist], BSAWest[dist], TSAWest[dist]);
		if (VSAWest[dist] == MaxSky) {
			shadowLengthW = (BankH_W_LI[dist] + TreeH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}
		else if (BSAWest[dist] == MaxSky) {
			shadowLengthW = (BankH_W_LI[dist] + BuildH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}
		else {
			shadowLengthW = (BankH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]));
		}

	}

	/* Now I am going to calculate the delta1 and delta2 to calcualte the amount of effective shading
	Eq. #4 & 5 in Sun et al., 2015*/

	if (SolAltitude_LI[ts] == 0) { delta1 = -(BankH_W_LI[dist] + secWidth_LI[dist]); }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAWest[dist], BSAWest[dist], TSAWest[dist]);
		if (VSAWest[dist] == MaxSky) {
			delta1 = ((BankH_W_LI[dist] + TreeH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_W_LI[dist] + secWidth_LI[dist]);
		}
		else if (BSAWest[dist] == MaxSky) {
			delta1 = ((BankH_W_LI[dist] + BuildH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_W_LI[dist] + secWidth_LI[dist]);
		}
		else {
			delta1 = ((BankH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(BankH_W_LI[dist] + secWidth_LI[dist]);
		}

	}
	if (SolAltitude_LI[ts] == 0) { delta2 = -(secWidth_LI[dist]); }
	else
	{
		double MaxSky = maxValue(VSAWest[dist], BSAWest[dist], TSAWest[dist]);
		if (VSAWest[dist] == MaxSky) {
			delta2 = ((BankH_W_LI[dist] + TreeH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}
		else if (BSAWest[dist] == MaxSky) {
			delta2 = ((BankH_W_LI[dist] + BuildH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}
		else {
			delta2 = ((BankH_W_LI[dist]) *
				fabs(sin((SolAzimuth_LI[ts]) - StrAzimuth_LI[dist]) / tan(SolAltitude_LI[ts]))) -
				(secWidth_LI[dist]);
		}

	}

	solarPhi = (cos(SolAltitude_LI[ts]) * fabs(sin(SolAzimuth_LI[ts] - StrAzimuth_LI[dist])));


	/* calculating the radiation extinction coefficient which is estimated as a function of LAI.
	Reference: http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract;  DeWalle (2010) */


	//Eq. #1 in Sun et al., (2015) and Sridhar et al. (2004)

	// The next two variables for calculating the extinction coefficient should be shortwave instead longwave based on the following paper
	double abovVegRadiation = SolDirW[ts] * (1 - SWreflVec[ts]) * ((sin(slope) * cos(SolAltitude_LI[ts]) * cos(SolAzimuth_LI[ts] -
		aspect)) + (cos(slope) * sin(SolAltitude_LI[ts])));

	double vegRadiation = SolDirW[ts] * (1 - SWreflVec[ts]);			// Direct shortwave radiation based on the Sridhar et al. 2004 ---> Eqn. 6 & 8

																		// Link address to Sridhar et al. (2004): 
																		//http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2004.tb01019.x/abstract
																		// Calculating the extinction coefficient based on (DeWalle, 2010 --> Eqn. 2)
																		// DeWalle (2010): http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract
	if (vegRadiation <= 0 || abovVegRadiation <= 0)
		extinctCoeff = 0;
	else
		extinctCoeff = -(log(abovVegRadiation / vegRadiation) / CanopyLAI);


	// caclulating the overhanging shade (like I3 in Ning Sun's work uisng following methodology:
	// http://ascelibrary.org/doi/abs/10.1061/%28ASCE%290733-9372%281998%29124%3A4%28304%29

	double overHangW_W = 0;
	double canDens = pm->get_can_dens();
	if (((0.1 * TreeH_W_LI[dist]) - CanDist_W_LI[dist]) < secWidth_LI[dist]) {
		overHangW_W = ((0.1 * TreeH_W_LI[dist]) - CanDist_W_LI[dist]) * canDens;
	}
	else {
		overHangW_W = secWidth_LI[dist] * canDens;
	}


	// calculating of the average path (Lavg) based on the table 1 of  Sun et al., (2015)
	// (1) No shade
	if (VSAWest[dist] > max(TSAWest[dist], BSAWest[dist])) {
		if ((delta1 <= 0.0) && (delta2 <= 0.0)) { avgPath = 0; }
		// (2) Partial shade, sun above buffer canopy
		else if ((delta1 <= 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * delta2) / solarPhi); }
		// (3) Partial shade, sun below buffer canopy
		else if ((delta1 <= 0.0) && (delta2 > Canbuffer)) { avgPath = ((0.5 * Canbuffer) / solarPhi); }
		// (4) Full shade, sun above buffer canopy
		else if ((delta1 > 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * (delta1 + delta2)) / solarPhi); }
		// (5) Full shade, sun partially below buffer canopy
		else if ((delta1 <= Canbuffer) && (delta2 > Canbuffer)) { avgPath = ((0.5 * (delta1 + Canbuffer)) / solarPhi); }
		// (6) Full shade, sun entirely below buffer canopy
		else if ((delta1 > Canbuffer) && (delta2 > Canbuffer)) { avgPath = (Canbuffer / solarPhi); }
		//Eq. #6 in Sun et al., (2015)
		// The shadow length as the initial value for shadow (Eq. #6 in Sun et al., 2015) for Eastern side
		if (shadowLengthW < CanDist_W_LI[dist]) { effShadowLengthW = 0; }
		else {
			effShadowLengthW = ((shadowLengthW - CanDist_W_LI[dist] - overHangW_W)
				* (1 - exp(-(extinctCoeff * avgPath))));
		}
	}
	else {
		if (shadowLengthW < BuildDist_W_LI[dist]) { effShadowLengthW = 0; }
		effShadowLengthW = shadowLengthW - BuildDist_W_LI[dist] - overHangW_W;
	}

	return effShadowLengthW;
}

// Fresnel's Reflectivity
void StreamTemperature::solarReflectivity()
{
	double n = 1.333;
	//vector<double> solarZ(TotalTime / 60);
	vector<double> solarZ(TotalTime+1);		// USED FOR HOURLY BASED
	solarZ = solarCal->getSolZenith();

	//vector<double> SWreflVecTemp;
	//vector<double> SWreflVec_temp(TotalTime/60);
	SWreflVec.resize(TotalTime+1);
	for (int i = 0; i < (TotalTime+1); i++) {
		//solarZenith = solarCal->getSolZenith(i);
		double alpha_rad = solarZ[i];
		if (alpha_rad < PI / 2) {
			double beta_rad = asin(sin(double (alpha_rad / n)));
			double a = pow((tan(alpha_rad - beta_rad)), 2);
			double b = pow((tan(alpha_rad + beta_rad)), 2);
			double c = pow((sin(alpha_rad - beta_rad)), 2);
			double d = pow((sin(alpha_rad + beta_rad)), 2);
			double a_deg = a*(180 / PI);
			double b_deg = b*(180 / PI);
			double c_deg = c*(180 / PI);
			double d_deg = d*(180 / PI);
			SWrefl = 0.5*((a_deg / b_deg) + (c_deg / d_deg));
		}
		else {
			SWrefl = 1;
		}
		SWreflVec[i] = SWrefl;
	}
	

}

void StreamTemperature::adjustedDirRadE(const vector<double> &DirSW, int timeStep)
{

	/* calcluating the index for getAspect function to get access the desired cell of the domain. */
	int col;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int index;
	int totCols = SpaData->getcols();

	double effWidth;
	adjustedDirSW_E.clear();
	adjustedDirSW_E.resize(TotalDist);

	switch (SolvingMethod)
	{
	case 1:

		// matrix1 would be direct solar radiation
		adjustedDirSW_E.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {

			col = colNum_Dist[i] - 1;
			row = rowNum_Dist[i] - 1;
			index = row * totCols + col;
			slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
			aspect = TI->getAspect(index);

			double topoEffect = (sin(slope) * cos(SolAltitude_LI[timeStep]) * cos((SolAltitude_LI[timeStep]) - aspect)) +
				cos(slope) * sin(SolAltitude_LI[timeStep]);
			if (topoEffect < 0) { topoEffect = 0; }
			effWidth = effectiveShadingE(DirSW, i, timeStep);
			adjustedDirSW_E[i] = DirSW[timeStep] * (1 - SWreflVec[timeStep]) * topoEffect * (1 - (effWidth / secWidth_LI[i]));
			if (effWidth > secWidth_LI[i]) { adjustedDirSW_E[i] = 0; }
		}
		break;

	case 2:
		// matrix1 would be direct solar radiation
		adjustedDirSW_E.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			adjustedDirSW_E[i] = DirSW[timeStep] * (1 - SF_LI[i]) * (1 - SWreflVec[timeStep]);
		}
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");

	}



}

void StreamTemperature::adjustedDirRadW(const vector<double> &DirSW, int timeStep)
{

	/* calcluating the index for getAspect function to get access the desired cell of the domain. */
	int col;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int index;
	int totCols = SpaData->getcols();

	double effWidth;
	adjustedDirSW_W.clear();
	adjustedDirSW_W.resize(TotalDist);

	switch (SolvingMethod)
	{
	case 1:

		// matrix1 would be direct solar radiation
		adjustedDirSW_W.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {

			col = colNum_Dist[i] - 1;
			row = rowNum_Dist[i] - 1;
			index = row * totCols + col;
			slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
			aspect = TI->getAspect(index);

			double topoEffect = (sin(slope) * cos(SolAltitude_LI[timeStep]) * cos((SolAltitude_LI[timeStep]) - aspect)) +
				cos(slope) * sin(SolAltitude_LI[timeStep]);
			if (topoEffect < 0) { topoEffect = 0; }
			effWidth = effectiveShadingW(DirSW, i, timeStep);
			adjustedDirSW_W[i] = DirSW[timeStep] * (1 - SWreflVec[timeStep]) * topoEffect * (1 - (effWidth / secWidth_LI[i]));
			if (effWidth > secWidth_LI[i]) { adjustedDirSW_W[i] = 0; }
		}
		break;

	case 2:
		// matrix1 would be direct solar radiation
		adjustedDirSW_W.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			adjustedDirSW_W[i] = DirSW[timeStep] * (1 - SF_LI[i]) * (1 - SWreflVec[timeStep]);
		}
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");

	}


}


void StreamTemperature::longWaveRadiation(const vector<double> &airTemperature, const vector<double> &relHumidity,
	const vector<double> &cloadinessCoeff, const vector<double> &streamTemp, int timeStep) {
	double SBConst = 0.000000056696;			// Stefan-Boltzman constant, 5.6696*10-8 (kg�s-3�K-4) 

	atmLW.resize(TotalDist);
	lcLW.resize(TotalDist);
	backLW.resize(TotalDist);

	switch (SolvingMethod)
	{
	case 1:
		// solving based on the calculated sky view factor
		for (int i = 0; i < TotalDist; i++) {
			double satVapPre = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
			double realVapPre = (relHumidity[timeStep] / 100) * satVapPre;

			double emis = 1.72 * pow(((realVapPre) / (airTemperature[timeStep] + 273.2)), (1.0 / 7.0)) * (1 + (0.22 * (pow(cloadinessCoeff[timeStep], 2))));
			if (emis > 0.96) { emis = 0.96; }
			// added by Reza for testing the Dr. Lautz's work: HFlux
			//term1W = 0.96 * 0.84 * SBConst * pow((airTemp + 273.2), 4) * min(TSAWest, VSAWest);
			atmLW[i] = 0.96 * emis * SBConst * pow((airTemperature[timeStep] + 273.2), 4) * SkyV_E[i];
			// Land cover longwave radiation
			lcLW[i] = 0.96 * (1 - SkyV_E[i]) * 0.96 * SBConst * pow((airTemperature[timeStep] + 273.2), 4);

			backLW[i] = -0.96 * SBConst * pow((streamTemp[i] + 273.2), 4);

		}
		break;
	case 2:
		for (int i = 0; i < TotalDist; i++) {
			double satVapPre = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
			double realVapPre = (relHumidity[timeStep] / 100) * satVapPre;

			double emis = 1.72 * pow(((realVapPre) / (airTemperature[timeStep] + 273.2)), (1.0 / 7.0)) * (1 + (0.22 * (pow(cloadinessCoeff[timeStep], 2))));
			if (emis > 0.96) { emis = 0.96; }
			// added by Reza for testing the Dr. Lautz's work: HFlux
			//term1W = 0.96 * 0.84 * SBConst * pow((airTemp + 273.2), 4) * min(TSAWest, VSAWest);
			atmLW[i] = 0.96 * emis * SBConst * pow((airTemperature[timeStep] + 273.2), 4) * SkyToView_LI[i];
			// Land cover longwave radiation
			lcLW[i] = 0.96 * (1 - SkyToView_LI[i]) * 0.96 * SBConst * pow((airTemperature[timeStep] + 273.2), 4);

			backLW[i] = -0.96 * SBConst * pow((streamTemp[i] + 273.2), 4);
			
		}
		break;
	default:
		cout << "Wrong longwave radiation methodology!!" << endl;
		AddLogComment("Wrong longwave radiation methodology!!");
	}

	for (int i = 0; i < TotalDist; i++) {
		atmLW_2D[i][timeStep] = atmLW[i];
		LCLW_2D[i][timeStep] = lcLW[i];
		backLW_2D[i][timeStep] = backLW[i];
		LW_2D[i][timeStep] = atmLW_2D[i][timeStep] + LCLW_2D[i][timeStep] + backLW_2D[i][timeStep];
	}

	atmLW.clear();
	lcLW.clear();
	backLW.clear();
}

void StreamTemperature::latentHeat(const vector<double> &airTemperature, const vector<double> &relHumidity, 
	const vector<double> &streamTemp, const vector<double> &windSp, int timeStep) {

	double c_air = 1004;			// heat capacity of air (J/kg deg C)
	double rho_air = 1.2041;		// density of air at 20 deg C (kg/m^3)

	latent.resize(TotalDist);

	// <<<<<<<<< Evaporation section >>>>>>>>
	for (int i = 0; i < TotalDist; i++) {
		double L_e = 1000000 * (2.501 - (0.002361 * streamTemp[i]));		// Calculate the latent heat of vaporization J/kg
																			// Calculate the slope of the saturated vapor pressure curve at a given air temperature
		double satVapPreLat = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
		double realVapPre = (relHumidity[timeStep] / 100) * satVapPreLat;
		double s = (4100 * satVapPreLat) / (pow((237 + airTemperature[timeStep]), 2)); //kPa / deg C
																					   // Calculate the aerodynamic resistance
		double r_a = 245 / ((0.54 * windSp[timeStep]) + 0.5); //[s / m]

															  // Calculate air pressure
															  // z = elevation of station where met data was obtained
		double Pa = 101.3 - (0.0105 * elev_LI[i]);
		// Calculate psychrometric constant(kPa / deg C) (based on air pressure(Pa), (value should be adjusted for different site elevations),
		//ratio of water to dry air = .622, and the latent heat of water vaporization = 2.45E6 [J / kg deg C])
		double psy = (c_air*Pa) / (0.622 * 2450000);
		// Calculate the Penman open water evaporation
		//double E = ((s * (((swDir[timeStep] + swDiff[timeStep]) * (1 - SWreflVec[timeStep])) + atmLW_2D[i][timeStep] + LCLW_2D[i][timeStep] + backLW_2D[i][timeStep])) / (1000 * L_e*(s + psy)))
		//	+ ((c_air*rho_air*psy*(satVapPreLat - realVapPre)) / (1000 * L_e*r_a*(s + psy)));
		double E = ((s * (SW_2D[i][timeStep] + LW_2D[i][timeStep])) / (1000 * L_e*(s + psy)))
			+ ((c_air*rho_air*psy*(satVapPreLat - realVapPre)) / (1000 * L_e*r_a*(s + psy)));

		latent[i] = (-rho_water * L_e * E);
	}
	
	for (int i = 0; i < TotalDist; i++) {
		Latent_2D[i][timeStep] = latent[i];
	}

	latent.clear();
}

void StreamTemperature::sensibleHeat(const vector<double> &airTemperature, const vector<double> &streamTemp, const vector<double> &windSp,
	const vector<double> &relHumidity, int timeStep) {

	int method = pm->get_sens_method();
	double c_air = 1004;			// (J / kg deg C) value for the heat capacity of air
	double rho_air = 1.2041;		// (kg / m ^ 3) value for the density of air at 20 deg C

	double vaporLatHeat = 2499500;			// latent heat of vaporization (Joules�kg-1)
	double empiricalConst = 0.00000000159;       // empirical constant, (s�m-1�mb-1)

	sensible.resize(TotalDist);

	switch (method)
	{
	case 1:
		for (int i = 0; i < TotalDist; i++) {
			double z_veg = 0.25;		    // (m)  height of vegetation around stream
			double zd = 0.7*z_veg;			// zero - plane displacement, m
			double z0 = 0.1*z_veg;			//roughness height, m
			double DH_DM = 1;               // ratio of diffusivity of sensible heat to diffusivity
											// of momentum, m2 / s(1 under stable conditions)
			double k = 0.4;                 //dimensionless constant
			double KH = DH_DM*c_air*rho_air*((pow(k, 2)) / (pow((log((elev_LI[i] - zd) / z0)), 2))); // (J / C deg m3)			
			sensible[i] = -KH * windSp[timeStep] * (streamTemp[i] - airTemperature[timeStep]); // W / m2
		}
		break;

	case 2:
		for (int i = 0; i < TotalDist; i++) {
			double ews = 0.61275* exp((17.27 * streamTemp[i]) / (237.3 + streamTemp[i])); //kPa
			double ewa = (relHumidity[timeStep] / 100.0)*ews; //kPa
			double Pa1 = 101.3 * pow(((293 - (0.0065 * elev_LI[i])) / 293), 5.256);
			double Br = 0.00061 * Pa1 * ((streamTemp[i] - airTemperature[timeStep]) / (ews - ewa));
			sensible[i] = Br * Latent_2D[i][timeStep];
		}
		break;

	case 3:
		// Ning Sun's methodology
		for (int i = 0; i < TotalDist; i++) {
			double ews = 0.61275* exp((17.27 * streamTemp[i]) / (237.3 + streamTemp[i])); //kPa
			double ewa = (humidity / 100)*ews; //kPa
			double Pa1 = 101.3 * pow(((293 - (0.0065 * elev_LI[i])) / 293), 5.256);
			double Br = 0.00061 * Pa1 * ((streamTemp[i] - airTemperature[timeStep]) / (ews - ewa));
			sensible[i] = Br * rho_water * vaporLatHeat * empiricalConst * windSp[timeStep] * (airTemperature[timeStep] - streamTemp[i]);
		}
		break;


	default:
		cout << "Wrong sensible heat methodology!!" << endl;
		AddLogComment("Wrong sensible heat methodology!!");

	}

	for (int i = 0; i < TotalDist; i++) {
		Sensible_2D[i][timeStep] = sensible[i];
	}

	sensible.clear();

}

void StreamTemperature::bedSediment(const vector<vector<double>> &Wp, const vector<vector<double>> &Width_B, const vector<double> &Ksed_index,
	const vector<double> &streamTemp, const vector<double> &bedTemp, const vector<double> &depthMeas, int timeStep) {
	//double tempSurface = surTemperature(ts);
	// streamTemp and sedimentTemp should be based on celsius
	bed.resize(TotalDist);
	for (int i = 0; i < TotalDist; i++) {
		bed[i] = ((Wp[i][timeStep] / Width_B[i][timeStep]) * (-Ksed_index[i] * ((streamTemp[i] - bedTemp[timeStep]) / depthMeas[i])));
	}

	for (int i = 0; i < TotalDist; i++) {
		Bed_2D[i][timeStep] = bed[i];
	}
	bed.clear();
}

void StreamTemperature::avgTemperature() {

	TotalTime = pm->get_total_time();
	TotalDist = pm->get_total_dist();
	calculation = pm->get_caculation_method(); // for 1: Solution Method=Crank-Nicolson and for 2: Solution Method=Explicit finite difference, 3: Solution Method=HEC-RAS based method, 4: Solution Method=Rung-Kutta
	vector<double> timeMod;
	vector<double> distMod;

	for (int i = 1; i <= TotalTime; i++) {
		timeMod.push_back(i);
	}

	for (int i = 1; i <= TotalDist; i++) {
		distMod.push_back(i);
	}
	cout << "+++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	cout << "Starting the i-Tree Cool-River calculations..." << endl << endl;
	cout << "Calculating time steps and nodes..." << endl;
	AddLogComment("Starting the i-Tree Cool-River calculations...\nCalculating time steps and nodes...\n");
	double timeSteps = TotalTime;
	double nodes = TotalDist;
	int dt = *std::max_element(timeMod.begin(), timeMod.end()) / (TotalTime - 1);	//=====> New for hourly 
	//double dt = (*std::max_element(timeMod.begin(), timeMod.end()) / (TotalTime)) * 60;
	cout << "...done!" << endl << endl;
	cout << "Interpolating longitudinal data in space..." << endl;
	AddLogComment("Interpolating longitudinal data in space...");
	// **************** Reading the discharge data for a rainfall event *********************
	// New: for Tannersville case study; We have 8 different situation for the discharge.
	const int dischargeCount = inp->getDis()->get_Q_count();
	vector <double> distanceQ, flow_temp_1;
		
	for (int i = 1; i <= dischargeCount; i++) {
			double temp1, temp_dist;
			temp1 = inp->getDis()->Qdischarge1(i);
			flow_temp_1.push_back(temp1);

			temp_dist = inp->getDis()->Qdistance(i);
			distanceQ.push_back(temp_dist);
	}


	vector<double> discharge_LI1;

	// Interpolate
	for (double x : distMod) {
		double y = interpolate(distanceQ, flow_temp_1, x, true);
		discharge_LI1.push_back(y);
	}

	// **************** Reading the inflow data *********************
	// New: for Tannersville case study; We have 4 additional inflow.
	const int knownInflowDates = inp->getInf()->getCount();
	vector <double> locations, inflow_temp_1, inflow_temp_2, inflow_temp_3, inflow_Q_1, inflow_Q_2, inflow_Q_3;
	//Sep.20:Added for the LA River Project
	vector <double> inflow_temp_4, inflow_temp_5, inflow_temp_6, inflow_Q_4, inflow_Q_5, inflow_Q_6;

	vector<vector<double>> inflow_Discharge(TotalDist, std::vector<double>(TotalTime));
	vector<vector<double>> inflow_Temp(TotalDist, std::vector<double>(TotalTime));
	for (int i = 1; i <= knownInflowDates+1; i++) {
		if (i == 1) {
			double temp1, temp2, temp3;
			//Sep.20:Added for the LA River Project
			double temp4, temp5, temp6;

			temp1 = inp->getInf()->getInflowT_1(i);
			temp2 = inp->getInf()->getInflowT_2(i);
			temp3 = inp->getInf()->getInflowT_3(i);
			//Sep.20:Added for the LA River Project
			temp4 = inp->getInf()->getInflowT_4(i);
			temp5 = inp->getInf()->getInflowT_5(i);
			temp6 = inp->getInf()->getInflowT_6(i);

			locations.push_back(temp1);
			locations.push_back(temp2);
			locations.push_back(temp3);
			//Sep.20:Added for the LA River Project
			locations.push_back(temp4);
			locations.push_back(temp5);
			locations.push_back(temp6);
		}
		else {
			double temp1, temp2, temp3, temp5, temp6, temp7;
			//Sep.20:Added for the LA River Project
			double temp4, temp8, temp9, temp10, temp11, temp12;

			temp1 = inp->getInf()->getInflowT_1(i);
			temp2 = inp->getInf()->getInflowT_2(i);
			temp3 = inp->getInf()->getInflowT_3(i);
			
			temp5 = inp->getInf()->getInflowQ_1(i); 
			temp6 = inp->getInf()->getInflowQ_2(i);
			temp7 = inp->getInf()->getInflowQ_3(i);
			
			inflow_temp_1.push_back(temp1);
			inflow_temp_2.push_back(temp2);
			inflow_temp_3.push_back(temp3);
			
			inflow_Q_1.push_back(temp5);
			inflow_Q_2.push_back(temp6);
			inflow_Q_3.push_back(temp7);
			
			//Sep.20:Added for the LA River Project
			temp4 = inp->getInf()->getInflowT_4(i);
			temp8 = inp->getInf()->getInflowQ_4(i);
			temp9 = inp->getInf()->getInflowT_5(i);
			temp10 = inp->getInf()->getInflowQ_5(i);
			temp11 = inp->getInf()->getInflowT_6(i);
			temp12 = inp->getInf()->getInflowQ_6(i);
			inflow_temp_4.push_back(temp4);
			inflow_Q_4.push_back(temp8);
			inflow_temp_5.push_back(temp9);
			inflow_Q_5.push_back(temp10);
			inflow_temp_6.push_back(temp11);
			inflow_Q_6.push_back(temp12);

		}

	}

	for (int j = 0; j < TotalTime; j++) {
		inflow_Discharge[locations[0] - 1][j] = inflow_Q_1[j];
		inflow_Discharge[locations[1] - 1][j] = inflow_Q_2[j];
		inflow_Discharge[locations[2] - 1][j] = inflow_Q_3[j];

		inflow_Temp[locations[0] - 1][j] = inflow_temp_1[j];
		inflow_Temp[locations[1] - 1][j] = inflow_temp_2[j];
		inflow_Temp[locations[2] - 1][j] = inflow_temp_3[j];
		
		//Sep.20:Added for the LA River Project
		inflow_Discharge[locations[3] - 1][j] = inflow_Q_4[j];
		inflow_Discharge[locations[4] - 1][j] = inflow_Q_5[j];
		inflow_Discharge[locations[5] - 1][j] = inflow_Q_6[j];
		inflow_Temp[locations[3] - 1][j] = inflow_temp_4[j];
		inflow_Temp[locations[4] - 1][j] = inflow_temp_5[j];
		inflow_Temp[locations[5] - 1][j] = inflow_temp_6[j];

	}
	 
	// ***************************** DONE **************************

	const int knownSectionCount = inp->getMor()->getCount();
	vector<double> secDistance, secArea, secWidth, secDepth, secDischarge, colNum, rowNum, LongValue, latValue, secSlope, Z;
	for (int i = 1; i <= knownSectionCount; i++) {
		double temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9, temp10, temp11;
		temp1 = inp->getMor()->getDsitance(i);
		temp2 = inp->getMor()->getArea(i);
		temp3 = inp->getMor()->getWidth(i);
		temp4 = inp->getMor()->getDepth(i);
		temp5 = inp->getMor()->getDischarge(i);
		temp6 = inp->getMor()->getColNumber(i);
		temp7 = inp->getMor()->getRowNumber(i);
		temp8 = inp->getMor()->getLongitude(i);
		temp9 = inp->getMor()->getLatitude(i);
		secDistance.push_back(temp1);
		secArea.push_back(temp2);
		secWidth.push_back(temp3);
		secDepth.push_back(temp4);
		secDischarge.push_back(temp5);
		colNum.push_back(temp6);
		rowNum.push_back(temp7);
		LongValue.push_back(temp8);
		latValue.push_back(temp9);

		temp10 = inp->getMor()->getSlope(i);
		secSlope.push_back(temp10);

		temp11 = inp->getMor()->getZvalue(i);
		Z.push_back(temp11);

	}

	vector<double> discharge_LI;

	// Interpolate
	for (double x : distMod) {
		double y = interpolate(secDistance, secWidth, x, true);
		secWidth_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, secDepth, x, true);
		secDepth_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, secDischarge, x, true);
		discharge_LI.push_back(y);   // interpolation of stream discharge at each location where dimensions were measured to each model node
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, secSlope, x, true);
		secSlope_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, secArea, x, true);
		secArea_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, Z, x, true);
		Z_LI.push_back(y);
	}
	

	colNum_Dist.resize(TotalDist);
	rowNum_Dist.resize(TotalDist);
	LongValue_Dist.resize(TotalDist);
	latValue_Dist.resize(TotalDist);

	int valuei = knownSectionCount - 1;
	// this way, I will consider the coordinates of the previous known point for the set of locations up to next known point, in the morphology input file
	for (int i = (TotalDist - 1); i >= 0; i--) {
		if (distMod[i] >= int(secDistance[valuei])) {
			colNum_Dist[i] = colNum[valuei];
			rowNum_Dist[i] = rowNum[valuei];
			LongValue_Dist[i] = LongValue[valuei];
			latValue_Dist[i] = latValue[valuei];
		}
		if (distMod[i] <= int(secDistance[valuei])) { valuei--; }
	}

	//colNum_Dist.push_back(colNum[i]);

	cout << "...done!" << endl << endl;


	cout << "Interpolating temporal data in time..." << endl;
	AddLogComment("Interpolating temporal data in time...");
	//vector<vector<double>> discharge_time(TotalDist, std::vector<double>(TotalTime));

	vector<vector<double>> discharge_time;
	discharge_time.resize(TotalDist);
	for (int i = 0; i < TotalDist; i++) {
		discharge_time[i].resize(TotalTime);
		for (int j = 0; j < TotalTime; j++) {
			discharge_time[i][j] = (discharge_LI1[i]);   // each row is a location along the stream and each column is a different time
		}
	}


	// ======================= Sediment Data ========================
	double sedDataCount = inp->getSed()->getTotalBedData();
	vector<double> DistBedMeas, BedDepthMeas, BedT0, BedTn, K_sedType_LI;
	vector<double> BedDepthMeas_LI, BedTn_LI;
	std::vector<std::string> BedSedType;
	for (int i = 1; i <= sedDataCount+1; i++) {
		DistBedMeas.push_back(inp->getSed()->getDistance(i));
		BedDepthMeas.push_back(inp->getSed()->getDepthOfMeas(i));
		BedTn.push_back(inp->getSed()->getTn_bed(i));
		BedSedType.push_back(inp->getSed()->getBedType(i));
	}

	// Interpolate
	for (double x : distMod) {
		double y = interpolate(DistBedMeas, BedDepthMeas, x, true);
		BedDepthMeas_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(DistBedMeas, BedTn, x, true);
		BedTn_LI.push_back(y);
	}
	vector<double> convertedCode;
	// Determine the sediment thermal conductivity (values from Lapham, 1989)
	for (int i = 0; i < sedDataCount+1; i++) {
		std::string tempType = BedSedType[i];
		if (tempType == "clay") { convertedCode.push_back(0.84); }
		else if (tempType == "sand") { convertedCode.push_back(1.2); }
		else if (tempType == "gravel") { convertedCode.push_back(1.4); }
		else if (tempType == "cobbles") { convertedCode.push_back(2.5); }
	}


	// operating the NEAREST interpolation! 
	//DistBedMeas[0] = 1;
	K_sedType_LI = interp1(DistBedMeas, convertedCode, distMod);			// thermal conductivity of sediment, W/mC

	vector<double> tempBedT;
	//tempBedT.push_back(BedT0[1]);
	tempBedT.push_back(BedTn[1]);
	tempBedT.push_back(BedTn[1]);

	vector<double> sedimentTime_LI;
	vector<double> sedimentDist_LI;
	vector<double> xValsTotalTime;
	//vector<double> xValsTotalDist;

	//for (int i = 1; i <= TotalTime; i++) xValsTotalTime.push_back((double)i); 
	//for (int i = 1; i <= TotalDist; i++) xValsTotalDist.push_back((double)i);
	// Interpolate
	//for (double x : xValsTotalTime)

	double firstDate = 0;
	double lastDate = timeSteps - 1;
	vector<double> time_dis;
	time_dis.push_back(firstDate);
	time_dis.push_back(lastDate);

	vector<double>timeMod_temp;
	for (int i = 1; i <= TotalTime+1; i++) {
		timeMod_temp.push_back(i);
	}	
	for (double x : timeMod_temp)
	{
		double y = interpolate(time_dis, tempBedT, x, true);
		sedimentTime_LI.push_back(y);
	}
	for (double x : distMod)
	{
		double y = interpolate(time_dis, tempBedT, x, true);
		sedimentDist_LI.push_back(y);
	}


	// ==============================================

	// ================== read in the shading percentage condition input file
	vector<double> DistanceSP_Temp, SF_Temp, SkyView_Temp;
	double ShadingPerDist = inp->getSP()->getTotalShadingData();

	for (int i = 1; i <= ShadingPerDist; i++) {
		DistanceSP_Temp.push_back(inp->getSP()->getDistance(i));
		SF_Temp.push_back(inp->getSP()->getSF(i));
		SkyView_Temp.push_back(inp->getSP()->getSkyView(i));
	}
	for (double x : distMod) {
		double y = interpolate(DistanceSP_Temp, SkyView_Temp, x, true);
		SkyToView_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(DistanceSP_Temp, SF_Temp, x, true);
		SF_LI.push_back(y);
	}

	// ================== Done! ============================

	// =============== Read in the shading data ======
	double ShadingDist = inp->getShade()->gettotalts();
	vector<double> Distance_Temp, BankH_E_Temp, TreeH_E_Temp, BankH_W_Temp, TreeH_W_Temp, BuildH_E_Temp,
		BuildH_W_Temp, CanDist_E_Temp, CanDist_W_Temp, BanDist_E_Temp, BanDist_W_Temp, BuildDist_E_Temp,
		BuildDist_W_Temp, Buff_E_Temp, Buff_W_Temp, StrAzimuth_Temp, elev_temp;

	for (int i = 1; i <= ShadingDist; i++) {
		Distance_Temp.push_back(inp->getShade()->gethDistanceShade(i));
		BankH_E_Temp.push_back(inp->getShade()->gethBankE(i));
		TreeH_E_Temp.push_back(inp->getShade()->gethTreeE(i));
		BankH_W_Temp.push_back(inp->getShade()->gethBankW(i));
		TreeH_W_Temp.push_back(inp->getShade()->gethTreeW(i));
		BuildH_E_Temp.push_back(inp->getShade()->gethBuildingE(i));
		BuildH_W_Temp.push_back(inp->getShade()->gethBuildingW(i));
		CanDist_E_Temp.push_back(inp->getShade()->getBankCanopyDistE(i));
		CanDist_W_Temp.push_back(inp->getShade()->getBankCanopyDistW(i));
		BanDist_E_Temp.push_back(inp->getShade()->getBankDistE(i));
		BanDist_W_Temp.push_back(inp->getShade()->getBankDistW(i));
		BuildDist_E_Temp.push_back(inp->getShade()->getBankBuildingDistE(i));
		BuildDist_W_Temp.push_back(inp->getShade()->getBankBuildingDistW(i));
		Buff_E_Temp.push_back(inp->getShade()->getBufferWidthE(i));
		Buff_W_Temp.push_back(inp->getShade()->getBufferWidthW(i));
		elev_temp.push_back(inp->getShade()->getElev(i));
		StrAzimuth_Temp.push_back(inp->getShade()->getStreamAzimuth(i));

	}

	// Interpolate
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BankH_E_Temp, x, true);
		BankH_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, TreeH_E_Temp, x, true);
		TreeH_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BankH_W_Temp, x, true);
		BankH_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, TreeH_W_Temp, x, true);
		TreeH_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, CanDist_E_Temp, x, true);
		CanDist_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, CanDist_W_Temp, x, true);
		CanDist_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BanDist_E_Temp, x, true);
		BanDist_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BanDist_W_Temp, x, true);
		BanDist_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BuildDist_E_Temp, x, true);
		BuildDist_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, BuildDist_W_Temp, x, true);
		BuildDist_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, Buff_E_Temp, x, true);
		Buff_E_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, Buff_W_Temp, x, true);
		Buff_W_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, elev_temp, x, true);
		elev_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(Distance_Temp, StrAzimuth_Temp, x, true);
		StrAzimuth_LI.push_back(y);
	}


	// I considered 10 meter in average for each building. Therefore, I copy the height of the building to 5m up and 
	// 5m down stream along the river.
	BuildH_E_LI.resize(TotalDist);
	BuildH_W_LI.resize(TotalDist);


	for (int i = 0; i < Distance_Temp.size(); i++) {
		if (i == (Distance_Temp.size() - 1)) {
			BuildH_E_LI[Distance_Temp[i] - 5] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 4] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 3] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 2] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 1] = BuildH_E_Temp[i];

			BuildH_W_LI[Distance_Temp[i] - 5] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 4] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 3] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 2] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 1] = BuildH_W_Temp[i];
		}
		else if (i == 0) {
			BuildH_E_LI[Distance_Temp[i]] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 5] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 4] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 3] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 2] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 1] = BuildH_E_Temp[i];

			BuildH_W_LI[Distance_Temp[i]] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 5] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 4] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 3] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 2] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 1] = BuildH_W_Temp[i];
		}
		else {
			BuildH_E_LI[Distance_Temp[i]] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 5] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 4] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 3] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 2] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] - 1] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 1] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 2] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 3] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 4] = BuildH_E_Temp[i];
			BuildH_E_LI[Distance_Temp[i] + 5] = BuildH_E_Temp[i];

			BuildH_W_LI[Distance_Temp[i]] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 5] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 4] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 3] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 2] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] - 1] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 1] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 2] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 3] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 4] = BuildH_W_Temp[i];
			BuildH_W_LI[Distance_Temp[i] + 5] = BuildH_W_Temp[i];
		}
	}


	// ================== Done! ============================
	// LAI value
	CanopyLAI = pm->get_LAI();

	// Calculate width - depth - discharge relationship
	//assumes stream cross section is a triangle and calculates the angle between the depth and the edge
	int number = TotalDist;
	vector<float> theta(number);
	for (int i = 0; i < nodes; i++) {
		theta[i] = (atan(secDepth_LI[i] / (0.5*secWidth_LI[i])));
	}

	

	vector<double> n_s;
	n_s.resize(TotalDist);
	// calculates the manning number divided by the slope^1/2 which will be used as a constant at each location along the stream
	for (int i = 0; i < nodes; i++) {
		if ((calculation == 1) || (calculation == 4)) {
			n_s[i] = (((pow(0.25, (2.0 / 3.0)))*(pow(2, (5.0 / 3.0)))*(pow(cos(theta[i]), (2.0 / 3.0)))*(pow(tan(theta[i]), (5.0 / 3.0)))
				*(pow(secDepth_LI[i], (8.0 / 3.0)))) / (2 * discharge_LI[i]));
		}
		if ((calculation == 2) || (calculation == 3)) {
			n_s[i] = pm->get_roughness();
		}
		
	}

	
	// Solve for depth through time and distance (assume constant theta and n_s)
	if (calculation == 1) {

		discharge_time.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			discharge_time[i].resize(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				discharge_time[i][j] = inflow_Discharge[0][0];   // each row is a location along the stream and each column is a different time
			}
		}

		depth_total.resize(nodes);
		for (int i = 0; i < nodes; i++) {
			depth_total[i].resize(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				depth_total[i][j] = pow(((2.0 * n_s[i] * discharge_time[i][j]) / ((pow(0.25, (2.0 / 3.0))) * (pow(2.0, (5.0 / 3.0)))
					* (pow(cos(theta[i]), (2.0 / 3.0))) * (pow(tan(theta[i]), (5.0 / 3.0))))), (3.0 / 8.0));
			}
		}

		// Solve for width of stream through time and distance (assume constant theta and n_s)
		width_total.resize(nodes);
		for (int i = 0; i < nodes; i++) {
			width_total[i].resize(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				width_total[i][j] = 2.0 * tan(theta[i]) * (pow(((2.0 * n_s[i] * discharge_time[i][j]) / ((pow(0.25, (2.0 / 3.0)))
					* (pow(2.0, (5.0 / 3.0))) * (pow(cos(theta[i]), (2.0 / 3.0))) * (pow(tan(theta[i]), (5.0 / 3.0))))), (3.0 / 8.0)));
			}
		}

		// cross sectional area
		area_total.resize(nodes);
		for (int i = 0; i < nodes; i++) {
			area_total[i].resize(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				area_total[i][j] = 0.5 * depth_total[i][j] * width_total[i][j];
			}
		}

		// Calculate wetted perimeter through time and space for triangular cross section
		wp_total.resize(nodes);
		for (int i = 0; i < nodes; i++) {
			wp_total[i].resize(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				wp_total[i][j] = 2.0 * (depth_total[i][j] / cos(theta[i]));
			}
		}
	}

	double endTimeCount = inp->getWeat()->gettotalts();

	// ===============   UNSTEADY STATE   ===============
	dx_unsteady = pm->get_unsteady_dx();			// in meter
	dx_Interval = pm->get_dx();
	dtime_unsteady = pm->get_unsteady_dt();			// in second
	if ((calculation == 3)||(calculation == 1)) {
		dtime_unsteady = pm->get_dt(); 
		TotalTime_min = TotalTime * 60;
		TotalTime_min = TotalTime_min * (60.0 / dtime_unsteady);
		//TotalDist_stable = (TotalDist / dx_Interval) + 1;
		TotalDist_stable = (TotalDist / dx_Interval);
	}
	if (calculation == 2) {

		TotalTime_min = TotalTime * 60;
		if (dtime_unsteady < 60) { TotalTime_min = TotalTime_min * (60.0 / dtime_unsteady); }
		TotalDist_stable = (TotalDist / dx_unsteady) + 1;
	}
	
	

	for (int i = 0; i < endTimeCount; i++) {
		double temp = inp->getT()->getTime(i);
		hourlyTime.push_back(temp);
	}
	hourlyTime[endTimeCount-1] = TotalTime_min;
	// ==================================================
	const int tsTotalHourly = inp->getS()->gettotalts() - 1;
	vector<double> solarSW_Dir, solarSW_Diff, airTemp, real_humidity, windSp, cloudiness, obs_xo, hourList, sedTemp;

	for (int i = 0; i < tsTotalHourly; i++) {
		double temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9;
		temp1 = inp->getS()->getDirSW(i);
		temp2 = inp->getS()->getDiffSW(i);
		temp3 = inp->getWeat()->getTair(i);  // Air temperatures have been converted to deg C in InputWeather.cpp
		temp4 = inp->getWeat()->getHumidity(i);
		temp5 = inp->getWeat()->getWindSp(i);
		temp6 = inp->getWeat()->getCloadiness(i);
		temp7 = inp->getWeat()->getObsT_x0(i);
		temp8 = inp->getWeat()->getHour(i);
		temp9 = inp->getWeat()->getSedT(i);
		
		solarSW_Dir.push_back(temp1);
		solarSW_Diff.push_back(temp2);
		airTemp.push_back(temp3);
		real_humidity.push_back(temp4);
		windSp.push_back(temp5);
		cloudiness.push_back(temp6);
		obs_xo.push_back(temp7);
		hourList.push_back(temp8);
		sedTemp.push_back(temp9);
	}

	vector<double> solarSW_Dir_LI, solarSW_Diff_LI, airTemp_LI, real_humidity_LI, windSp_LI, cloudiness_LI,  
		hourList_LI, sedTemp_LI;

	for (int i = 0; i < tsTotalHourly-1; i++) {
		solarSW_Dir_LI.push_back(solarSW_Dir[i]);
		solarSW_Diff_LI.push_back(solarSW_Diff[i]);
		airTemp_LI.push_back(airTemp[i]);
		real_humidity_LI.push_back(real_humidity[i]);
		windSp_LI.push_back(windSp[i]);
		cloudiness_LI.push_back(cloudiness[i]);
		obs_xo_LI.push_back(obs_xo[i]);
		hourList_LI.push_back(hourList[i]);
		sedTemp_LI.push_back(sedTemp[i]);
	}


	// ================== Solar Azimuth and Altitude =====================

	vector<double> SolAzimuth_Temp, SolAltitude_Temp;
	for (int i = 0; i < tsTotalHourly-1; i++) {
		SolAzimuth_Temp.push_back(solarCal->getSolAzimuth(i));
		SolAltitude_Temp.push_back(solarCal->getSolAltitude(i));
	}

	for (int i = 0; i < tsTotalHourly-1; i++) {
		SolAzimuth_LI.push_back(SolAzimuth_Temp[i]);
		SolAltitude_LI.push_back(SolAltitude_Temp[i]);
	}

	cout << "...done!" << endl;
	// ============================== done! ===============================

	// ==================================================		
	
	// I put this function here to make sure that the code has the required vectors for unsteady calculations for 
	// solar reflectivity.
	solarReflectivity();

	// ===============   UNSTEADY STATE   ===============


	vector<int> timeMod_min;
	vector<double> xVals_min;
	for (int i = 0; i < TotalTime_min; i++) {
		timeMod_min.push_back(i);
	}
	vector<double> DirSW_Uns, DiffSW_Uns, airTemp_Uns, RH_Uns, Cloadiness_Uns, wndSpd_Uns, sedimentTime_LI_Uns, sedTemp_Uns;
	// Interpolate
	//LAR Project
	
	for (int i = 1; i <= TotalTime_min; i++) xVals_min.push_back((double)i);
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, inflow_Q_1, x, true);
		Q_minBased.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, obs_xo_LI, x, true);
		Tobs_minBased.push_back(y);
	}

	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, inflow_Q_2, x, true);
		inflow_Q_2_min.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, inflow_temp_2, x, true);
		inflow_temp_2_temp.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, inflow_Q_3, x, true);
		inflow_Q_3_min.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, inflow_temp_3, x, true);
		inflow_temp_3_temp.push_back(y);
	}

	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, solarSW_Dir_LI, x, true);
		DirSW_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, solarSW_Diff_LI, x, true);
		DiffSW_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, airTemp_LI, x, true);
		airTemp_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, real_humidity_LI, x, true);
		RH_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, cloudiness_LI, x, true);
		Cloadiness_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, windSp_LI, x, true);
		wndSpd_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, sedimentTime_LI, x, true);
		sedimentTime_LI_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, sedTemp_LI, x, true);
		sedTemp_Uns.push_back(y);
	}
	
	

	hyp_Slope_Uns.resize(TotalDist_stable);
	vector<double> elevation_calc(knownSectionCount);
	vector<double> elevation_LI, elevation_Uns;
	elevation_calc[0] = elev_LI[0];
	for (int i = 1; i < knownSectionCount; i++) {
		elevation_calc[i] = elevation_calc[i - 1] - (secSlope[i - 1] * (secDistance[i] - secDistance[i - 1]));
	}
	for (double x : distMod) {
		double y = interpolate(secDistance, elevation_calc, x, true);
		elevation_LI.push_back(y);
	}

	int counter_unsteady = 0;
	for (int i = 0; i <= TotalDist_stable; i++) {
		Z_unsteady.push_back(Z_LI[counter_unsteady]);
		n_unsteady.push_back(n_s[counter_unsteady]);
		s_unsteady.push_back(secSlope_LI[counter_unsteady]);			// Bed slope
		discharge_Unsteady.push_back(discharge_LI1[counter_unsteady]);
		BedTn_LI_Uns.push_back(BedTn_LI[counter_unsteady]);
		width_unsteady.push_back(secWidth_LI[counter_unsteady]);
		
		elevation_Uns.push_back(elevation_LI[counter_unsteady]);

		counter_unsteady = (counter_unsteady + dx_unsteady) - 1;
	
		if (calculation == 3) {
			if (i == 0) { i = 1; }
			counter_unsteady = i * dx_Interval;
			if (counter_unsteady == ((TotalDist_stable - 1) * dx_Interval)) { counter_unsteady--; }
		}
	}

	for (int i = 1; i < TotalDist_stable-1; i++){
		hyp_Slope_Uns[i] = (elevation_Uns[i-1] - elevation_Uns[i]) / dx_unsteady;
	}
	hyp_Slope_Uns[0] = hyp_Slope_Uns[1];

	//inflow_Temp & inflow_Discharge
	inflow_Rate.resize(TotalDist_stable);
	inflow_Temp_Uns.resize(TotalDist_stable);
	for (int i = 0; i < TotalDist_stable; i++) {
		inflow_Rate[i].resize(TotalTime_min);
		inflow_Temp_Uns[i].resize(TotalTime_min);
	}
	int inflow_loc1 = locations[1] / dx_unsteady;
	int inflow_loc2 = locations[2] / dx_unsteady;
	for (int j = 0; j < TotalTime_min; j++) {
		inflow_Rate[inflow_loc1][j] = inflow_Q_2_min[j];
		inflow_Temp_Uns[inflow_loc1][j] = inflow_temp_2_temp[j];
		inflow_Rate[inflow_loc2][j] = inflow_Q_3_min[j];
		inflow_Temp_Uns[inflow_loc2][j] = inflow_temp_3_temp[j];
	}

	Q_GW.resize(TotalDist_stable);
	Temp_GW.resize(TotalDist_stable);
	for (int i = 0; i < (TotalDist_stable - 1); i++) {
		Q_GW[i] = discharge_Unsteady[i + 1] - discharge_Unsteady[i];
		if (Q_GW[i] < 0) { Q_GW[i] = Q_GW[i - 1]; }	// to avoid negative values caused by interpolation
	}
	Q_GW[TotalDist_stable - 2] = Q_GW[TotalDist_stable - 3];
	for (int i = 0; i < TotalDist_stable; i++) {
		if (i == 0) {
			Temp_GW[i] = sedimentDist_LI[i * dx_Interval];
		}
		else {
			Temp_GW[i] = sedimentDist_LI[(i * dx_Interval) - 1];
		}

	}

	//for (int i = 1; i <= TotalTime_min; i++) xVals_min.push_back((double)i);
	// Interpolate
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, SWreflVec, x, true);
		SWreflVec_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, SolAzimuth_LI, x, true);
		SolAzimuth_LI_Uns.push_back(y);
	}
	for (double x : xVals_min) {
		double y = interpolate(hourlyTime, SolAltitude_LI, x, true);
		SolAltitude_LI_Uns.push_back(y);
	}

	// SUBSTRATE CONDUCTION 
	vector<double> conductivity, particleSize, embeddedness;
	vector<double> conductivity_LI, particleSize_LI, embeddedness_LI;
	//std::vector<std::string> BedSedType;
	for (int i = 1; i <= sedDataCount+1; i++) {
		conductivity.push_back(inp->getSed()->getConductivity(i) / 1000);  // to convert from mm/s to m/s
		particleSize.push_back(inp->getSed()->getParticleSize(i));
		embeddedness.push_back(inp->getSed()->getEmbeddedness(i));
	}

	// Interpolate
	for (double x : distMod) {
		double y = interpolate(DistBedMeas, conductivity, x, true);
		conductivity_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(DistBedMeas, particleSize, x, true);
		particleSize_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(DistBedMeas, embeddedness, x, true);
		embeddedness_LI.push_back(y);
	}


	int counter_uns = 0;
	for (int i = 0; i < TotalDist_stable; i++) {
		conductivity_Uns.push_back(conductivity_LI[counter_uns]);
		particleSize_Uns.push_back(particleSize_LI[counter_uns]);
		embeddedness_Uns.push_back(embeddedness_LI[counter_uns]);

		counter_uns = (counter_uns + dx_unsteady) - 1;
	}

	vector<double> Flux_Total_Time(TotalDist_stable);
	vector<double> Flux_Conduction_Time(TotalDist_stable);
	vector<double> Flux_Convection_Time(TotalDist_stable);
	vector<double> FLux_AtmLW_Time(TotalDist_stable);
	vector<double> Flux_Evaporation_Time(TotalDist_stable);
	vector<double> Flux_LCLW_Time(TotalDist_stable);
	vector<double> Flux_BackLW_Time(TotalDist_stable);
	vector<double> Flux_LW_Time(TotalDist_stable);
	vector<double> Flux_DirSW_Time(TotalDist_stable);
	vector<double> Flux_DiffSW_Time(TotalDist_stable);
	vector<double> Flux_SW_Time(TotalDist_stable);
	vector<double> Delta_T(TotalDist_stable);
	vector<double> depth_Uns_temp(TotalDist_stable);

	vector<double> Nodes_Uns;
	for (int i = 0; i < TotalDist_stable; i++) {
		Nodes_Uns.push_back(i * dx_unsteady);
	}
	Nodes_Uns[0] = 1;
	// ============================== done! ===============================
	cout << "Computing volumes of nodes, discharge rates and groundwater inflow rates..." << endl;
	AddLogComment("Computing volumes of nodes, discharge rates and groundwater inflow rates...");
	// ====================================================================================
	// STEP 1: compute volumes of each reservoir (node) in the model 

	vector<vector<double>> volume(TotalDist, std::vector<double>(TotalTime));
	if (calculation == 1) {
		for (int i = 0; i < TotalTime; i++) {
			volume[0][i] = (distMod[1] - distMod[0]) * area_total[0][i];
		}
		for (int i = 1; i < (TotalDist - 1); i++) {
			for (int j = 0; j < TotalTime; j++) {
				volume[i][j] = area_total[i][j] * (((distMod[i + 1] + distMod[i]) / 2) - ((distMod[i] + distMod[i - 1]) / 2));
			}
		}
		// set volume at last node
		for (int i = 0; i < TotalTime; i++) {
			volume[(nodes - 1)][i] = (distMod[(nodes - 1)] - distMod[(nodes - 2)]) * area_total[(nodes - 1)][i];
		}
	}
	// STEP 2: compute discharge rates at reservoir edges using linear
	//interpolation(n - values are upstream of node n values) 

	vector<vector<double>> Q_half((TotalDist + 1), vector<double>(TotalTime));

	Q_half.resize(TotalDist + 1);
	for (int i = 0; i <= TotalDist; i++) {
		Q_half[i].resize(TotalTime);
	}

	// this 2D vector should have (nodes+1) row and TotalTime column
	// extrapolate backwards to get discharge rate at upstream edge of stream (half a node upstream from first node)
	for (int i = 0; i < TotalTime; i++) {
		Q_half[0][i] = (((2.0 * discharge_time[0][i]) - discharge_time[1][i]) + discharge_time[0][i]) / 2.0;
	}
	// linearly interpolate to get discharge rates at node boundaries
	for (int i = 1; i < TotalDist; i++) {
		for (int j = 0; j < TotalTime; j++) {
			Q_half[i][j] = (discharge_time[i][j] + discharge_time[(i - 1)][j]) / 2.0;
		}
	}
	// extrapolate forwards to get discharge rate at downstream edge of stream (half a node downstream from last node)
	for (int i = 0; i < TotalTime; i++) {
		Q_half[nodes][i] = (((2.0 * discharge_time[(nodes - 1)][i]) - discharge_time[(nodes - 2)][i]) + discharge_time[(nodes - 1)][i]) / 2.0;
	}


	// STEP 3: compute lateral groundwater discharge rates to each node based on longtudinal changes in streamflow
	vector<vector<double>> Q_L(TotalDist, std::vector<double>(TotalTime));
	for (int i = 0; i < TotalDist; i++) {
		for (int j = 0; j < TotalTime; j++) {
			Q_L[i][j] = Q_half[i + 1][j] - Q_half[i][j];
		}
	}

	
	// I had to turn this section off for the LAR Project. I was getting error here and have no idea why!! Reza, Feb. 20
	// STEP 4: unit conversions so all discharge rates are in m3 / min;
	// note that all inputs are x are in m, T are in deg C, and Q or Q_L are in m3 / s
	int TotalDist_dummy = 5;
	int TotalTime_dummy = 5;
	vector<vector<double>> Q_half_min, Q_L_min;
	
	if ((calculation == 2) || (calculation == 4)|| (calculation == 1)) {
		//vector<vector<double>> Q_L_min(TotalDist, std::vector<double>(TotalTime));
		//vector<vector<double>> Q_half_min((TotalDist+1), std::vector<double>(TotalTime));
		Q_half_min.resize(TotalDist + 1);
		for (int i = 0; i < (TotalDist+1); i++) {
			Q_half_min[i].resize(TotalTime);
		}
		Q_L_min.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			Q_L_min[i].resize(TotalTime);
		}
		for (int i = 0; i < (TotalDist + 1); i++) {
			for (int j = 0; j < TotalTime; j++) {
				Q_half_min[i][j] = Q_half[i][j] * 60.0;
			}
		}
		for (int i = 0; i < TotalDist; i++) {
			for (int j = 0; j < TotalTime; j++) {
				Q_L_min[i][j] = Q_L[i][j] * 60.0;
			}
		}
	}
	else {
		//vector<vector<double>> Q_L_min(TotalDist_dummy, std::vector<double>(TotalTime_dummy));
		//vector<vector<double>> Q_half_min((TotalDist_dummy + 1), std::vector<double>(TotalTime_dummy));

		Q_half_min.resize(TotalDist_dummy + 1);
		for (int i = 0; i < (TotalDist_dummy + 1); i++) {
			Q_half_min[i].resize(TotalTime_dummy);
		}
		Q_L_min.resize(TotalDist_dummy);
		for (int i = 0; i < TotalDist_dummy; i++) {
			Q_L_min[i].resize(TotalTime_dummy);
		}
		for (int i = 0; i < (TotalDist_dummy + 1); i++) {
			for (int j = 0; j < TotalTime_dummy; j++) {
				Q_half_min[i][j] = Q_half[i][j] * 60.0;
			}
		}
		for (int i = 0; i < TotalDist_dummy; i++) {
			for (int j = 0; j < TotalTime_dummy; j++) {
				Q_L_min[i][j] = Q_L[i][j] * 60.0;
			}
		}
	}

	cout << "...done!" << endl;


	// ====================================================================================================================
	// Applying the HecRas outputs as the input data as an alternative for calculating the temperature on steady flow state
	// Jan. 18
	// First, reading in the input data from the HecRasData file

	//int	HeatTime = 0;
	//int	TravelTime = 0;
	int	Rotation = 0;
	// Periodic Boundary Condition 
	int PBC_On = pm->get_PBC_on();

	int HecRasCount = inp->getHecRas()->getCount();
	vector<double> dist_HR, Q_HR, MinChElev_HR, WSElev_HR, VelChnl_HR, FlowArea_HR, TopWidth_HR, WSSlope_HR, WP_HR;

	for (int i = 0; i <= HecRasCount; i++) {
		double temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9;
		temp1 = inp->getHecRas()->getDist(i) * 1000; // To convert form km to m
		temp2 = inp->getHecRas()->getTotalQ(i);
		temp3 = inp->getHecRas()->getChElev(i);
		temp4 = inp->getHecRas()->getWaterSurElev(i);
		temp5 = inp->getHecRas()->getVelChnl(i);
		temp6 = inp->getHecRas()->getXArea(i);
		temp7 = inp->getHecRas()->getTopWidth(i);
		temp8 = inp->getHecRas()->getWaterSurSlope(i);
		temp9 = inp->getHecRas()->getWettedPerimeter(i);

		dist_HR.push_back(temp1);
		Q_HR.push_back(temp2);
		MinChElev_HR.push_back(temp3);
		WSElev_HR.push_back(temp4);
		VelChnl_HR.push_back(temp5);
		FlowArea_HR.push_back(temp6);
		TopWidth_HR.push_back(temp7);
		WSSlope_HR.push_back(temp8);
		WP_HR.push_back(temp9);
	}

	// Interpolating the input data
	for (double x : distMod) {
		double y = interpolate(dist_HR, Q_HR, x, true);
		Q_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, MinChElev_HR, x, true);
		MinChElev_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, WSElev_HR, x, true);
		WSElev_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, VelChnl_HR, x, true);
		VelChnl_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, FlowArea_HR, x, true);
		FlowArea_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, TopWidth_HR, x, true);
		TopWidth_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, WSSlope_HR, x, true);
		WSSlope_HR_LI.push_back(y);
	}
	for (double x : distMod) {
		double y = interpolate(dist_HR, WP_HR, x, true);
		WP_HR_LI.push_back(y);
	}

	// ******************************************************************************
	// New: for steady state condition of Tannersville case study; We have 4 additional inflow. 
	// Based on new update on LAR Project, I am considering to read the inflows from Inflow.dat in place of SteadyInflow.dat
	/*
	const int InflowDates_HR = inp->getStdInf()->getCount_HR();
	vector <double> locations_HR, inflow_T0_HR, inflow_T1_HR, inflow_T2_HR, inflow_T3_HR, inflow_T4_HR, inflow_Q1_HR,
		inflow_Q2_HR, inflow_Q3_HR, inflow_Q4_HR;
	Q_Inflow_HR.resize(TotalDist_stable);
	T_Inflow_HR.resize(TotalDist_stable);
	for (int i = 0; i < TotalDist_stable; i++) {
		Q_Inflow_HR[i].resize(TotalTime_min);
		T_Inflow_HR[i].resize(TotalTime_min);
	}
	dtime_Interval = pm->get_dt();
	int PBC_loopNR = pm->get_PBC_loopNR() * 60;
	PBC_loopNR = PBC_loopNR * (60.0 / dtime_Interval);
	for (int i = 1; i <= InflowDates_HR; i++) {
		if (i == 1) {
			double temp1, temp2, temp3, temp4;
			temp1 = inp->getStdInf()->getInflowQ1_HR(i);
			temp2 = inp->getStdInf()->getInflowQ2_HR(i);
			temp3 = inp->getStdInf()->getInflowQ3_HR(i);
			//temp4 = inp->getStdInf()->getInflowQ4_HR(i);
			locations_HR.push_back(temp1 / dx_Interval);
			locations_HR.push_back(temp2 / dx_Interval);
			locations_HR.push_back(temp3 / dx_Interval);
			//locations_HR.push_back(temp4 / dx_Interval);
		}
		else {
			double temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8;
			temp0 = inp->getStdInf()->getInflowT0_HR(i);
			temp1 = inp->getStdInf()->getInflowQ1_HR(i);
			temp2 = inp->getStdInf()->getInflowQ2_HR(i);
			temp3 = inp->getStdInf()->getInflowQ3_HR(i);
			//temp4 = inp->getStdInf()->getInflowQ4_HR(i);
			temp5 = inp->getStdInf()->getInflowT1_HR(i);
			temp6 = inp->getStdInf()->getInflowT2_HR(i);
			temp7 = inp->getStdInf()->getInflowT3_HR(i);
			//temp8 = inp->getStdInf()->getInflowT4_HR(i);
			inflow_T0_HR.push_back(temp0);
			inflow_Q1_HR.push_back(temp1);
			inflow_Q2_HR.push_back(temp2);
			inflow_Q3_HR.push_back(temp3);
			//inflow_Q4_HR.push_back(temp4);
			inflow_T1_HR.push_back(temp5);
			inflow_T2_HR.push_back(temp6);
			inflow_T3_HR.push_back(temp7);
			//inflow_T4_HR.push_back(temp8);
		}
	}
	for (int j = 0; j < TotalTime_min; j++) {
		Q_Inflow_HR[locations_HR[0] - 1][j] = inflow_Q1_HR[j];
		Q_Inflow_HR[locations_HR[1] - 1][j] = inflow_Q2_HR[j];
		Q_Inflow_HR[locations_HR[2] - 1][j] = inflow_Q3_HR[j];
		//Q_Inflow_HR[locations_HR[3] - 1][j] = inflow_Q4_HR[j];
		T_Inflow_HR[locations_HR[0] - 1][j] = inflow_T1_HR[j];
		T_Inflow_HR[locations_HR[1] - 1][j] = inflow_T2_HR[j];
		T_Inflow_HR[locations_HR[2] - 1][j] = inflow_T3_HR[j];
		//T_Inflow_HR[locations_HR[3] - 1][j] = inflow_T4_HR[j];
	}
	*/
	dtime_Interval = pm->get_dt();
	int PBC_loopNR = pm->get_PBC_loopNR() * 60;
	PBC_loopNR = PBC_loopNR * (60.0 / dtime_Interval);
	vector <double> inflow_T0_HR;

	Q_Inflow_HR.resize(TotalDist_stable);
	T_Inflow_HR.resize(TotalDist_stable);
	for (int i = 0; i < TotalDist_stable; i++) {
		Q_Inflow_HR[i].resize(TotalTime);
		T_Inflow_HR[i].resize(TotalTime);
	}
	for (int j = 0; j < TotalTime; j++) {
		Q_Inflow_HR[0][j] = inflow_Discharge[0][j];
		T_Inflow_HR[0][j] = inflow_Temp[0][j];
		Q_Inflow_HR[locations[1]/dx_Interval][j] = inflow_Discharge[locations[1] - 1][j];
		T_Inflow_HR[locations[1]/dx_Interval][j] = inflow_Temp[locations[1] - 1][j];
		Q_Inflow_HR[locations[2] / dx_Interval][j] = inflow_Discharge[locations[2] - 1][j];
		T_Inflow_HR[locations[2] / dx_Interval][j] = inflow_Temp[locations[2] - 1][j];
 	}
	// ======================================================
	
	// START - LOAD MODEL VARIABLES & SETUP INITAL CONDITIONS

	cout << "Loading Variables & Initial Condition..." << endl;

	DeltaT_HR.resize(TotalDist_stable);


	// Finite difference target sections

	int TotalDist_stable_HR = TotalDist_stable - 1;

	Porosity.resize(TotalDist_stable_HR);
	for (int i = 0; i < TotalDist_stable_HR; i++)
		Porosity[i].resize(TotalTime_min);

	int TotalTime_min_HR = 0;
	int TotalTime_HR = 0;
	int TotalDist_HR = 0;
	if (calculation == 3) {
		//TotalTime_min_HR = TotalTime_min;
		TotalTime_HR = TotalTime;
		TotalDist_HR = TotalDist;
		Porosity.resize(TotalDist_stable);
		for (int i = 0; i < TotalDist_stable; i++)
			Porosity[i].resize(TotalTime_HR);
	}
	else {
		TotalTime_min_HR = 1;
		TotalDist_HR = 1;
	}


	FluxTotal_HR.resize(TotalDist_stable);
	DeltaTotal_HR.resize(TotalDist_stable);
	Temp1_HRsize2.resize(TotalDist_stable);
	DepthALL_HR.resize(TotalDist_stable);
	DepthAvgALL_HR.resize(TotalDist_stable);
	AreaALL_HR.resize(TotalDist_stable);
	VelocityALL_HR.resize(TotalDist_stable);
	WidthALL_HR.resize(TotalDist_stable);
	RetentionT_HR.resize(TotalDist_stable);
	Pw_ALL_HR.resize(TotalDist_stable);
	WSElev_ALL_HR.resize(TotalDist_stable);
	Q_Str_HR.resize(TotalDist_stable);
	HyporheicExchange_HR.resize(TotalDist_stable);
	Dispersion_HR.resize(TotalDist_stable);
	FluxConduction_HR.resize(TotalDist_stable);
	for (int i = 0; i < TotalDist_stable; i++) {
		FluxTotal_HR[i].resize(TotalTime_HR);
		DeltaTotal_HR[i].resize(TotalTime_HR);
		Temp1_HRsize2[i].resize(TotalTime_HR);
		DepthALL_HR[i].resize(TotalTime_HR);
		DepthAvgALL_HR[i].resize(TotalTime_HR);
		AreaALL_HR[i].resize(TotalTime_HR);
		VelocityALL_HR[i].resize(TotalTime_HR);
		WidthALL_HR[i].resize(TotalTime_HR);
		RetentionT_HR[i].resize(TotalTime_HR);
		Pw_ALL_HR[i].resize(TotalTime_HR);
		WSElev_ALL_HR[i].resize(TotalTime_HR);
		Q_Str_HR[i].resize(TotalTime_HR);
		HyporheicExchange_HR[i].resize(TotalTime_HR);
		Dispersion_HR[i].resize(TotalTime_HR);
		FluxConduction_HR[i].resize(TotalTime_HR);
	}
	

	Flux_Evaporation_HR.resize(TotalDist_HR);
	Flux_Conduction_HR.resize(TotalDist_HR);
	Flux_Convection_HR.resize(TotalDist_HR);
	FLux_AtmLW_HR.resize(TotalDist_HR);
	Flux_LCLW_HR.resize(TotalDist_HR);
	Flux_BackLW_HR.resize(TotalDist_HR);
	Flux_LW_HR.resize(TotalDist_HR);
	Flux_DirSW_HR.resize(TotalDist_HR);
	Flux_DiffSW_HR.resize(TotalDist_HR);
	Flux_SW_HR.resize(TotalDist_HR);
	Flux_Total_HRdist.resize(TotalDist_HR);
	Temp_HRdist.resize(TotalDist_HR);
	for (int i = 0; i < TotalDist_HR; i++) {
		Flux_Evaporation_HR[i].resize(TotalTime_HR);
		Flux_Conduction_HR[i].resize(TotalTime_HR);
		Flux_Convection_HR[i].resize(TotalTime_HR);
		FLux_AtmLW_HR[i].resize(TotalTime_HR);
		Flux_LCLW_HR[i].resize(TotalTime_HR);
		Flux_BackLW_HR[i].resize(TotalTime_HR);
		Flux_LW_HR[i].resize(TotalTime_HR);
		Flux_DirSW_HR[i].resize(TotalTime_HR);
		Flux_DiffSW_HR[i].resize(TotalTime_HR);
		Flux_SW_HR[i].resize(TotalTime_HR);
		Flux_Total_HRdist[i].resize(TotalTime_HR);
		Temp_HRdist[i].resize(TotalTime_HR);
	}


	Flux_Evaporation_Nodes.resize(TotalDist_stable_HR);
	Flux_Conduction_Nodes.resize(TotalDist_stable_HR);
	Flux_Convection_Nodes.resize(TotalDist_stable_HR);
	FLux_AtmLW_Nodes.resize(TotalDist_stable_HR);
	Flux_LCLW_Nodes.resize(TotalDist_stable_HR);
	Flux_BackLW_Nodes.resize(TotalDist_stable_HR);
	Flux_LW_Nodes.resize(TotalDist_stable_HR);
	Flux_DirSW_Nodes.resize(TotalDist_stable_HR);
	Flux_DiffSW_Nodes.resize(TotalDist_stable_HR);
	Flux_SW_Nodes.resize(TotalDist_stable_HR);
	for (int i = 0; i < (TotalDist_stable_HR); i++) {
		Flux_Evaporation_Nodes[i].resize(TotalTime_HR);
		Flux_Conduction_Nodes[i].resize(TotalTime_HR);
		Flux_Convection_Nodes[i].resize(TotalTime_HR);
		FLux_AtmLW_Nodes[i].resize(TotalTime_HR);
		Flux_LCLW_Nodes[i].resize(TotalTime_HR);
		Flux_BackLW_Nodes[i].resize(TotalTime_HR);
		Flux_LW_Nodes[i].resize(TotalTime_HR);
		Flux_DirSW_Nodes[i].resize(TotalTime_HR);
		Flux_DiffSW_Nodes[i].resize(TotalTime_HR);
		Flux_SW_Nodes[i].resize(TotalTime_HR);
	}

	calcT_Temp.resize(TotalDist_stable);

	// ======================================================

	int distanceHR = TotalDist;
	vector<double> Hec_Dist;
	int counterHR = 0;

	if (calculation == 3) {
		for (int i = 0; i < TotalTime; i++) {

			while (distanceHR > 0)
			{
				Hec_Dist.push_back(TotalDist-distanceHR);

				WidthALL_HR[counterHR][i] = TopWidth_HR_LI[counterHR * dx_Interval];
				DepthALL_HR[counterHR][i] = WSElev_HR_LI[counterHR * dx_Interval] - MinChElev_HR_LI[counterHR * dx_Interval];
				DepthAvgALL_HR[counterHR][i] = FlowArea_HR_LI[counterHR * dx_Interval] / TopWidth_HR_LI[counterHR * dx_Interval];
				Q_Str_HR[counterHR][i] = Q_HR_LI[counterHR * dx_Interval];
				VelocityALL_HR[counterHR][i] = VelChnl_HR_LI[counterHR * dx_Interval];
				AreaALL_HR[counterHR][i] = FlowArea_HR_LI[counterHR * dx_Interval];
				RetentionT_HR[counterHR][i] = dx_Interval / VelChnl_HR_LI[counterHR * dx_Interval];
				//Pw_ALL_HR[counterHR][i] = secWidth_LI[counterHR * dx_Interval] + 2.0 * DepthALL_HR[counterHR][0] * sqrt(1.0 + pow(Z_LI[counterHR * dx_Interval], 2.0));
				Pw_ALL_HR[counterHR][i] = WP_HR_LI[counterHR * dx_Interval];
				WSElev_ALL_HR[counterHR][i] = WSElev_HR_LI[counterHR * dx_Interval] + (WSSlope_HR_LI[counterHR * dx_Interval] * ((TotalDist - distanceHR) - Hec_Dist[counterHR]));


				distanceHR = distanceHR - dx_Interval;
				counterHR++;
			}
			distanceHR = TotalDist;
			Hec_Dist.resize(0);
			counterHR = 0;
		}
	}



	if (calculation == 1) { 
		cout << endl << "Solving the Crank-Nicolson method..." << endl << endl; 
		AddLogComment("Solving the Crank-Nicolson method...");
	
	}
	if (calculation == 2) {
		cout << endl << "Solving the Explicit finite difference method..." << endl << endl;
		AddLogComment("Solving the Explicit finite difference method...");
	}
	if (calculation == 3) { 
		cout << endl << "Solving the HEC-RAS based method..." << endl << endl; 
		AddLogComment("Solving the HEC-RAS based method...");
	}
	if (calculation == 4) {
		cout << endl << "Solving the Runge-Kutta method..." << endl << endl;
		AddLogComment("Solving the Runge-Kutta method...");
	}


	// ================== SW calculation condition 
	SolvingMethod = pm->get_SW_method();
	if (SolvingMethod == 1) { 
		cout << endl << "Solving SW/LW Rad. Flux based on Sky View Factor and provided heights..." << endl << endl; 
		AddLogComment("Solving SW/LW Rad. Flux based on Sky View Factor and provided heights...");
	}
	if (SolvingMethod == 2) { 
		cout << endl << "Solving SW/LW Rad. Flux based on fixed coverage percentage values..." << endl << endl; 
		AddLogComment("Solving SW/LW Rad. Flux based on fixed coverage percentage values...");
	}
	// =============================================
	SedimentMethod = pm->get_Sediment_method();
	if (SedimentMethod == 1) { 
		cout << endl << "Solving sediment flux based on RBM model..." << endl << endl; 
		AddLogComment("Solving sediment flux based on RBM model...");
	}
	if (SedimentMethod == 2) { 
		cout << endl << "Solving sediment flux based on Heat Source model..." << endl << endl; 
		AddLogComment("Solving sediment flux based on Heat Source model...");
	}


	// For the Crank-Nicolson method
	int TotalDist_CN = 0;
	int TotalTime_CN = 0;
	if (calculation == 1) {
		TotalDist_CN = TotalDist;
		TotalTime_CN = TotalTime;
	}
	else {
		TotalDist_CN = 1;
		TotalTime_CN = 1;
	}
	SWDir_2D.resize(TotalDist_CN);
	SWDiff_2D.resize(TotalDist_CN);
	SW_2D.resize(TotalDist_CN);
	atmLW_2D.resize(TotalDist_CN);
	LCLW_2D.resize(TotalDist_CN);
	backLW_2D.resize(TotalDist_CN);
	LW_2D.resize(TotalDist_CN);
	Latent_2D.resize(TotalDist_CN);
	Sensible_2D.resize(TotalDist_CN);
	Bed_2D.resize(TotalDist_CN);
	heat_flux_2D.resize(TotalDist_CN);
	for (int i = 0; i < TotalDist_CN; i++) {
		SWDir_2D[i].resize(TotalTime_CN);
		SWDiff_2D[i].resize(TotalTime_CN);
		SW_2D[i].resize(TotalTime_CN);
		atmLW_2D[i].resize(TotalTime_CN);
		LCLW_2D[i].resize(TotalTime_CN);
		backLW_2D[i].resize(TotalTime_CN);
		LW_2D[i].resize(TotalTime_CN);
		Latent_2D[i].resize(TotalTime_CN);
		Sensible_2D[i].resize(TotalTime_CN);
		Bed_2D[i].resize(TotalTime_CN);
		heat_flux_2D[i].resize(TotalTime_CN);
	}
	// ANALYSING THE ENTERIOR RESULTS AND VECTOR - REZA
	vector<vector<double>> a_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> b_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> c_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> o(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> p(TotalDist_CN, std::vector<double>(TotalTime_CN));						// intermediate matrices to get b
	vector<vector<double>> q(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> o_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> p_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> q_c(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> d(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> g(TotalDist_CN, std::vector<double>(TotalTime_CN));				 // Pre - allocate g, k, and m arrays
	vector<vector<double>> k(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> m(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> A(TotalDist_CN, std::vector<double>(TotalDist_CN + 1)); // the last column is for Solving linear equations with Gaussian elimination
	vector<vector<double>> a(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> b(TotalDist_CN, std::vector<double>(TotalTime_CN));
	vector<vector<double>> c(TotalDist_CN, std::vector<double>(TotalTime_CN));

	// ===================================================================

	// required for Crank-Nicolson method
	int startingHour = pm->get_starting_hour();

	double initialT = pm->get_initial_temp();					// set initial temperature condition
	//int TotalTimeMin = TotalTime * 60;

	vector<int> timeRepeatedHour;
	vector<double> initialT_T0(TotalDist);

	//required for Runge-Kutta method
	int TotalDist_RK = 0;
	int TotalTime_RK = 0;
	if (calculation == 4) {
		TotalDist_RK = TotalDist;
		TotalTime_RK = TotalTime;
	}
	else {
		TotalDist_RK = 1;
		TotalTime_RK = 1;
	}
	vector<vector<double>> T_k1(TotalDist_RK, std::vector<double>(TotalTime_RK)); // pre-allocate arrays for temperature at intermediate times
	vector<vector<double>> heat_flux_k1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> heat_flux_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> u1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> v1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> s1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> m1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> k1(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> u2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> v2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> s2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> m2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> SWDir_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> SWDiff_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> SW_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> atmLW_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> LCLW_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> backLW_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> LW_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> Latent_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> Sensible_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));
	vector<vector<double>> Bed_2D_k2(TotalDist_RK, std::vector<double>(TotalTime_RK));


	int TotalDist_FD = 0;
	int TotalTime_FD = 0;
	if (calculation == 2) {
		TotalDist_FD = TotalDist;
		TotalTime_FD = TotalTime;
		TotalTime_Uns_FD = TotalTime * 60;
	}
	else {
		TotalDist_FD = 1;
		TotalTime_FD = 1;
		TotalTime_Uns_FD = 1;
	}

	Flux_Total.resize(TotalDist_FD);
	Flux_Conduction.resize(TotalDist_FD);
	Flux_Evaporation.resize(TotalDist_FD);
	Flux_Convection.resize(TotalDist_FD);
	FLux_AtmLW.resize(TotalDist_FD);
	Flux_LCLW.resize(TotalDist_FD);
	Flux_BackLW.resize(TotalDist_FD);
	Flux_LW.resize(TotalDist_FD);
	Flux_DirSW.resize(TotalDist_FD);
	Flux_DiffSW.resize(TotalDist_FD);
	Flux_SW.resize(TotalDist_FD);
	T_Uns.resize(TotalDist_FD);
	depth_Uns.resize(TotalDist_FD);
	for (int i = 0; i < TotalDist_FD; i++) {
		Flux_Total[i].resize(TotalTime_Uns_FD);
		Flux_Conduction[i].resize(TotalTime_Uns_FD);
		Flux_Evaporation[i].resize(TotalTime_Uns_FD);
		Flux_Convection[i].resize(TotalTime_Uns_FD);
		FLux_AtmLW[i].resize(TotalTime_Uns_FD);
		Flux_LCLW[i].resize(TotalTime_Uns_FD);
		Flux_BackLW[i].resize(TotalTime_Uns_FD);
		Flux_LW[i].resize(TotalTime_Uns_FD);
		Flux_DirSW[i].resize(TotalTime_Uns_FD);
		Flux_DiffSW[i].resize(TotalTime_Uns_FD);
		Flux_SW[i].resize(TotalTime_Uns_FD);
		T_Uns[i].resize(TotalTime_Uns_FD);
		depth_Uns[i].resize(TotalTime_Uns_FD);
	}


	hour_Flux_Total.resize(TotalDist_stable);
	hour_Flux_Conduction.resize(TotalDist_stable);
	hour_Flux_Evaporation.resize(TotalDist_stable);
	hour_Flux_Convection.resize(TotalDist_stable);
	hour_FLux_AtmLW.resize(TotalDist_stable);
	hour_Flux_LCLW.resize(TotalDist_stable);
	hour_Flux_BackLW.resize(TotalDist_stable);
	hour_Flux_LW.resize(TotalDist_stable);
	hour_Flux_DirSW.resize(TotalDist_stable);
	hour_Flux_DiffSW.resize(TotalDist_stable);
	hour_Flux_SW.resize(TotalDist_stable);
	hour_T_Uns.resize(TotalDist_stable);
	hour_depth_Uns.resize(TotalDist_stable);
	for (int i = 0; i < TotalDist_stable; i++) {
		hour_Flux_Total[i].resize(TotalTime);
		hour_Flux_Conduction[i].resize(TotalTime);
		hour_Flux_Evaporation[i].resize(TotalTime);
		hour_Flux_Convection[i].resize(TotalTime);
		hour_FLux_AtmLW[i].resize(TotalTime);
		hour_Flux_LCLW[i].resize(TotalTime);
		hour_Flux_BackLW[i].resize(TotalTime);
		hour_Flux_LW[i].resize(TotalTime);
		hour_Flux_DirSW[i].resize(TotalTime);
		hour_Flux_DiffSW[i].resize(TotalTime);
		hour_Flux_SW[i].resize(TotalTime);
		hour_T_Uns[i].resize(TotalTime);
		hour_depth_Uns[i].resize(TotalTime);
	}




	int counterSec = 0;
	int counterWriter = 0;
	int counterHourly = 0;
	int minCounter = 60 / dtime_unsteady;
	// Calculating the sky view factors for the East and West banks and the magnitude of the TSA, VSA & BSA
	skyViewE();
	skyViewW();


	switch (calculation) {
	case 1:

		vector<vector<double>>().swap(T_k1);
		vector<vector<double>>().swap(heat_flux_k1);
		vector<vector<double>>().swap(heat_flux_k2);
		vector<vector<double>>().swap(u1);
		vector<vector<double>>().swap(v1);
		vector<vector<double>>().swap(s1);
		vector<vector<double>>().swap(m1);
		vector<vector<double>>().swap(k1);
		vector<vector<double>>().swap(u2);
		vector<vector<double>>().swap(v2);
		vector<vector<double>>().swap(s2);
		vector<vector<double>>().swap(m2);
		vector<vector<double>>().swap(k2);
		vector<vector<double>>().swap(SWDir_2D_k2);
		vector<vector<double>>().swap(SWDiff_2D_k2);
		vector<vector<double>>().swap(SW_2D_k2);
		vector<vector<double>>().swap(atmLW_2D_k2);
		vector<vector<double>>().swap(LCLW_2D_k2);
		vector<vector<double>>().swap(backLW_2D_k2);
		vector<vector<double>>().swap(LW_2D_k2);
		vector<vector<double>>().swap(Latent_2D_k2);
		vector<vector<double>>().swap(Sensible_2D_k2);
		vector<vector<double>>().swap(Bed_2D_k2);

		// STEP 5 : Calculate coefficients of the tridiagonal matrix(a, b, c)
		//  and set coefficients at the boundaries. Use a, b and c to create the A matrix.
		//   Note that a, b and c are constant in time as long as Q, volume, and Q_L are constant with time.
		//   ===================> Solving the Crank-Nicolson method 
		// coefficient matrices 
		// pieces of equation for the future temperature

		for (int i = 0; i < TotalDist; i++) {
			for (int j = 0; j < (TotalTime - 1); j++) {
				a[i][j] = (-dt * Q_half_min[i][j + 1]) / (4.0 * volume[i][0]);      // subdiagonal: coefficients of Tn - 1
				o[i][j] = (dt * Q_half_min[i][j + 1]) / ((4.0 * volume[i][0]));     // intermediate steps to get b
				p[i][j] = (dt * Q_half_min[i + 1][j + 1]) / ((4.0 * volume[i][0]));
				q[i][j] = (dt * Q_L_min[i][j + 1]) / ((2.0 * volume[i][0]));
				b[i][j] = 1.0 + o[i][j] - p[i][j] + q[i][j];                    // diagonal: coefficients of Tn
				c[i][j] = (dt * Q_half_min[i + 1][j + 1]) / (4 * volume[i][0]);  // superdiagonal: coefficients of Tn+1
			}
			// for last values since we don't know the future we just reuse the last known
			a[i][TotalTime - 1] = (-dt * Q_half_min[i][TotalTime - 1]) / (4.0 * volume[i][0]);  // subdiagonal: coefficients of Tn-1
			o[i][TotalTime - 1] = (dt * Q_half_min[i][TotalTime - 1]) / ((4.0 * volume[i][0]));
			p[i][TotalTime - 1] = (dt * Q_half_min[i + 1][TotalTime - 1]) / ((4.0 * volume[i][0]));
			q[i][TotalTime - 1] = (dt * Q_L_min[i][TotalTime - 1]) / ((2.0 * volume[i][0]));
			b[i][TotalTime - 1] = 1.0 + o[i][TotalTime - 1] - p[i][TotalTime - 1] + q[i][TotalTime - 1];  // diagonal: coefficients of Tn
			c[i][TotalTime - 1] = (dt*Q_half_min[i + 1][TotalTime - 1]) / (4.0 * volume[i][TotalTime - 1]);  // superdiagonal: coefficients of Tn+1
		}
		// pieces of equation for the current temperature to make d(new)
		for (int i = 0; i < TotalDist; i++) {
			for (int j = 0; j < TotalTime; j++) {
				a_c[i][j] = (-dt * Q_half_min[i][j]) / (4 * volume[i][0]);      // subdiagonal: coefficients of Tn - 1
				o_c[i][j] = (dt * Q_half_min[i][j]) / ((4 * volume[i][0]));     // intermediate steps to get b
				p_c[i][j] = (dt * Q_half_min[i + 1][j]) / ((4 * volume[i][0]));
				q_c[i][j] = (dt * Q_L_min[i][j]) / ((2 * volume[i][0]));
				b_c[i][j] = 1.0 + o_c[i][j] - p_c[i][j] + q_c[i][j];                    // diagonal: coefficients of Tn
				c_c[i][j] = (dt * Q_half_min[i + 1][j]) / (4 * volume[i][0]);  // superdiagonal: coefficients of Tn+1
			}
		}



		// STEP 6: Calculate right hand side(d).
		// The values for d are temperature - dependent, so they change each time step.
		// Once d is computed, use that d value and the
		// matrix A to solve for the temperature for each time step.

		// set temperatures for first time step at input values
		T.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			T[i].resize(TotalTime);
			T[i][0] = initialT;
		}
		for (int i = 0; i < TotalDist; i++) { initialT_T0[i] = initialT; }


		// Shortwave calculatin for the first time step:
		solarReflectivity();

		adjustedDirRadE(solarSW_Dir_LI, 0); // preparing the adjustedDirSW_E vector
		adjustedDirRadW(solarSW_Dir_LI, 0); // preparing the adjustedDirSW_W vector 
		netSolarDiffRadE(solarSW_Diff_LI, 0);  // preparing the adjustedDiffSW_E vector
		netSolarDiffRadW(solarSW_Diff_LI, 0);  // preparing the adjustedDiffSW_W vector


		// Insert values for first time step.
		for (int i = 0; i < TotalDist; i++) {
			if (hourList_LI[0] >= 0 && hourList_LI[0] < 12) {
				SWDir_2D[i][0] = adjustedDirSW_E[i];
				SWDiff_2D[i][0] = adjustedDiffSW_E[i];
			}
			else {
				SWDir_2D[i][0] = adjustedDirSW_W[i];
				SWDiff_2D[i][0] = adjustedDiffSW_W[i];
			}
			SW_2D[i][0] = SWDir_2D[i][0] + SWDiff_2D[i][0];
		}


		// Longwave radiation for the first time step
		longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, 0);
		// latent heat in the fist time step
		latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, 0);
		// Sensible heat for the first time step
		sensibleHeat(airTemp_LI, initialT_T0, windSp_LI, real_humidity_LI, 0);
		// Stream Bed heat for the first time step
		bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, 0);

		//// Insert values for first time step.
		for (int i = 0; i < TotalDist; i++) {
			heat_flux_2D[i][0] = (SW_2D[i][0] + LW_2D[i][0] + Latent_2D[i][0] + Sensible_2D[i][0] + Bed_2D[i][0]) * 60;
		}

		for (int i = 0; i < TotalDist; i++) {
			for (int j = 0; j < TotalTime; j++) {
				g[i][j] = 1.0 + a_c[i][j] + c_c[i][j] - q_c[i][j];
				if (Q_L_min[i][j] < 0) {
					k[i][j] = 0;
				}
				else {
					k[i][j] = ((dt * Q_L_min[i][j]) / volume[i][j]);
				}
			}
		}

		// ========================== main calculations ======================
		for (int j = 0; j < TotalTime; j++) {
			if (j == (TotalTime - 1)) {}
			else {
				for (int i = 0; i < TotalDist; i++) {
					m[i][j] = (dt * (width_total[i][j] * heat_flux_2D[i][j]) / (rho_water*c_water) / area_total[i][j]);
				}
				// set upper boundary of reach
				d[0][j] = ((g[0][j] * T[0][j]) + (o_c[0][j] * obs_xo_LI[j]) - (p_c[0][j] * T[1][j]) + (k[0][j] * sedimentDist_LI[0])
					+ m[0][j]) - (a_c[0][j] * obs_xo_LI[j + 1]);
				// set lower boundary of reach
				d[TotalDist - 1][j] = (g[TotalDist - 1][j] * T[TotalDist - 1][j]) + (o_c[TotalDist - 1][j] * T[(TotalDist - 2)][j])
					- (p_c[TotalDist - 1][j] * T[TotalDist - 1][j]) + (k[TotalDist - 1][j] * sedimentDist_LI[TotalDist - 1])
					+ m[TotalDist - 1][j];
				for (int i = 1; i < (TotalDist - 1); i++) {
					d[i][j] = (g[i][j] * T[i][j]) + (o_c[i][j] * T[i - 1][j]) - (p_c[i][j] * T[i + 1][j]) + (k[i][j]
						* sedimentDist_LI[i]) + m[i][j];
				}

				for (int i = 0; i < (TotalDist - 1); i++) {
					A[i + 1][i] = a[i + 1][j];
					A[i][i] = b[i][j];
					A[i][i + 1] = c[i][j];

					// This creates a specified temperature gradient of dT / dx = 0 at the downtream node.In other words, T(r) = T(r + 1),
					// with T(r + 1) being a dummy cell after the model reach.
				}
				A[TotalDist - 1][TotalDist - 1] = b[TotalDist - 1][j] + c[TotalDist - 1][j];

				for (int i = 0; i < TotalDist; i++) {//*************************
					A[i][TotalDist] = d[i][j];
				}

				// ================================ Solving linear equations with Gaussian elimination for Ax=B linear equation ======
				// Here the A is the A[TotalDist][TotalDist] 2D vector, x is the T and B is the d (but just 1 column for both)
				// https://martin-thoma.com/solving-linear-equations-with-gaussian-elimination/
				// copying the target column of d to the A, this way we will have a A[TotalDist][TotalDist+1] matrix

				x = gauss(A);
				for (int i = 0; i < TotalDist; i++) {
					for (int j = 0; j <= TotalDist; j++) {
						A[i][j] = 0;
					}
				}

				for (int i = 0; i < TotalDist; i++) {
					T[i][(j + 1)] = x[i];
				}
				for (int i = 0; i < TotalDist; i++) { initialT_T0[i] = T[i][j + 1]; }

				// For debugging!
				//float average = accumulate(initialT_T0.begin(), initialT_T0.end(), 0.0) / initialT_T0.size();
				//cout << "*** The Average of the initialT_T0:  " << average << endl;
				//std::string commentAverage = "*** The Average of the initialT_T0:  "+std::to_string(average);
				//AddLogComment(commentAverage);
				




				// =============================== Gaussian elimination for Ax=B linear equation done! ==========================
				// =============================== Next time step (j+1) calculations
				adjustedDirRadE(solarSW_Dir_LI, (j + 1)); // preparing the adjustedDirSW_E vector
				adjustedDirRadW(solarSW_Dir_LI, (j + 1)); // preparing the adjustedDirSW_W vector 
				netSolarDiffRadE(solarSW_Diff_LI, (j + 1));  // preparing the adjustedDiffSW_E vector
				netSolarDiffRadW(solarSW_Diff_LI, (j + 1));  // preparing the adjustedDiffSW_W vector
				// Longwave radiation for the first time step
				for (int i = 0; i < TotalDist; i++) {
					if (hourList_LI[j] >= 0 && hourList_LI[j] < 12) {
						SWDir_2D[i][(j + 1)] = adjustedDirSW_E[i];
						SWDiff_2D[i][(j + 1)] = adjustedDiffSW_E[i];
					}
					else {
						SWDir_2D[i][(j + 1)] = adjustedDirSW_W[i];
						SWDiff_2D[i][(j + 1)] = adjustedDiffSW_W[i];
					}
					SW_2D[i][(j + 1)] = SWDir_2D[i][(j + 1)] + SWDiff_2D[i][(j + 1)];
				}
				longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, (j + 1));
				// latent heat in the fist time step
				latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, (j + 1));
				// Sensible heat for the first time step
				sensibleHeat(airTemp_LI, initialT_T0, windSp_LI, real_humidity_LI, (j + 1));
				// Stream Bed heat for the first time step
				bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, (j + 1));

				for (int i = 0; i < TotalDist; i++) {
					heat_flux_2D[i][(j + 1)] = (SW_2D[i][(j + 1)] + LW_2D[i][(j + 1)] + Latent_2D[i][(j + 1)]
						+ Sensible_2D[i][(j + 1)] + Bed_2D[i][(j + 1)])*60;
				}
				
				cout << j << " time step out of " << TotalTime << " completed." << endl;
				AddLogComment(std::to_string(j)+ " time step out of " + std::to_string(TotalTime) + " completed.");
			}
		
		}

		t_minBased.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			t_minBased[i].resize(TotalTime * 60);
		}
		for (int i = 0; i < TotalDist; i++) {
			//vector<double> t_minBased_temp(TotalTime);
			vector<double> T_temp(TotalTime);
			for (int j = 0; j < TotalTime; j++) {
				T_temp[j] = T[i][j];
			}
			for (double x = 0; x < (TotalTime * 60); x++) {
				double y = interpolate(hourlyTime, T_temp, x, true);
				t_minBased[i][x] = y;
			}

		}

		cout << "... Crank-Nicolson modeling methodology is done!" << endl;
		AddLogComment("... Crank-Nicolson modeling methodology is done!");
	
		break;

		case 2:

		// Removing the required vectors for case 1 and 2 to reduce the amount of memory usage
		vector<vector<double>>().swap(T_k1);
		vector<vector<double>>().swap(heat_flux_k1);
		vector<vector<double>>().swap(heat_flux_k2);
		vector<vector<double>>().swap(u1);
		vector<vector<double>>().swap(v1);
		vector<vector<double>>().swap(s1);
		vector<vector<double>>().swap(m1);
		vector<vector<double>>().swap(k1);
		vector<vector<double>>().swap(u2);
		vector<vector<double>>().swap(v2);
		vector<vector<double>>().swap(s2);
		vector<vector<double>>().swap(m2);
		vector<vector<double>>().swap(k2);
		vector<vector<double>>().swap(SWDir_2D_k2);
		vector<vector<double>>().swap(SWDiff_2D_k2);
		vector<vector<double>>().swap(SW_2D_k2);
		vector<vector<double>>().swap(atmLW_2D_k2);
		vector<vector<double>>().swap(LCLW_2D_k2);
		vector<vector<double>>().swap(backLW_2D_k2);
		vector<vector<double>>().swap(LW_2D_k2);
		vector<vector<double>>().swap(Latent_2D_k2);
		vector<vector<double>>().swap(Sensible_2D_k2);
		vector<vector<double>>().swap(Bed_2D_k2);

		vector<vector<double>>().swap(a_c);
		vector<vector<double>>().swap(b_c);
		vector<vector<double>>().swap(c_c);
		vector<vector<double>>().swap(o);
		vector<vector<double>>().swap(p);
		vector<vector<double>>().swap(q);
		vector<vector<double>>().swap(o_c);
		vector<vector<double>>().swap(p_c);
		vector<vector<double>>().swap(q_c);
		vector<vector<double>>().swap(d);
		vector<vector<double>>().swap(g);
		vector<vector<double>>().swap(k);
		vector<vector<double>>().swap(m);
		vector<vector<double>>().swap(A);
		vector<vector<double>>().swap(a);
		vector<vector<double>>().swap(b);
		vector<vector<double>>().swap(c);


		// Calculating the unsteady state using the McCormick and Explicit Finite Difference methodologies
		// Using the formulation form Boyd & Kasper (2003) 
		// www.oregon.gov/deq/FilterDocs/heatsourcemanual.pdf

		// ======================================================
		// START - LOAD MODEL VARIABLES & SETUP INITAL CONDITIONS
		cout << "Loading Variables & Initial Condition..." << endl;
		AddLogComment("Loading Variables & Initial Condition...");
		Q.resize(2);
		Temp_unsteady.resize(2);
		for (int i = 0; i < (2); i++) {
			Q[i].resize(TotalDist_stable + 1);
			Temp_unsteady[i].resize(TotalDist_stable + 1);
		}
		depth_unsteady.resize(TotalDist_stable);
		AreaX.resize(TotalDist_stable);
		velocity_unsteady.resize(TotalDist_stable);
		for (int i = 0; i < TotalDist_stable; i++) {
			depth_unsteady[i].resize(2);
			AreaX[i].resize(2);
			velocity_unsteady[i].resize(2);
		}
		Pw_unsteady.resize(TotalDist_stable);
		width_UnsTotal.resize(TotalDist_stable);
		depth_AvgUns.resize(TotalDist_stable);
		Hyporheic_Exchange.resize(TotalDist_stable);
		Rh_unsteady.resize(TotalDist_stable);
		Flag_SkipNode.resize(TotalDist_stable);

		// ======================================================
		// Sky to view and TSA, VSA & BSA adjusted to unsteady dx

		if (SolvingMethod == 1) {
			SkyToView_UnsE.resize(TotalDist_stable);
			SkyToView_UnsW.resize(TotalDist_stable);
			int count_uns = 0;
			for (int i = 0; i < TotalDist_stable; i++) {
				SkyToView_UnsE[i] = SkyV_E[count_uns];
				SkyToView_UnsW[i] = SkyV_W[count_uns];
				count_uns = (count_uns + dx_unsteady) - 1;
			}
		}
		else {
			SkyToView_UnsE.resize(TotalDist_stable);
			SkyToView_UnsW.resize(TotalDist_stable);
			SF_LI_Uns.resize(TotalDist_stable);
			int count_uns = 0;
			for (int i = 0; i < TotalDist_stable; i++) {
				SkyToView_UnsE[i] = SkyToView_LI[count_uns];
				SkyToView_UnsW[i] = SkyToView_LI[count_uns];
				SF_LI_Uns[i] = SF_LI[count_uns];

				count_uns = (count_uns + dx_unsteady) - 1;
			}
		}

		// ======================================================
		Node_Uns = 0;
		double distance;
		distance = TotalDist;
		time_Uns = 0;
		flag_BC = 1;

		Q_In.resize(TotalDist_stable);
		T_In.resize(TotalDist_stable);
		for (int i = 0; i < TotalDist_stable; i++) {
			Q_In[i].resize(TotalTime_min);
			T_In[i].resize(TotalTime_min);
		}

		for (int i = 0; i < TotalDist_stable; i++) {
			for (int j = 0; j < TotalTime_min; j++) {
				Q_In[i][j] = inflow_Rate[i][j];
				T_In[i][j] = inflow_Temp_Uns[i][j];
			}
		}

		while (distance >= 0) {

			initialConditions(Node_Uns);

			distance = distance - dx_unsteady;
			Node_Uns++;
			flag_BC = 0;
		}

		// ======================================================
		// END LOAD MODEL VARIABLES & SETUP INITAL CONDITIONS

		// ======================================================
		// START MACCORMICK HEAT/MASS TRANSFER MODELS
		for (int theTime = 0; theTime < TotalTime_min; theTime++) {

			hydroStability();
			// ===========================================================
			// Reset Counters, Flags
			Node_Uns = 0;
			flag_BC = 1;
			distance = TotalDist;
			T_unsTemporary.resize(TotalDist_stable);
			// ===========================================================

			while (distance >= 0) {
				hydraulics(Node_Uns, theTime);

				adjustedDirRadE_Uns(DirSW_Uns, theTime, Node_Uns);
				adjustedDirRadW_Uns(DirSW_Uns, theTime, Node_Uns);
				netSolarDiffRadE_Uns(DiffSW_Uns, theTime, Node_Uns);
				netSolarDiffRadW_Uns(DiffSW_Uns, theTime, Node_Uns);

				if (startingHour >= 0 && startingHour < 12) {
					DirSW_Uns_temp = DirSW_UnsE;
					DiffSW_Uns_temp = DiffSW_UnsE;
				}
				else {
					DirSW_Uns_temp = DirSW_UnsW;
					DiffSW_Uns_temp = DiffSW_UnsW;
				}
				SW_Uns = DiffSW_Uns_temp + DirSW_Uns_temp;

				longWaveRadiation_Uns(airTemp_Uns, RH_Uns, Cloadiness_Uns, theTime, Node_Uns);
				latentHeat_Uns(airTemp_Uns, RH_Uns, wndSpd_Uns, theTime, Node_Uns);
				sensibleHeat_Uns(airTemp_Uns, wndSpd_Uns, RH_Uns, theTime, Node_Uns);
				//bedSediment_Uns(K_sedType_LI, sedTemp_Uns, depth_AvgUns, theTime, Node_Uns);

				if (SedimentMethod == 1) {
					bedSediment_Uns(K_sedType_LI, sedTemp_Uns, depth_AvgUns, theTime, Node_Uns);
				}
				if (SedimentMethod == 2) {
					bedSedimentHS(sedTemp_Uns, theTime, Node_Uns);
				}


				Flux_Total_Time[Node_Uns] = SW_Uns + LW_Uns + latent_Uns + Sensible_Uns + bed_Uns;
				Flux_Conduction_Time[Node_Uns] = bed_Uns;
				Flux_Evaporation_Time[Node_Uns] = latent_Uns;
				Flux_Convection_Time[Node_Uns] = Sensible_Uns;
				FLux_AtmLW_Time[Node_Uns] = LW_Atm_Uns;
				Flux_LCLW_Time[Node_Uns] = LW_LC_Uns;
				Flux_BackLW_Time[Node_Uns] = LW_Back_Uns;
				Flux_LW_Time[Node_Uns] = LW_Atm_Uns + LW_LC_Uns + LW_Back_Uns;
				Flux_DirSW_Time[Node_Uns] = DirSW_Uns_temp;
				Flux_DiffSW_Time[Node_Uns] = DiffSW_Uns_temp;
				Flux_SW_Time[Node_Uns] = SW_Uns;

				// Delta_T here is a variable which refers to the 3rd part of the equation #2-119 & #2-121 in Boyd and Kasper (2003) document
				Delta_T[Node_Uns] = Flux_Total_Time[Node_Uns] / (depth_AvgUns[Node_Uns] * rho_water * c_water);

				flag_BC = 0;
				distance = distance - dx_unsteady;
				Node_Uns = Node_Uns + 1;

			}

			McCormick_Temp1(Delta_T, theTime);
			McCormick_Temp2(Delta_T, theTime);

			// Reset flags
			for (int i = 0; i < TotalDist_stable; i++) {
				Q[0][i] = Q[1][i];
				AreaX[i][0] = AreaX[i][1];
				depth_unsteady[i][0] = depth_unsteady[i][1];
				depth_Uns_temp[i] = depth_unsteady[i][1];
			}
			if (counterSec % minCounter == 0) {
				// writing the results
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_Total_Time, x, true);
					Flux_Total[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_Conduction_Time, x, true);
					Flux_Conduction[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_Evaporation_Time, x, true);
					Flux_Evaporation[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_Convection_Time, x, true);
					Flux_Convection[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, FLux_AtmLW_Time, x, true);
					FLux_AtmLW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_LCLW_Time, x, true);
					Flux_LCLW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_BackLW_Time, x, true);
					Flux_BackLW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_LW_Time, x, true);
					Flux_LW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_DirSW_Time, x, true);
					Flux_DirSW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_DiffSW_Time, x, true);
					Flux_DiffSW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, Flux_SW_Time, x, true);
					Flux_SW[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, T_unsTemporary, x, true);
					T_Uns[x][counterWriter] = y;
				}
				for (double x = 0; x < TotalDist; x++) {
					double y = interpolate(Nodes_Uns, depth_Uns_temp, x, true);
					depth_Uns[x][counterWriter] = y;
				}

				counterWriter++;
			}

			if (counterSec % (60 * minCounter) == 0) {
				for (int i = 0; i < TotalDist_stable; i++) {
					hour_Flux_Total[i][counterHourly] = Flux_Total_Time[i];
					hour_Flux_Conduction[i][counterHourly] = Flux_Conduction_Time[i];
					hour_Flux_Evaporation[i][counterHourly] = Flux_Evaporation_Time[i];
					hour_Flux_Convection[i][counterHourly] = Flux_Convection_Time[i];
					hour_FLux_AtmLW[i][counterHourly] = FLux_AtmLW_Time[i];
					hour_Flux_LCLW[i][counterHourly] = Flux_LCLW_Time[i];
					hour_Flux_BackLW[i][counterHourly] = Flux_BackLW_Time[i];
					hour_Flux_LW[i][counterHourly] = Flux_LW_Time[i];
					hour_Flux_DirSW[i][counterHourly] = Flux_DirSW_Time[i];
					hour_Flux_DiffSW[i][counterHourly] = Flux_DiffSW_Time[i];
					hour_Flux_SW[i][counterHourly] = Flux_SW_Time[i];
					hour_T_Uns[i][counterHourly] = T_unsTemporary[i];
					hour_depth_Uns[i][counterHourly] = depth_Uns_temp[i];
				}
				counterHourly++;
			}

			counterSec++;
			if (counterSec >= (60 * (60 / dtime_unsteady))) {
				startingHour++;
				counterSec = 0;
			}
			if (startingHour >= 24) { startingHour = 0; }
			
			cout << theTime << " time step out of " << TotalTime_min << " completed." << endl;
			AddLogComment(std::to_string(theTime) + " time step out of " + std::to_string(TotalTime_min) + " completed.");
		}

	break;

	case 3:

		// Removing the required vectors for case 1 and 2 to reduce the amount of memory usage
		vector<vector<double>>().swap(T_k1);
		vector<vector<double>>().swap(heat_flux_k1);
		vector<vector<double>>().swap(heat_flux_k2);
		vector<vector<double>>().swap(u1);
		vector<vector<double>>().swap(v1);
		vector<vector<double>>().swap(s1);
		vector<vector<double>>().swap(m1);
		vector<vector<double>>().swap(k1);
		vector<vector<double>>().swap(u2);
		vector<vector<double>>().swap(v2);
		vector<vector<double>>().swap(s2);
		vector<vector<double>>().swap(m2);
		vector<vector<double>>().swap(k2);
		vector<vector<double>>().swap(SWDir_2D_k2);
		vector<vector<double>>().swap(SWDiff_2D_k2);
		vector<vector<double>>().swap(SW_2D_k2);
		vector<vector<double>>().swap(atmLW_2D_k2);
		vector<vector<double>>().swap(LCLW_2D_k2);
		vector<vector<double>>().swap(backLW_2D_k2);
		vector<vector<double>>().swap(LW_2D_k2);
		vector<vector<double>>().swap(Latent_2D_k2);
		vector<vector<double>>().swap(Sensible_2D_k2);
		vector<vector<double>>().swap(Bed_2D_k2);

		vector<vector<double>>().swap(a_c);
		vector<vector<double>>().swap(b_c);
		vector<vector<double>>().swap(c_c);
		vector<vector<double>>().swap(o);
		vector<vector<double>>().swap(p);
		vector<vector<double>>().swap(q);
		vector<vector<double>>().swap(o_c);
		vector<vector<double>>().swap(p_c);
		vector<vector<double>>().swap(q_c);
		vector<vector<double>>().swap(d);
		vector<vector<double>>().swap(g);
		vector<vector<double>>().swap(k);
		vector<vector<double>>().swap(m);
		vector<vector<double>>().swap(A);
		vector<vector<double>>().swap(a);
		vector<vector<double>>().swap(b);
		vector<vector<double>>().swap(c);


		// ======================================================
		// Sky to view and TSA, VSA & BSA adjusted to unsteady dx

		if (SolvingMethod == 1) {
			SkyToView_UnsE.resize(TotalDist_stable);
			SkyToView_UnsW.resize(TotalDist_stable);
			int count_uns = 0;
			for (int i = 0; i < TotalDist_stable; i++) {
				if (i == (TotalDist_stable - 1)) { count_uns = (i * dx_Interval) - 1; }
				else { count_uns = i * dx_Interval; }

				SkyToView_UnsE[i] = SkyV_E[count_uns];
				SkyToView_UnsW[i] = SkyV_W[count_uns];

			}
		}
		else {
			SkyToView_UnsE.resize(TotalDist_stable);
			SkyToView_UnsW.resize(TotalDist_stable);
			SF_LI_Uns.resize(TotalDist_stable);
			int count_uns = 0;
			for (int i = 0; i < TotalDist_stable; i++) {
				if (i == (TotalDist_stable - 1)) { count_uns = (i * dx_Interval) - 1; }
				else { count_uns = i * dx_Interval; }

				SkyToView_UnsE[i] = SkyToView_LI[count_uns];
				SkyToView_UnsW[i] = SkyToView_LI[count_uns];
				SF_LI_Uns[i] = SF_LI[count_uns];

			}
		}

		// ======================================================
		//Node_HR = 0;
		//double distance_HR;
		//distance_HR = TotalDist;
		//time_HR = 0;
		flag_BC = 1;
		HyporheicVelocity_HR.resize(TotalDist_stable);

		// ======================================================

		//for (int i = 0; i < TotalTime_min; i++) {
		for (int i = 0; i < TotalTime; i++) {
			for (int theNode_HR = 0; theNode_HR <= TotalDist_stable_HR; theNode_HR++) {
				// Find hyporheic fluxes
				// Ratio Conductivity of dominant sunstrate
				double Dummy1 = conductivity_Uns[theNode_HR] * (1.0 - embeddedness_Uns[theNode_HR]);
				// Ratio Conductivity of sand - low range
				double Dummy2 = 0.00002 * embeddedness_Uns[theNode_HR];
				// True horzontal cond. (m / s)
				double HorCond = Dummy1 + Dummy2;

				// Ratio Size of dominant substrate
				Dummy1 = particleSize_Uns[theNode_HR] * (1.0 - embeddedness_Uns[theNode_HR]);
				// Ratio Conductivity of sand - low range
				Dummy2 = 0.062 * embeddedness_Uns[theNode_HR];
				// Estimated Porosity
				Porosity[theNode_HR][i] = (0.3683 * pow((Dummy1 + Dummy2), (-0.0641)));

				// Calculate head at top(ho) and bottom(hL) of reach
				double ho, hL;
				if (theNode_HR < (TotalDist_stable_HR - 1)) {
					hL = WSElev_ALL_HR[theNode_HR + 1][i];
				}
				else {
					hL = WSElev_HR_LI[((theNode_HR + 1) * dx_Interval) - 1];
				}
				ho = WSElev_ALL_HR[theNode_HR][i];

				// Try new equation for calculating Hyporheic Exchange Flow, without squaring ho and hL, and without porosity
				HyporheicExchange_HR[theNode_HR][i] = abs(ho - hL) * Pw_ALL_HR[theNode_HR][i] * HorCond * (ho - hL) / dx_Interval;

				// I turned this section off. There was no reason to keep it! Reza, Feb. 20

				//if (HyporheicExchange_HR[theNode_HR][i] > Q_Str_HR[theNode_HR][i]) {
				//	HyporheicExchange_HR[theNode_HR][i] = Q_Str_HR[theNode_HR][i];
				//}
				//if (abs(HyporheicExchange_HR[theNode_HR][i]) > 0) {
				//	HyporheicVelocity_HR[theNode_HR] = (HyporheicExchange_HR[theNode_HR][i] / 3600.0) / ((ho - hL) * Pw_ALL_HR[theNode_HR][i] * Porosity[theNode_HR][TotalTime]);   // m/hr

				//}
				//else {
				//	HyporheicVelocity_HR[theNode_HR] = 0;
				//}
				//HyporheicExchange_HR[theNode_HR][i] = abs(HyporheicExchange_HR[theNode_HR][i]);


				// finding dispersion coefficient
				// Calculate dispersion using equations copied from SubMcCormick1
				double Shear_Velocity;
				double SlopeWS = (hL - ho) / dx_Interval;
				if (SlopeWS <= 0) {
					Shear_Velocity = VelocityALL_HR[theNode_HR][i];
				}
				else {
					Shear_Velocity = sqrt(9.8 * DepthALL_HR[theNode_HR][i] * SlopeWS);
				}
				// Changed 0.011 to 0.06 in below eqn to account for natural (not straight) streams
				Dispersion_HR[theNode_HR][i] = (0.06 * pow(VelocityALL_HR[theNode_HR][i], 2.0) * pow(WidthALL_HR[theNode_HR][i], 2.0)) / (DepthALL_HR[theNode_HR][i] * Shear_Velocity);
				if ((Dispersion_HR[theNode_HR][i] * pow((dtime_Interval / dx_Interval), 2.0)) > 0.5) {
					Dispersion_HR[theNode_HR][i] = (0.45 * pow(dx_Interval, 2.0)) / dtime_Interval;
				}

				// Updating the stream temperature in the 1st cross section (theNode = 0) w/ the observed temperature for boundary condition
				if (flag_BC == 1) {
					//Temp1_HRsize2[theNode_HR][i] = inflow_T0_HR[i];
					// I replaced the right hand side vector in order to avoid using the "steadyInflow.dat" file
					Temp1_HRsize2[theNode_HR][i] = inflow_temp_1[i];
				}

				flag_BC = 0;
				theDistance_HR = theDistance_HR - dx_Interval;


				// For debugging purpose
				//Hor_Con_HR.push_back(HorCond);
				//ho_HR.push_back(ho);
				//hl_HR.push_back(hL);
			}
			flag_BC = 1;

		}

		// For debugging purpose
		//for (int i = 0; i < 100; i++) {
		//	Hyporheic_Exchange_HR.push_back(HyporheicExchange_HR[i][1]);
		//}

		//for (int i = 0; i < TotalDist_stable_HR; i++) { Pw_HR_1D.push_back(Pw_ALL_HR[i][1]); }
		//average_PW_HR = accumulate(Pw_HR_1D.begin(), Pw_HR_1D.end(), 0.0) / Pw_HR_1D.size();
		//averageHor_Con_HR = accumulate(Hor_Con_HR.begin(), Hor_Con_HR.end(), 0.0) / Hor_Con_HR.size();
		//averageHor_ho_HR = accumulate(ho_HR.begin(), ho_HR.end(), 0.0) / ho_HR.size();
		//averageHor_hl_HR = accumulate(hl_HR.begin(), hl_HR.end(), 0.0) / hl_HR.size();


		// Updated heat calculations
		//for (int timeStep = 0; timeStep < TotalTime_min; timeStep++) {
		for (int timeStep = 0; timeStep < TotalTime; timeStep++) {

			//TravelTime = 0;

			for (int theNode = 0; theNode <= TotalDist_stable_HR; theNode++) {

				//if (timeStep == 46) {
				//	system("pause");
				//}


				//if (timeStep == 0) {
				//	Temp1_HRsize2[theNode][timeStep] = inflow_T0_HR[timeStep];
				//}
				if (theNode == 0) {
					if (PBC_On == 1) {
						if ((timeStep != 0) && (timeStep % PBC_loopNR != 0)) {
							Temp1_HRsize2[theNode][timeStep] = Temp1_HRsize2[TotalDist_stable_HR-1][timeStep-1];
						}
					}
				}

				adjustedDirRadE_Uns(solarSW_Dir_LI, timeStep, theNode);
				adjustedDirRadW_Uns(solarSW_Dir_LI, timeStep, theNode);
				netSolarDiffRadE_Uns(solarSW_Diff_LI, timeStep, theNode);
				netSolarDiffRadW_Uns(solarSW_Diff_LI, timeStep, theNode);

				if (startingHour >= 0 && startingHour < 12) {
					DirSW_Uns_temp = DirSW_UnsE;
					DiffSW_Uns_temp = DiffSW_UnsE;
				}
				else {
					DirSW_Uns_temp = DirSW_UnsW;
					DiffSW_Uns_temp = DiffSW_UnsW;
				}
				SW_Uns = DiffSW_Uns_temp + DirSW_Uns_temp;

				longWaveRadiation_Uns(airTemp_LI, real_humidity_LI, cloudiness_LI, timeStep, theNode);
				latentHeat_Uns(airTemp_LI, real_humidity_LI, windSp_LI, timeStep, theNode);
 				sensibleHeat_Uns(airTemp_LI, windSp_LI, real_humidity_LI, timeStep, theNode);
				//option 1 for bed*******************************************************
				//bedSediment_HR(K_sedType_LI, sedTemp_Uns, DepthAvgALL_HR, timeStep, theNode);

				Flux_Total_Time[theNode] = SW_Uns + LW_Uns + latent_Uns + Sensible_Uns;

				//Flux_Conduction_Time[theNode] = bed_Uns;
				Flux_Evaporation_Time[theNode] = latent_Uns;
				Flux_Convection_Time[theNode] = Sensible_Uns;
				FLux_AtmLW_Time[theNode] = LW_Atm_Uns;
				Flux_LCLW_Time[theNode] = LW_LC_Uns;
				Flux_BackLW_Time[theNode] = LW_Back_Uns;
				Flux_LW_Time[theNode] = LW_Atm_Uns + LW_LC_Uns + LW_Back_Uns;
				Flux_DirSW_Time[theNode] = DirSW_Uns_temp;
				Flux_DiffSW_Time[theNode] = DiffSW_Uns_temp;
				Flux_SW_Time[theNode] = SW_Uns;

				// Here I put a node to talk with Ted about the dtime_Interval here and retention time ???
				DeltaT_HR[theNode] = (Flux_Total_Time[theNode] * dtime_Interval) / (DepthAvgALL_HR[theNode][timeStep] * rho_water * c_water);

				DeltaTotal_HR[theNode][timeStep] = DeltaT_HR[theNode];

				//HeatTime = HeatTime + RetentionT_HR[theNode][timeStep];

				//option 1 for bed*******************************************************
				ConductionFlux_HR(Porosity, sedTemp_LI, timeStep, theNode, Rotation);
				FluxTotal_HR[theNode][timeStep] = Flux_Total_Time[theNode];
				Flux_Conduction_Time[theNode] = FluxConduction_HR[theNode][timeStep];

				// Calculate mixture temperature for each node and time step :

				double Advection = 0;
				double Disp = 0;
				double FluxTemp_HR;

				// For first node, temperature at beginning of node is boundary condition temp. at that time
				//if ((theNode == 0) && (timeStep != 0)) {
				//	//Temp0_HRsize2[theNode][timeStep] = HeatTime;
				//	Advection = (FluxTotal_HR[theNode][timeStep] + FluxConduction_HR[theNode][timeStep]) / (rho_water * c_water * DepthALL_HR[theNode][timeStep]);
				//	Disp = 0;
				//	FluxTemp_HR = Tobs_minBased[timeStep] * (Advection + Disp) * RetentionT_HR[theNode][timeStep];
				//	Temp1_HRsize2[theNode][timeStep] = (FluxTemp_HR * (Q_Str_HR[theNode][timeStep] - HyporheicExchange_HR[theNode][timeStep] - Q_GW[theNode]) +
				//		Q_Inflow_HR[theNode][timeStep] * T_Inflow_HR[theNode][timeStep] + HyporheicExchange_HR[theNode][timeStep] * BedTn_LI_Uns[theNode] + 
				//		Q_GW[theNode] * Temp_GW[theNode]) / (Q_Inflow_HR[theNode][timeStep] + Q_Str_HR[theNode][timeStep]) ;
				//}

				// For all other nodes, temperature at beginning of node is temperature at the end of the node
				//if ((theNode != 0) && (timeStep != 0)) {
				if (theNode != 0) {
					//Temp0_HRsize2[theNode][timeStep] = HeatTime;
					Advection = (FluxTotal_HR[theNode][timeStep] + FluxConduction_HR[theNode][timeStep]) / (rho_water * c_water * DepthALL_HR[theNode][timeStep]);
					Disp = -1 * Dispersion_HR[theNode][timeStep] * (((FluxTotal_HR[theNode][timeStep] + FluxConduction_HR[theNode][timeStep]) /
						(rho_water * c_water * DepthALL_HR[theNode][timeStep] * VelocityALL_HR[theNode][timeStep]) - ((FluxTotal_HR[theNode - 1][timeStep]
							+ FluxConduction_HR[theNode - 1][timeStep]) / (rho_water * c_water * DepthALL_HR[theNode - 1][timeStep] * VelocityALL_HR[theNode - 1][timeStep]))) / dx_Interval);
					FluxTemp_HR = Temp1_HRsize2[theNode - 1][timeStep] + (Advection + Disp) * RetentionT_HR[theNode][timeStep];
					Temp1_HRsize2[theNode][timeStep] = (FluxTemp_HR * (Q_Str_HR[theNode][timeStep] - HyporheicExchange_HR[theNode][timeStep] - Q_GW[theNode] - Q_Inflow_HR[theNode][timeStep])
						+ Q_Inflow_HR[theNode][timeStep] * T_Inflow_HR[theNode][timeStep] + HyporheicExchange_HR[theNode][timeStep] * BedTn_LI_Uns[theNode]
						+ Q_GW[theNode] * Temp_GW[theNode]) / Q_Str_HR[theNode][timeStep];
					//TravelTime = TravelTime + RetentionT_HR[theNode][timeStep];

				}

				for (int counter = 0; counter < TotalDist_stable; counter++) {
					calcT_Temp[counter] = Temp1_HRsize2[counter][timeStep];
				}

				if ((Temp1_HRsize2[theNode][timeStep] > 50) || (Temp1_HRsize2[theNode][timeStep] < 0)) {
  					cout << "Model is unstable.  There could be a variety of reasons for this." << endl;
					cout << "Check your input data, or try decreasing time step and/or increasing distance step." << endl;
				}

				Rotation = Rotation + 1;

			}


			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_Total_Time, x, true);
				Flux_Total_HRdist[x][timeStep] = y;
			}

			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_Evaporation_Time, x, true);
				Flux_Evaporation_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_Conduction_Time, x, true);
				Flux_Conduction_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_Convection_Time, x, true);
				Flux_Convection_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, FLux_AtmLW_Time, x, true);
				FLux_AtmLW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_LCLW_Time, x, true);
				Flux_LCLW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_BackLW_Time, x, true);
				Flux_BackLW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_LW_Time, x, true);
				Flux_LW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_DirSW_Time, x, true);
				Flux_DirSW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_DiffSW_Time, x, true);
				Flux_DiffSW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, Flux_SW_Time, x, true);
				Flux_SW_HR[x][timeStep] = y;
			}
			for (double x = 0; x < TotalDist; x++) {
				double y = interpolate(Nodes_Uns, calcT_Temp, x, true);
				Temp_HRdist[x][timeStep] = y;
			}



			for (int count = 0; count < TotalDist_stable_HR; count++) {
				Flux_Evaporation_Nodes[count][timeStep] = Flux_Evaporation_Time[count];
				Flux_Conduction_Nodes[count][timeStep] = Flux_Conduction_Time[count];
				Flux_Convection_Nodes[count][timeStep] = Flux_Convection_Time[count];
				FLux_AtmLW_Nodes[count][timeStep] = FLux_AtmLW_Time[count];
				Flux_LCLW_Nodes[count][timeStep] = Flux_LCLW_Time[count];
				Flux_BackLW_Nodes[count][timeStep] = Flux_BackLW_Time[count];
				Flux_LW_Nodes[count][timeStep] = Flux_LW_Time[count];
				Flux_DirSW_Nodes[count][timeStep] = Flux_DirSW_Time[count];
				Flux_DiffSW_Nodes[count][timeStep] = Flux_DiffSW_Time[count];
				Flux_SW_Nodes[count][timeStep] = Flux_SW_Time[count];
			}



			Rotation = 0;
			startingHour++;
			if (startingHour > 24) { startingHour = 0; }

			//HeatTime = HeatTime - TravelTime;
			cout << timeStep << " time step out of " << (TotalTime - 1) << " completed." << endl;
		}

		// For Debugging purpose*******************************************
		//for (int i = 0; i < 12; i++) {
		//	for (int j = 0; j < 96; j++) {
		//		tempNodesDebugg[i][j] = Temp1_HRsize2[nodeDebugg[i]][j];
		//	}
		//}

		cout << "... HEC-RAS based simulation process is done!" << endl;

		break;


	case 4:
		
		vector<vector<double>>().swap(a_c);
		vector<vector<double>>().swap(b_c);
		vector<vector<double>>().swap(c_c);
		vector<vector<double>>().swap(o);
		vector<vector<double>>().swap(p);
		vector<vector<double>>().swap(q);
		vector<vector<double>>().swap(o_c);
		vector<vector<double>>().swap(p_c);
		vector<vector<double>>().swap(q_c);
		vector<vector<double>>().swap(d);
		vector<vector<double>>().swap(g);
		vector<vector<double>>().swap(k);
		vector<vector<double>>().swap(m);
		vector<vector<double>>().swap(A);
		vector<vector<double>>().swap(a);
		vector<vector<double>>().swap(b);
		vector<vector<double>>().swap(c);

		// STEP 6: Pre-allocate arrays used in iterative solution and set
		// initial and boundary temperature conditions.
		// ===================> Solving the Runge-Kutta method 

		// set temperatures for first time step at input values
		T.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) {
			T[i].resize(TotalTime);
			T[i][0] = initialT;
		}
		for (int i = 0; i < TotalTime; i++) { T[0][i] = obs_xo_LI[i]; }		// set boundary temperature condition

		initialT_T0.clear();
		initialT_T0.resize(TotalDist);
		for (int i = 0; i < TotalDist; i++) { initialT_T0[i] = initialT; }
		// Insert R - values for first time step.
		// Shortwave calculatin for the first time step:
		solarReflectivity();
		adjustedDirRadE(solarSW_Dir_LI, 0); // preparing the adjustedDirSW_E vector
		adjustedDirRadW(solarSW_Dir_LI, 0); // preparing the adjustedDirSW_W vector 
		netSolarDiffRadE(solarSW_Diff_LI, 0);  // preparing the adjustedDiffSW_E vector
		netSolarDiffRadW(solarSW_Diff_LI, 0);  // preparing the adjustedDiffSW_W vector
											   // Longwave radiation for the first time step
		longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, 0);
		// latent heat in the fist time step
		latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, 0);
		// Sensible heat for the first time step
		sensibleHeat(airTemp_LI, initialT_T0, windSp_LI, real_humidity_LI, 0);
		// Stream Bed heat for the first time step
		bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, 0);

		// ============ Time managing for East/West side of the stream bor allocating shortwave radiation correctly ===========


		minToHour(startingHour, TotalTime, timeRepeatedHour);

		// =======================================================================
		// Insert values for first time step.

		// Insert values for first time step.

		for (int i = 0; i < TotalDist; i++) {
			if (timeRepeatedHour[0] >= 0 && timeRepeatedHour[0] < 12) {
				SWDir_2D[i][0] = adjustedDirSW_E[i];
				SWDiff_2D[i][0] = adjustedDiffSW_E[i];
			}
			else {
				SWDir_2D[i][0] = adjustedDirSW_W[i];
				SWDiff_2D[i][0] = adjustedDiffSW_W[i];
			}
		}


		// Step 7: Calculate stream temperature using a second order Runge-Kutta method.
		// Change in temperature with respect to time is calculated at intermediate timesteps as defined by k1, which is
		// used to determine temperature at the intermediate time step. k1 is then used to calculate change in temperature to the next
		// time step, or k2.  Temperature at the future timestep is solved using k1 and k2.


		for (int j = 0; j < TotalTime; j++) {
			if (j == (TotalTime - 1)) {}
			else {
				// Insert heat flux for k1 at n=2:r-1
				// =============================== Next time step (j) calculations
				adjustedDirRadE(solarSW_Dir_LI, j); // preparing the adjustedDirSW_E vector
				adjustedDirRadW(solarSW_Dir_LI, j); // preparing the adjustedDirSW_W vector 
				netSolarDiffRadE(solarSW_Diff_LI, j);  // preparing the adjustedDiffSW_E vector
				netSolarDiffRadW(solarSW_Diff_LI, j);  // preparing the adjustedDiffSW_W vector
													   // Longwave radiation for the first time step
				longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, j);
				// latent heat in the fist time step
				latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, j);
				// Sensible heat for the first time step
				sensibleHeat(airTemp_LI, initialT_T0, windSp_LI,real_humidity_LI, j);
				// Stream Bed heat for the first time step
				bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, j);
				// ================================ Creating the "heat_flux_k1" 2D vector
				// ========= Time managing for East/West side of the stream for allocating shortwave radiation correctly ========

				// Insert values for first time step.

				for (int i = 0; i < TotalDist; i++) {

					if (timeRepeatedHour[j] >= 0 && timeRepeatedHour[j] < 12) {
						SWDir_2D[i][j] = adjustedDirSW_E[i];
						SWDiff_2D[i][j] = adjustedDiffSW_E[i];
					}
					else {
						SWDir_2D[i][j] = adjustedDirSW_W[i];
						SWDiff_2D[i][j] = adjustedDiffSW_W[i];
					}
					SW_2D[i][j] = SWDir_2D[i][j] + SWDiff_2D[i][j];


					heat_flux_k1[i][j] = SW_2D[i][j] + LW_2D[i][j] + Latent_2D[i][j] + Sensible_2D[i][j] + Bed_2D[i][j];
				}

				for (int i = 1; i <= (TotalDist - 2); i++) {
					u1[i][j] = (Q_half_min[i][j] / volume[i][0])*(0.5 * T[(i - 1)][j] - 0.5 *T[i][j]);
					v1[i][j] = (Q_half_min[(i + 1)][j] / volume[i][0])*(0.5 * T[i][j] - 0.5 * T[(i + 1)][j]);
					s1[i][j] = (Q_L_min[i][j] / volume[i][0])*(sedimentDist_LI[i] - T[i][j]);
					m1[i][j] = (width_total[i][j] * heat_flux_k1[i][j]) / ((rho_water*c_water)) / area_total[i][j];
					k1[i][j] = u1[i][j] + v1[i][j] + s1[i][j] + m1[i][j];
				}

				// T(r,t) is assumed to be T(r-1,t)
				// for i = TotalDist
				u1[nodes - 1][j] = (Q_half_min[nodes - 1][j] / volume[nodes - 1][0])*(0.5 * T[(nodes - 2)][j] - 0.5 *T[nodes - 1][j]);
				v1[nodes - 1][j] = (Q_half_min[nodes - 1][j] / volume[nodes - 1][0])*(0.5 * T[nodes - 1][j] - 0.5 * T[nodes - 1][j]);
				s1[nodes - 1][j] = (Q_L_min[nodes - 1][j] / volume[nodes - 1][0])*(sedimentDist_LI[nodes - 1] - T[nodes - 1][j]);
				m1[nodes - 1][j] = (width_total[nodes - 1][j] * heat_flux_k1[nodes - 1][j]) / ((rho_water*c_water)) / area_total[nodes - 1][j];
				k1[nodes - 1][j] = u1[nodes - 1][j] + v1[nodes - 1][j] + s1[nodes - 1][j] + m1[nodes - 1][j];


				// Calculate temperature based on k1
				T_k1[0][j] = obs_xo_LI[j];  // set boundary temperature condition
				for (int i = 1; i < TotalDist; i++) {
					T_k1[i][j] = T[i][j] + (dt*k1[i][j]);
				}

				initialT_T0.clear();
				initialT_T0.resize(TotalDist);
				for (int i = 0; i < TotalDist; i++) {
					initialT_T0[i] = T_k1[i][j];
				}

				// *****************CHECKING THE RESULTS OF K1 - START
				float averageTK1 = accumulate(initialT_T0.begin(), initialT_T0.end(), 0.0) / initialT_T0.size();
				cout << "*** The Average of the T_K1:  " << averageTK1 << endl;
				AddLogComment("*** The Average of the T_K1:  " + std::to_string(averageTK1));
				// *****************CHECKING THE RESULTS OF K1 - END



				// Calculate k2 ===========> Insert R - values for k2 *****************************************
				adjustedDirRadE(solarSW_Dir_LI, j); // preparing the adjustedDirSW_E vector
				adjustedDirRadW(solarSW_Dir_LI, j); // preparing the adjustedDirSW_W vector 
				netSolarDiffRadE(solarSW_Diff_LI, j);  // preparing the adjustedDiffSW_E vector
				netSolarDiffRadW(solarSW_Diff_LI, j);  // preparing the adjustedDiffSW_W vector
													   // Longwave radiation for the first time step
				longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, j);
				// latent heat in the fist time step
				latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, j);
				// Sensible heat for the first time step
				sensibleHeat(airTemp_LI, initialT_T0, windSp_LI, real_humidity_LI, j);
				// Stream Bed heat for the first time step
				bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, j);

				// Insert values for first time step.

				for (int i = 0; i < TotalDist; i++) {
					if (timeRepeatedHour[j] >= 0 && timeRepeatedHour[j] < 12) {
						SWDir_2D_k2[i][j] = adjustedDirSW_E[i];
						SWDiff_2D_k2[i][j] = adjustedDiffSW_E[i];
					}
					else {
						SWDir_2D_k2[i][j] = adjustedDirSW_W[i];
						SWDiff_2D_k2[i][j] = adjustedDiffSW_W[i];
					}
					SW_2D_k2[i][j] = SWDir_2D_k2[i][j] + SWDiff_2D_k2[i][j];
					//atmLW_2D_k2[i][j] = atmLW_2D[i][j];
					//LCLW_2D_k2[i][j] = LCLW_2D[i][j];
					//backLW_2D_k2[i][j] = backLW[i];
					LW_2D_k2[i][j] = LW_2D[i][j];
					Latent_2D_k2[i][j] = Latent_2D[i][j];
					Sensible_2D_k2[i][j] = Sensible_2D[i][j];
					Bed_2D_k2[i][j] = Bed_2D[i][j];

					heat_flux_k2[i][j] = SW_2D_k2[i][j] + LW_2D_k2[i][j] + Latent_2D_k2[i][j] + Sensible_2D_k2[i][j] + Bed_2D_k2[i][j];
				}

				// T(r,t) is assumed to be T(r-1,t)
				for (int i = 1; i <= (TotalDist - 2); i++) {
					u2[i][j] = (Q_half_min[i][(j + 1)] / volume[i][0])*(0.5*T_k1[(i - 1)][j] - 0.5*T_k1[i][j]);
					v2[i][j] = (Q_half_min[(i + 1)][(j + 1)] / volume[i][0])*(0.5*T_k1[i][j] - 0.5*T_k1[(i + 1)][j]);
					s2[i][j] = (Q_L_min[i][(j + 1)] / volume[i][0])*(sedimentDist_LI[i] - T_k1[i][j]);
					m2[i][j] = (width_total[i][j] * heat_flux_k2[i][j]) / ((rho_water*c_water)) / area_total[i][j];
					k2[i][j] = u2[i][j] + v2[i][j] + s2[i][j] + m2[i][j];
				}

				u2[nodes - 1][j] = (Q_half_min[nodes - 1][(j + 1)] / volume[nodes - 1][0])*(0.5*T_k1[(nodes - 2)][j] - 0.5*T_k1[nodes - 1][j]);
				v2[nodes - 1][j] = (Q_half_min[nodes][(j + 1)] / volume[nodes - 1][0])*(0.5*T_k1[nodes - 1][j] - 0.5*T_k1[nodes - 1][j]);
				s2[nodes - 1][j] = (Q_L_min[nodes - 1][(j + 1)] / volume[nodes - 1][0])*(sedimentDist_LI[nodes - 1] - T_k1[nodes - 1][j]);
				m2[nodes - 1][j] = (width_total[nodes - 1][j] * heat_flux_k2[nodes - 1][j]) / ((rho_water*c_water)) / area_total[nodes - 1][j];
				k2[nodes - 1][j] = u2[nodes - 1][j] + v2[nodes - 1][j] + s2[nodes - 1][j] + m2[nodes - 1][j];



				// Calculate temperature at next timestep for each node
				initialT_T0.clear();
				initialT_T0.resize(TotalDist);
				for (int i = 1; i < TotalDist; i++) {
					T[i][(j + 1)] = T[i][j] + (dt*(0.5*k1[i][j] + 0.5*k2[i][j]));
				}
				for (int i = 0; i < TotalDist; i++) { initialT_T0[i] = T[i][j + 1]; }

				float averageT = accumulate(initialT_T0.begin(), initialT_T0.end(), 0.0) / initialT_T0.size();
				cout << "*** The Average of the initialT_T0:  " << averageT << endl;
				AddLogComment("*** The Average of the initialT_T0:  " + std::to_string(averageT));
				// Insert R-values for future time step
				// =============================== Next time step (j+1) calculations
				adjustedDirRadE(solarSW_Dir_LI, (j + 1)); // preparing the adjustedDirSW_E vector
				adjustedDirRadW(solarSW_Dir_LI, (j + 1)); // preparing the adjustedDirSW_W vector 
				netSolarDiffRadE(solarSW_Diff_LI, (j + 1));  // preparing the adjustedDiffSW_E vector
				netSolarDiffRadW(solarSW_Diff_LI, (j + 1));  // preparing the adjustedDiffSW_W vector
															 // Longwave radiation for the first time step
				longWaveRadiation(airTemp_LI, real_humidity_LI, cloudiness_LI, initialT_T0, (j + 1));
				// latent heat in the fist time step
				latentHeat(airTemp_LI, real_humidity_LI, initialT_T0, windSp_LI, (j + 1));
				// Sensible heat for the first time step
				sensibleHeat(airTemp_LI, initialT_T0, windSp_LI, real_humidity_LI, (j + 1));
				// Stream Bed heat for the first time step
				bedSediment(wp_total, width_total, K_sedType_LI, initialT_T0, sedimentTime_LI, BedDepthMeas_LI, (j + 1));

				// Insert values for first time step.
				//vector<vector<double>> heat_flux_2D, SWDir_2D, SWDiff_2D, SW_2D, LW_2D, atmLW_2D, LCLW_2D, backLW_2D, Latent_2D, Sensible_2D, Bed_2D;
				for (int i = 0; i < TotalDist; i++) {
					if (timeRepeatedHour[j] >= 0 && timeRepeatedHour[j] < 12) {
						SWDir_2D[i][(j + 1)] = adjustedDirSW_E[i];
						SWDiff_2D[i][(j + 1)] = adjustedDiffSW_E[i];
					}
					else {
						SWDir_2D[i][(j + 1)] = adjustedDirSW_W[i];
						SWDiff_2D[i][(j + 1)] = adjustedDiffSW_W[i];
					}

				}
				cout << j << " time step out of " << TotalTime << " completed." << endl;
				AddLogComment(std::to_string(j)+ " time step out of " + std::to_string(TotalTime)+ " completed.");
			}
		}
		cout << "... Runge-Kutta modeling methodology is done!" << endl;
		AddLogComment("... Runge-Kutta modeling methodology is done!");
		for (int i = 0; i < TotalDist; i++) {
			for (int j = 0; j < TotalTime; j++) {
				SW_2D[i][j] = SWDir_2D[i][j] + SWDiff_2D[i][j];
				heat_flux_2D[i][j] = SW_2D[i][j] + LW_2D[i][j] + Latent_2D[i][j] + Sensible_2D[i][j] + Bed_2D[i][j];
			}
		}

		break;


	default:
		cout << "Wrong modeling methodology code! Check the methodology code and try again." << endl;
		AddLogComment("Wrong modeling methodology code! Check the methodology code and try again.");
		break;
	}
	
}

//   Returns interpolated value at x from parallel arrays ( xData, yData )
//   Assumes that xData has at least two elements, is sorted and is strictly monotonic increasing
//   boolean argument extrapolate determines behaviour beyond ends of array (if needed)

double StreamTemperature::interpolate(vector<double> &xData, vector<double> &yData, double x, bool extrapolate)
{
	int size = xData.size();

	int i = 0;                                                                  // find left end of interval for interpolation
	if (x >= xData[size - 2])                                                 // special case: beyond right end
	{
		i = size - 2;
	}
	else
	{
		while (x > xData[i + 1]) i++;
	}
	double xL = xData[i], yL = yData[i], xR = xData[i + 1], yR = yData[i + 1];      // points on either side (unless beyond ends)
	if (!extrapolate)                                                         // if beyond ends of array and not extrapolating
	{
		if (x < xL) yR = yL;
		if (x > xR) yL = yR;
	}

	double dydx = (yR - yL) / (xR - xL);                                    // gradient
	return yL + dydx * (x - xL);                                              // linear interpolation
}

//======================================================================

void StreamTemperature::minToHour(int startH, int size, vector<int> &dateHTemp) {
	double value1 = size / 60.0;						    // 3100 / 60 = 51.6 ====> example
	int value1_f = floor(value1);							// 51
	int full = value1_f * 60;
	int extra = size - (value1_f * 60);

	dateHTemp.resize(size);
	int j = 1;
	int z = 0;
	int counter = startH;
	for (int hour = 0; hour < value1_f; hour++) {
		for (int i = 0; i <= 59; i++) {
			dateHTemp[i + (z * 60)] = counter;
		}
		z = z + 1;
		counter = counter + 1;
		if (counter > 23) { counter = counter - 24; }
	}


	for (int i = 0; i < extra; i++) {
		dateHTemp[(full + i)] = counter;
	}

}

// ================================= solving the linear equation using Gaussian elimination for Ax=B linear equation
vector<double> StreamTemperature::gauss(vector<vector<double>> &A) {
	int n = A.size();

	for (int i = 0; i<n; i++) {
		// Search for maximum in this column
		double maxEl = abs(A[i][i]);
		int maxRow = i;
		for (int k = i + 1; k<n; k++) {
			if (abs(A[k][i]) > maxEl) {
				maxEl = abs(A[k][i]);
				maxRow = k;
			}
		}

		// Swap maximum row with current row (column by column)
		for (int k = i; k<n + 1; k++) {
			double tmp = A[maxRow][k];
			A[maxRow][k] = A[i][k];
			A[i][k] = tmp;
		}

		// Make all rows below this one 0 in current column
		for (int k = i + 1; k<n; k++) {
			double c = -A[k][i] / A[i][i];
			for (int j = i; j<n + 1; j++) {
				if (i == j) {
					A[k][j] = 0;
				}
				else {
					A[k][j] += c * A[i][j];
				}
			}
		}
	}

	// Solve equation Ax=b for an upper triangular matrix A
	vector<double> c = vector<double>(n);
	for (int i = n - 1; i >= 0; i--) {
		c.at(i) = A[i][n] / A[i][i];
		for (int k = i - 1; k >= 0; k--) {
			A[k][n] -= A[k][i] * c.at(i);
		}
	}
	return c;
}


double StreamTemperature::maxValue(double x, double y, double z) {
	double Maximum = x;
	if (y > Maximum) { Maximum = y; }
	if (z > Maximum) { Maximum = z; }

	return Maximum;

}


std::vector<double> StreamTemperature::interp1(std::vector<double> &x, std::vector<double> &y, std::vector<double> &x_new)
{
	// Nearest interpolation for the y_new vector based on the distances in x and x_new and also based on the values in y
	std::vector<double> y_new;
	y_new.resize(x_new.size());
	int counter = 0;
	for (int i = 0; i < x_new.size(); i++) {
		double up_dist = x_new[i] - x[counter];
		double down_dist = x[counter + 1] - x_new[i];
		if (down_dist < up_dist) { y_new[i] = y[counter + 1]; }
		else { y_new[i] = y[counter]; }

		if (x_new[i] >= x[counter + 1]) { counter++; }
	}
	return y_new;
}



void StreamTemperature::initialConditions(int Node) {


	// Set Flow Initial Conditions
	if (flag_BC == 1) {
		Q[0][Node] = Q_minBased[time_Uns];
	}
	else {
		Q[0][Node] = Q[0][Node - 1] + Q_In[Node- 1][time_Uns] + Q_GW[Node - 1];
	}
	Q[1][Node] = Q[0][Node];
	// ======================================================
	// Set Temperature Initial Conditions
	Temp_unsteady[0][Node] = Tobs_minBased[time_Uns];
	Temp_unsteady[1][Node] = Temp_unsteady[0][Node];
	// ======================================================
	// Calculate Initial Condition Hydraulics
	if (Node != TotalDist_stable) {

		if (s_unsteady[Node] <= 0) {
			cout << "Slope cannot be less than or equal to zero unless you enter a control depth." << endl;
			AddLogComment("Slope cannot be less than or equal to zero unless you enter a control depth.");
		}

		if (flag_BC == 1) {
			depth_unsteady[Node][0] = 1.0;
		}
		else {
			depth_unsteady[Node][0] = depth_unsteady[Node - 1][0];
		}

		if (Q[0][Node] < 0.0071) {
			// Channel is going dry
			cout << "The channel is going dry. " << endl;
			AddLogComment("The channel is going dry. ");
			Flag_SkipNode[Node] = 1;
		}
		else {
			// Channel has sufficient flow
			Flag_SkipNode[Node] = 0;
		}

		double Q_Est = Q[0][Node];

		if (Flag_SkipNode[Node] == 0) {
			double Converge = 100000.0;
			double dy = 0.01;
			double D_Est = depth_unsteady[Node][0];
			double A_Est = AreaX[Node][0];
			double Fy = 0;
			double Fyy = 0;
			double dFy;
			double thed;

			int Count_Iterations = 0;
			int passCode = 0;

			while (passCode == 0) {
				if (D_Est == 0) { D_Est = 10.0; }
				A_Est = D_Est * (width_unsteady[Node] + Z_unsteady[Node] * D_Est);
				Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * D_Est * sqrt(1.0 + pow(Z_unsteady[Node], 2.0));
				if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
				Rh_unsteady[Node] = A_Est / Pw_unsteady[Node];
				Fy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
				thed = D_Est + dy;
				A_Est = thed * (width_unsteady[Node] + Z_unsteady[Node] * thed);
				Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * thed * sqrt(1 + pow(Z_unsteady[Node], 2.0));
				if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
				Rh_unsteady[Node] = A_Est / Pw_unsteady[Node];
				Fyy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
				dFy = (Fyy - Fy) / dy;
				if (dFy == 0) { dFy = 0.99; }
				thed = D_Est - Fy / dFy;
				D_Est = thed;
				if ((D_Est < 0) || (D_Est > 1000000000000) || (Count_Iterations > 1000)) {
					srand(time(0));
					double r = rand() % 1000;
					D_Est = 10.0 * r;			// Randomly reseed initial value and step
					Converge = 10.0;
					Count_Iterations = 0;
				}
				dy = 0.01;
				Converge = abs(Fy / dFy);
				if (Converge < 0.001) {
					passCode++;
				}
				Count_Iterations = Count_Iterations + 1;
			}
			depth_unsteady[Node][0] = D_Est;
			AreaX[Node][0] = A_Est;
			velocity_unsteady[Node][0] = Q[0][Node] / AreaX[Node][0];
			width_UnsTotal[Node] = width_unsteady[Node] + 2.0 * Z_unsteady[Node] * depth_unsteady[Node][0];
			// Celerity(Node) = theVelocity(Node, 0) + Sqr(9.8 * theDepth(Node, 0))
		}
		else {
			Q_Est = 0;
			depth_unsteady[Node][0] = 0;
			AreaX[Node][0] = 0;
			Pw_unsteady[Node] = 0;
			Rh_unsteady[Node] = 0;
			width_UnsTotal[Node] = 0;
			depth_AvgUns[Node] = 0;
			velocity_unsteady[Node][0] = 0;
			Q[0][Node] = 0;
			// Celerity(Node) = 0
		}
	}
}


void StreamTemperature::hydroStability() {

	double dummy;
	double maxdt = 100000.0;
	int theDistance = TotalDist;
	int Node = 0;

	for (int i = 0; i < TotalDist; i += dx_unsteady) {
		if (theDistance >= 0) {
			dummy = dx_unsteady / (velocity_unsteady[Node][0] + sqrt(9.80 * depth_unsteady[Node][0]));
			if (dummy < maxdt) { maxdt = dummy; }
			dummy = pow(Rh_unsteady[Node], (4.0 / 3.0)) / (9.8 * velocity_unsteady[Node][0] * pow(n_unsteady[Node], 2.0));
			if (dummy < maxdt) { maxdt = dummy; }

			theDistance = theDistance - dx_unsteady;
			Node++;
		}
		if (maxdt < dtime_unsteady) {
			cout << "The selected dt for the unsteady calculation is not stable!! " << endl;
			AddLogComment("The selected dt for the unsteady calculation is not stable!! ");
			cout << "The dt should be considered equal to: " << maxdt << " as the max alovable dt. " << endl;
			AddLogComment("The dt should be considered equal to: " + std::to_string(maxdt) + " as the max alovable dt. ");
		}
	}
}


void StreamTemperature::hydraulics(int Node, int t) {

	double Q_In_0, Q_In_1, Q_Out_0;


	// ======================================================
	// Calculate Initial Condition Hydraulics
	if (flag_BC == 1) {
		Q[0][Node] = Q_minBased[t];
		Q_In_0 = Q[0][Node];
		Q_In_1 = Q[1][Node];
		Q_Out_0 = Q[0][Node];
		Temp_unsteady[0][Node] = Tobs_minBased[t];
	}
	else {
		Q_In_0 = Q[0][Node - 1];
		Q_In_1 = Q[1][Node - 1];
		Q_Out_0 = Q[0][Node];
	}


	// ======================================================
	// Calculate flow volumes in reaches for both times

	double EvapVol = evap_Rate * width_UnsTotal[Node] * dx_unsteady;
	double Mix = Q_In[Node][t] + Q_GW[Node] - EvapVol;
	double V_In_0 = (Mix + Q_In_0) * dtime_unsteady;
	if (V_In_0 < 0) { V_In_0 = 0; }
	double V_In_1 = (Mix + Q_In_1) * dtime_unsteady;
	if (V_In_1 < 0) { V_In_1 = 0; }
	double V_Out_0 = Q_Out_0 * dtime_unsteady;
	if (V_Out_0 < 0) { V_Out_0 = 0; }
	// ======================================================
	
	double Q_Est = Mix + Q_In_1;
	if (Q_Est < 0.0071) {
		// Channel is going dry
		cout << "The channel is going dry. " << endl;
		AddLogComment("The channel is going dry. ");
		Flag_SkipNode[Node] = 1;
	}
	else {
		// Channel has sufficient flow
		Flag_SkipNode[Node] = 0;
	}

	// ======================================================
	// Start Flow Routing

	if (flag_BC == 1) {
		depth_unsteady[Node][0] = 1;
	}
	else {
		depth_unsteady[Node][0] = depth_unsteady[Node - 1][0];
	}

	int passCode = 0;
	double Converge = 100000.0;
	if (Flag_SkipNode[Node] == 0) {
		double dy = 0.01;
		double D_Est = depth_unsteady[Node][0];
		double A_Est = AreaX[Node][0];
		int Count_Iterations = 0;

		while (passCode == 0) {
			if (D_Est == 0) { D_Est = 10.0; }
			A_Est = D_Est * (width_unsteady[Node] + Z_unsteady[Node] * D_Est);
			Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * D_Est * sqrt(1.0 + pow(Z_unsteady[Node], 2.0));
			if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
			Rh_unsteady[Node] = AreaX[Node][0] / Pw_unsteady[Node];
			double Fy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
			double thed = D_Est + dy;
			A_Est = thed * (width_unsteady[Node] + Z_unsteady[Node] * thed);
			Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * thed * sqrt(1 + pow(Z_unsteady[Node], 2.0));
			if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
			Rh_unsteady[Node] = AreaX[Node][0] / Pw_unsteady[Node];
			double Fyy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
			double dFy = (Fyy - Fy) / dy;
			if (dFy == 0) { dFy = 0.99; }
			thed = D_Est - Fy / dFy;
			D_Est = thed;
			if ((D_Est < 0) || (D_Est > 1000000000000) || (Count_Iterations > 1000)) {
				// Newton-Raphson didn't converge on a solution
				// need to reseed initial guess and restart method
				srand(time(0));
				//double r = rand() % 1;
				double r = ((double)rand() / (RAND_MAX)) + 1;
				D_Est = 0.1 * r;			// Randomly reseed initial value and step
				Converge = 10.0;
				Count_Iterations = 0;
			}
			dy = 0.01;
			Converge = abs(Fy / dFy);
			if (Converge < 0.0001) {
				passCode++;
			}
			Count_Iterations = Count_Iterations + 1;
		}
		// Newton-Raphson has determined wetted depth, width, XArea, velocity at current time
		depth_unsteady[Node][0] = D_Est;
		AreaX[Node][0] = A_Est;
		velocity_unsteady[Node][0] = Q_Est / AreaX[Node][0];
		width_UnsTotal[Node] = width_unsteady[Node] + 2.0 * Z_unsteady[Node] * depth_unsteady[Node][0];
		depth_AvgUns[Node] = AreaX[Node][0] / width_UnsTotal[Node];
	}
	else {
		Q_Est = 0;
		depth_unsteady[Node][1] = 0;
		AreaX[Node][1] = 0;
		Pw_unsteady[Node] = 0;
		Rh_unsteady[Node] = 0;
		width_UnsTotal[Node] = 0;
		depth_AvgUns[Node] = 0;
		velocity_unsteady[Node][0] = 0;
		Q[1][Node] = 0;		
	}


	if (Flag_SkipNode[Node] == 0) {
		if (flag_BC == 1) {
			// Start - Boundary Condition
			depth_unsteady[Node][1] = depth_unsteady[Node][0];
			Q[1][Node] = Q[0][Node];
			AreaX[Node][1] = AreaX[Node][0];
			velocity_unsteady[Node][1] = Q[1][Node] / AreaX[Node][1];
		}
		else {
			// Explicit Hydraulic Method
			double dR, WR, vR;
			if (Node == (TotalDist_stable - 1)) {
				dR = depth_unsteady[Node][0];
				WR = width_UnsTotal[Node];
				vR = velocity_unsteady[Node][0];
			}
			else {
				dR = depth_unsteady[Node + 1][0];
				WR = width_UnsTotal[Node + 1];
				vR = velocity_unsteady[Node + 1][0];
			}
			double dL = depth_unsteady[Node - 1][0];
			double dM = depth_unsteady[Node][0];
			double Wm = width_UnsTotal[Node];
			double WL = width_UnsTotal[Node - 1];
			double vL = velocity_unsteady[Node - 1][0];
			double vM = velocity_unsteady[Node][0];
			double So = s_unsteady[Node];
			double Sf;

			// Solve for the wetted depth using (3 - 26) from ducumentation (Boyd & Kasper 2003)
			// www.oregon.gov/deq/FilterDocs/heatsourcemanual.pdf
			dM = dM + (dtime_unsteady / (2.0 * dx_unsteady)) * (dM * (vL - vR) + vM * (dL - dR));

			// Solve for friction slope using (3-28) from documentation (Boyd & Kasper 2003)
			AreaX[Node][1] = dM * (width_unsteady[Node] + Z_unsteady[Node] * dM);
			Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * dM * sqrt(1.0 + pow(Z_unsteady[Node], 2.0));
			Rh_unsteady[Node] = AreaX[Node][1] / Pw_unsteady[Node];
			Sf = (((pow((vR + vL), 2.0)) / 2.0) * (pow(n_unsteady[Node], 2.0))) / pow(Rh_unsteady[Node], (4.0 / 3.0));

			// Solve for velocity using (3-27) from documentation (Boyd & Kasper 2003)
			double A = vM + (dtime_unsteady / (2.0 * dx_unsteady)) * vM * (vR - vL);
			double B = ((dtime_unsteady * 9.8 / (2.0 * dx_unsteady)) * (dR - dL)) - (dtime_unsteady * 9.8 * (So - Sf));
			velocity_unsteady[Node][1] = A + B;

			// Calculate flow as a function of velocity and depth
			double Converge = 100000.0;
			double Q_Est = Mix + Q_In_1;

			if (Q_Est < 0.0071) {
				// Channel is going dry
				cout << "The channel is going dry. " << endl;
				AddLogComment("The channel is going dry. ");
				cout << "Stop Model Run and Change Input Data" << endl;
				AddLogComment("Stop Model Run and Change Input Data");
				Flag_SkipNode[Node] = 1;
			}
			else {
				// Channel has sufficient flow
				Flag_SkipNode[Node] = 0;
			}

			if (Flag_SkipNode[Node] == 0) {
				double dy = 0.01;
				int Count_Iterations = 0;
				double D_Est = depth_unsteady[Node][1];
				double A_Est = AreaX[Node][1];
				double Fy, thed, Fyy, dFy;
				int passCode1 = 0;
				while (passCode1 == 0) {
					if (D_Est == 0) { D_Est = 10.0; }
					A_Est = D_Est * (width_unsteady[Node] + Z_unsteady[Node] * D_Est);
					Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * D_Est * sqrt(1.0 + pow(Z_unsteady[Node], 2.0));
					if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
					Rh_unsteady[Node] = AreaX[Node][0] / Pw_unsteady[Node];
					Fy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
					thed = D_Est + dy;
					A_Est = thed * (width_unsteady[Node] + Z_unsteady[Node] * thed);
					Pw_unsteady[Node] = width_unsteady[Node] + 2.0 * thed * sqrt(1 + pow(Z_unsteady[Node], 2.0));
					if (Pw_unsteady[Node] <= 0) { Pw_unsteady[Node] = 0.00001; }
					Rh_unsteady[Node] = AreaX[Node][0] / Pw_unsteady[Node];
					Fyy = A_Est * pow(Rh_unsteady[Node], (2.0 / 3.0)) - (n_unsteady[Node]) * Q_Est / sqrt(s_unsteady[Node]);
					dFy = (Fyy - Fy) / dy;
					if (dFy == 0) { dFy = 0.99; }
					thed = D_Est - Fy / dFy;
					D_Est = thed;
					if ((D_Est < 0) || (D_Est > 1000000000000) || (Count_Iterations > 1000)) {
						srand(time(0));
						//double r = rand() % 10;
						double r = ((double)rand() / (RAND_MAX)) + 1;
						D_Est = 0.1 * r;			// Randomly reseed initial value and step
						Converge = 10.0;
						Count_Iterations = 0;
					}
					dy = 0.01;
					Converge = abs(Fy / dFy);
					if (Converge < 0.0001) {
						passCode1++;
					}
					Count_Iterations = Count_Iterations + 1;
				}
				depth_unsteady[Node][1] = D_Est;
				AreaX[Node][1] = A_Est;
				width_UnsTotal[Node] = width_unsteady[Node] + 2.0 * Z_unsteady[Node] * depth_unsteady[Node][1];
				depth_AvgUns[Node] = AreaX[Node][1] / width_UnsTotal[Node];
				Q[1][Node] = velocity_unsteady[Node][1] * AreaX[Node][1];
			}
			else {
				Q_Est = 0;
				depth_unsteady[Node][1] = 0;
				AreaX[Node][1] = 0;
				Pw_unsteady[Node] = 0;
				Rh_unsteady[Node] = 0;
				width_UnsTotal[Node] = 0;
				depth_AvgUns[Node] = 0;
				velocity_unsteady[Node][0] = 0;
				Q[1][Node] = 0;
			}

		}

	}

	// ======================================================
	// Calc hyporheic flow in cell Q(0,1)
	if (Flag_SkipNode[Node] == 0) {
		// Ratio Conductivity of dominant sunstrate
		double Dummy1 = conductivity_Uns[Node] * (1.0 - embeddedness_Uns[Node]);
		// Ratio Conductivity of sand - low range
		double Dummy2 = 0.01 * embeddedness_Uns[Node];
		// True horzontal cond. (m / s)
		double HorCond = Dummy1 + Dummy2;

		// Ratio Size of dominant substrate
		Dummy1 = particleSize_Uns[Node] * (1.0 - embeddedness_Uns[Node]);
		// Ratio Conductivity of sand - low range
		Dummy2 = 0.062 * embeddedness_Uns[Node];
		// Estimated Porosity
		Porosity[Node][t] = 0.3683 * pow((Dummy1 + Dummy2), (-0.0641));

		// Calculate head at top(ho) and bottom(hL) of reach
		double ho, hL;
		if (flag_BC == 1) {
			ho = hyp_Slope_Uns[Node] * dx_unsteady;
			hL = 0;
		}
		else {
			ho = depth_unsteady[Node - 1][1] + hyp_Slope_Uns[Node] * dx_unsteady;
			hL = depth_unsteady[Node][1];
		}
		// Calculate Hyporheic Flows
		//Hyporheic_Exchange[Node] = abs(Porosity * Pw_unsteady[Node] * HorCond * (pow(ho, 2.0) - pow(hL, 2.0)) / (2.0 * dx_unsteady));
		Hyporheic_Exchange[Node] = hyp_Slope_Uns[Node] * Pw_unsteady[Node] * HorCond * (ho -hL);
		if (Hyporheic_Exchange[Node] > Q[1][Node]) {
			Hyporheic_Exchange[Node] = Q[1][Node];
		}

		// Calculate tendency to stratify
		Froude_Densiometric = (sqrt(1.0 / 9.8 * 0.000001)) * ((dx_unsteady * Q[1][Node]) / (depth_unsteady[Node][1] * AreaX[Node][1] * dx_unsteady));

	}
	else {
		// No Flow in Channel
		Hyporheic_Exchange[Node] = 0;
		Froude_Densiometric = 0;
		Temp_unsteady[0][Node] = 0;
	}

	// ======================================================

}


void StreamTemperature::McCormick_Temp1(const vector<double> &delta_t , int time) {
	// =======================================================
	// Calc Forward Difference "S1" of MacCormick Method
	// Calculate temperature (first estimate)
	//  T(t,i) = Stream tempertaure
	//  t = time
	//  i = simulation node
	// =======================================================

	int Flag_BC = 1;
	double dummy = 0;
	double T0, T1, T2;
	double Shear_Velocity;
	double Dummy1, Dummy2;
	int Node = 0;
	dispersion.resize(TotalDist_stable);
	S1.resize(TotalDist_stable);

	T_trib_shift.resize(2);
	for (int i = 0; i < 2; i++) {
		T_trib_shift[i].resize(TotalDist_stable + 1);
	}

	while (TotalDist - (Node * dx_unsteady) >= 0) {
		if (Flag_BC == 0) {
			if (Flag_SkipNode[Node] == 0) {
				T_trib_shift[0][Node] = 0;
				mixing(Node, dummy, time);
				if (TotalDist - ((Node + 1) * dx_unsteady) > 0) {
					T0 = Temp_unsteady[0][Node - 1] + T_trib_shift[0][Node];
					T1 = Temp_unsteady[0][Node];
					T2 = Temp_unsteady[0][Node + 1];
				}
				else {
					T0 = Temp_unsteady[0][Node - 1] + T_trib_shift[0][Node];
					T1 = Temp_unsteady[0][Node];
					T2 = Temp_unsteady[0][Node];
				}
				if (s_unsteady[Node] <= 0) {
					Shear_Velocity = velocity_unsteady[Node][1];
				}
				else {
					Shear_Velocity = sqrt(9.8 * depth_unsteady[Node][1] * s_unsteady[Node]);
				}
				dispersion[Node] = (0.011 * pow(velocity_unsteady[Node][1], 2.0) * pow(width_UnsTotal[Node], 2.0)) / (depth_unsteady[Node][1] * Shear_Velocity);
				if ((dispersion[Node] * pow((dtime_unsteady / dx_unsteady), 2.0)) > 0.5) {
					dispersion[Node] = (0.45 * pow(dx_unsteady, 2.0)) / dtime_unsteady;
				}
				Dummy1 = -velocity_unsteady[Node][1] * (T1 - T0) / dx_unsteady;
				Dummy2 = dispersion[Node] * (T2 - 2.0 * T1 + T0) / pow(dx_unsteady, 2.0);
				S1[Node] = Dummy1 + Dummy2 + delta_t[Node];
				Temp_unsteady[1][Node] = Temp_unsteady[0][Node] + S1[Node] * dtime_unsteady;
			}
			else
			{
				Temp_unsteady[1][Node] = Temp_unsteady[0][Node];
			}
		}
		else {
			Temp_unsteady[1][Node] = Tobs_minBased[time];
		}
		Flag_BC = 0;
		Node = Node + 1;
	}

	//Temp_unsteady[1][TotalDist_stable] = Temp_unsteady[1][TotalDist_stable - 1];
}


void StreamTemperature::McCormick_Temp2(const vector<double> &delta_t, int time) {

	// =======================================================
	// Calc Backward Difference "S2" of MacCormick Method
	// =======================================================
	
	int Flag_BC = 1;
	int Node = 0;
	int dummy = 1;
	double T0, T1, T2;
	double Dummy1, Dummy2;

	S2.resize(TotalDist_stable);

	while (TotalDist - (Node * dx_unsteady) >= 0) {
		if (Flag_BC == 0) {
			T_trib_shift[1][Node] = 0;
			mixing(Node, dummy, time);
			if (Flag_SkipNode[Node] == 0) {
				if (TotalDist - ((Node + 1) * dx_unsteady) > 0) {
					T0 = Temp_unsteady[1][Node - 1] + T_trib_shift[1][Node];
					T1 = Temp_unsteady[1][Node];
					T2 = Temp_unsteady[1][Node + 1];
				}
				else {
					T0 = Temp_unsteady[1][Node - 1] + T_trib_shift[1][Node];
					T1 = Temp_unsteady[1][Node];
					T2 = Temp_unsteady[1][Node];
				}

				// ===================================================
				// Final MacCormick Finite Difference Calc.
				// ===================================================
				Dummy1 = -velocity_unsteady[Node][1] * (T1 - T0) / dx_unsteady;
				Dummy2 = dispersion[Node] * (T2 - 2.0 * T1 + T0) / pow(dx_unsteady, 2.0);
				S2[Node] = Dummy1 + Dummy2 + delta_t[Node];
				Temp_unsteady[1][Node] = Temp_unsteady[0][Node] + ((S1[Node] + S2[Node]) / 2.0) * dtime_unsteady;
			}
			else {
				Temp_unsteady[1][Node] = Temp_unsteady[0][Node];
			}
		}
		if ((Temp_unsteady[1][Node] > 50) || (Temp_unsteady[1][Node] < 0)) {
			cout << "Model is unstable.  There could be a variety of reasons for this." << endl;
			AddLogComment("Model is unstable.  There could be a variety of reasons for this.");
			cout << "Check your input data, or try decreasing time step and/or increasing distance step." << endl;
			AddLogComment("Check your input data, or try decreasing time step and/or increasing distance step.");
		}
		Flag_BC = 0;
		Node = Node + 1;
	}
	Node = 0;
	while (TotalDist - (Node * dx_unsteady) >= -dx_unsteady) {
		Temp_unsteady[0][Node] = Temp_unsteady[1][Node];
		T_unsTemporary[Node] = Temp_unsteady[1][Node];
		Node = Node + 1;
	}

}


void StreamTemperature::mixing(int Node, int Dummy, int t) {
	// Temperatures from mass transfer processes

	double Q_up, T_up, T_mix;

	if (Q[1][Node] > 0) {
		Q_up = Q[Dummy][Node - 1];
		T_up = Temp_unsteady[Dummy][Node - 1];
	}
	else {
		Q_up = 0;
	}

	if (Q_up > 0) {
	
		T_mix = ((Q_In[Node][t] * T_In[Node][t]) + (T_up * Q_up) + (BedTn_LI_Uns[Node] * Hyporheic_Exchange[Node]) + (Q_GW[Node] * Temp_GW[Node]))
			/ (Q_GW[Node] + Hyporheic_Exchange[Node] + Q_up + Q_In[Node][t]);

		T_trib_shift[Dummy][Node] = T_mix - T_up;
	}

}

void StreamTemperature::adjustedDirRadE_Uns(const vector<double> &DirSW, int timeStep, int Node)
{
	/* calcluating the index for getAspect function to get access the desired cell of the domain. */
	int col;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int index;
	int totCols = SpaData->getcols();

	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node* dx_unsteady) - 1; }

	double effWidth;
	DirSW_UnsE = 0;
	
	double topoEffect = 0;
	switch (SolvingMethod)
	{
	case 1:
		col = colNum_Dist[NodeTemp] - 1;
		row = rowNum_Dist[NodeTemp] - 1;
		index = row * totCols + col;
		slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
		aspect = TI->getAspect(index);
		
		topoEffect = (sin(slope) * cos(SolAltitude_LI_Uns[timeStep]) * cos((SolAltitude_LI_Uns[timeStep]) - aspect)) +
			cos(slope) * sin(SolAltitude_LI_Uns[timeStep]);
		if (topoEffect < 0) { topoEffect = 0; }
		effWidth = effectiveShadingE_Uns(DirSW, Node, timeStep);
		DirSW_UnsE = DirSW[timeStep] * (1 - SWreflVec_Uns[timeStep]) * topoEffect * (1 - (effWidth / width_UnsTotal[Node]));
		if (effWidth > width_UnsTotal[Node]) { DirSW_UnsE = 0; }

		break;

	case 2:
		if (calculation == 2) {
			DirSW_UnsE = DirSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec_Uns[timeStep]);
		}
		if (calculation == 3) {
			DirSW_UnsE = DirSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec[timeStep]);
		}

		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");

	}
}

void StreamTemperature::adjustedDirRadW_Uns(const vector<double> &DirSW, int timeStep, int Node)
{
	/* calcluating the index for getAspect function to get access the desired cell of the domain. */
	int col;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int index;
	int totCols = SpaData->getcols();

	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node* dx_unsteady) - 1; }

	double effWidth;
	DirSW_UnsW = 0;

	double topoEffect = 0;
	switch (SolvingMethod)
	{
	case 1:
		col = colNum_Dist[NodeTemp] - 1;
		row = rowNum_Dist[NodeTemp] - 1;
		index = row * totCols + col;
		slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
		aspect = TI->getAspect(index);

		topoEffect = (sin(slope) * cos(SolAltitude_LI_Uns[timeStep]) * cos((SolAltitude_LI_Uns[timeStep]) - aspect)) +
			cos(slope) * sin(SolAltitude_LI_Uns[timeStep]);
		if (topoEffect < 0) { topoEffect = 0; }
		effWidth = effectiveShadingW(DirSW, Node, timeStep);
		DirSW_UnsW = DirSW[timeStep] * (1 - SWreflVec_Uns[timeStep]) * topoEffect * (1 - (effWidth / width_UnsTotal[Node]));
		if (effWidth > width_UnsTotal[Node]) { DirSW_UnsW = 0; }

		break;

	case 2:
		if (calculation == 2) {
			DirSW_UnsW = DirSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec_Uns[timeStep]);
		}
		if (calculation == 3) {
			DirSW_UnsW = DirSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec[timeStep]);
		}

		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");

	}
}


double StreamTemperature::effectiveShadingE_Uns(const vector<double> &SolDirE, int Node, int ts)
{
	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node* dx_unsteady) - 1; }
	// to get access the correct location in the vectors based on the dx of 
	// unsteady state.

	int col = colNum_Dist[NodeTemp] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row = rowNum_Dist[NodeTemp] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int totCols = SpaData->getcols();
	int index = row * totCols + col;

	slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
	aspect = TI->getAspect(index);

	double delta1;
	double delta2;
	double avgPath;
	double solarPhi;
	double shadowLengthE;
	double extinctCoeff;
	double effShadowLengthE;

	double Canbuffer = Buff_E_LI[NodeTemp];

	//Eq. #3 in Sun et al., (2015)
	if (SolAltitude_LI_Uns[ts] == 0) { shadowLengthE = 0; }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAEast[NodeTemp], BSAEast[NodeTemp], TSAEast[NodeTemp]);
		if (VSAEast[NodeTemp] == MaxSky) {
			shadowLengthE = (BankH_E_LI[NodeTemp] + TreeH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
		else if (BSAEast[NodeTemp] == MaxSky) {
			shadowLengthE = (BankH_E_LI[NodeTemp] + BuildH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
		else {
			shadowLengthE = (BankH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
	}

	/* Now I am going to calculate the delta1 and delta2 to calcualte the amount of effective shading
	Eq. #4 & 5 in Sun et al., 2015*/

	if (SolAltitude_LI_Uns[ts] == 0) { delta1 = -(BankH_E_LI[NodeTemp] + width_UnsTotal[Node]); }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAEast[NodeTemp], BSAEast[NodeTemp], TSAEast[NodeTemp]);
		if (VSAEast[NodeTemp] == MaxSky) {
			delta1 = ((BankH_E_LI[NodeTemp] + TreeH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_E_LI[NodeTemp] + width_UnsTotal[Node]);
		}
		else if (BSAEast[NodeTemp] == MaxSky) {
			delta1 = ((BankH_E_LI[NodeTemp] + BuildH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_E_LI[NodeTemp] + width_UnsTotal[Node]);
		}
		else {
			delta1 = (BankH_E_LI[NodeTemp] *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_E_LI[NodeTemp] + width_UnsTotal[Node]);
		}
	}
	if (SolAltitude_LI_Uns[ts] == 0) { delta2 = -(width_UnsTotal[Node]); }
	else
	{
		double MaxSky = maxValue(VSAEast[NodeTemp], BSAEast[NodeTemp], TSAEast[NodeTemp]);
		if (VSAEast[NodeTemp] == MaxSky) {
			delta2 = ((BankH_E_LI[NodeTemp] + TreeH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}
		else if (BSAEast[NodeTemp] == MaxSky) {
			delta2 = ((BankH_E_LI[NodeTemp] + BuildH_E_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}
		else {
			delta2 = (BankH_E_LI[NodeTemp] *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}

	}

	solarPhi = (cos(SolAltitude_LI_Uns[ts]) * fabs(sin(SolAzimuth_LI_Uns[ts] - StrAzimuth_LI[NodeTemp])));


	/* calculating the radiation extinction coefficient which is estimated as a function of LAI.
	Reference: http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract;  DeWalle (2010) */


	//Eq. #1 in Sun et al., (2015) and Sridhar et al. (2004)

	// The next two variables for calculating the extinction coefficient should be shortwave instead longwave based on the following paper
	double abovVegRadiation = SolDirE[ts] * (1 - SWreflVec_Uns[ts]) * ((sin(slope) * cos(SolAltitude_LI_Uns[ts]) * cos(SolAzimuth_LI_Uns[ts] -
		aspect)) + (cos(slope) * sin(SolAltitude_LI_Uns[ts])));

	double vegRadiation = SolDirE[ts] * (1 - SWreflVec_Uns[ts]);			// Direct shortwave radiation based on the Sridhar et al. 2004 ---> Eqn. 6 & 8

																		// Link address to Sridhar et al. (2004): 
																		//http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2004.tb01019.x/abstract
																		// Calculating the extinction coefficient based on (DeWalle, 2010 --> Eqn. 2)
																		// DeWalle (2010): http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract
	if (vegRadiation <= 0 || abovVegRadiation <= 0)
		extinctCoeff = 0;
	else
		extinctCoeff = -(log(abovVegRadiation / vegRadiation) / CanopyLAI);


	// caclulating the overhanging shade (like I3 in Ning Sun's work uisng following methodology:
	// http://ascelibrary.org/doi/abs/10.1061/%28ASCE%290733-9372%281998%29124%3A4%28304%29

	double overHangW_E = 0;
	double canDens = pm->get_can_dens();
	if (((0.1 * TreeH_E_LI[NodeTemp]) - CanDist_E_LI[NodeTemp]) < width_UnsTotal[Node]) {
		overHangW_E = ((0.1 * TreeH_E_LI[NodeTemp]) - CanDist_E_LI[NodeTemp]) * canDens;
	}
	else {
		overHangW_E = width_UnsTotal[Node] * canDens;
	}


	// calculating of the average path (Lavg) based on the table 1 of  Sun et al., (2015)
	// (1) No shade
	if (VSAEast[NodeTemp] > max(TSAEast[NodeTemp], BSAEast[NodeTemp])) {
		if ((delta1 <= 0.0) && (delta2 <= 0.0)) { avgPath = 0; }
		// (2) Partial shade, sun above buffer canopy
		else if ((delta1 <= 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * delta2) / solarPhi); }
		// (3) Partial shade, sun below buffer canopy
		else if ((delta1 <= 0.0) && (delta2 > Canbuffer)) { avgPath = ((0.5 * Canbuffer) / solarPhi); }
		// (4) Full shade, sun above buffer canopy
		else if ((delta1 > 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * (delta1 + delta2)) / solarPhi); }
		// (5) Full shade, sun partially below buffer canopy
		else if ((delta1 <= Canbuffer) && (delta2 > Canbuffer)) { avgPath = ((0.5 * (delta1 + Canbuffer)) / solarPhi); }
		// (6) Full shade, sun entirely below buffer canopy
		else if ((delta1 > Canbuffer) && (delta2 > Canbuffer)) { avgPath = (Canbuffer / solarPhi); }
		//Eq. #6 in Sun et al., (2015)
		// The shadow length as the initial value for shadow (Eq. #6 in Sun et al., 2015) for Eastern side
		if (shadowLengthE < CanDist_E_LI[NodeTemp]) { effShadowLengthE = 0; }
		else {
			effShadowLengthE = ((shadowLengthE - CanDist_E_LI[NodeTemp] - overHangW_E)
				* (1 - exp(-(extinctCoeff * avgPath))));
		}
	}
	else {
		if (shadowLengthE < BuildDist_E_LI[NodeTemp]) { effShadowLengthE = 0; }
		effShadowLengthE = shadowLengthE - BuildDist_E_LI[NodeTemp] - overHangW_E;
	}

	return effShadowLengthE;
}


double StreamTemperature::effectiveShadingW_Uns(const vector<double> &SolDirW, int Node, int ts)
{
	int NodeTemp ;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node* dx_unsteady) - 1; }
	// to get access the correct location in the vectors based on the dx of 
	// unsteady state.

	int col = colNum_Dist[NodeTemp] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int row = rowNum_Dist[NodeTemp] - 1;			// considering the (-1) to get a correct answer for "i*cols + j" in SlopeCal class i as the row number and j as the col number
	int totCols = SpaData->getcols();
	int index = row * totCols + col;

	slope = TI->getSlope(index);      //The answers for slope and aspect are in radian
	aspect = TI->getAspect(index);

	double delta1;
	double delta2;
	double avgPath;
	double solarPhi;
	double shadowLengthW;
	double extinctCoeff;
	double effShadowLengthW;

	double Canbuffer = Buff_W_LI[NodeTemp];

	//Eq. #3 in Sun et al., (2015)
	if (SolAltitude_LI_Uns[ts] == 0) { shadowLengthW = 0; }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAWest[NodeTemp], BSAWest[NodeTemp], TSAWest[NodeTemp]);
		if (VSAWest[NodeTemp] == MaxSky) {
			shadowLengthW = (BankH_W_LI[NodeTemp] + TreeH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
		else if (BSAWest[NodeTemp] == MaxSky) {
			shadowLengthW = (BankH_W_LI[NodeTemp] + BuildH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
		else {
			shadowLengthW = (BankH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]));
		}
	}

	/* Now I am going to calculate the delta1 and delta2 to calcualte the amount of effective shading
	Eq. #4 & 5 in Sun et al., 2015*/

	if (SolAltitude_LI_Uns[ts] == 0) { delta1 = -(BankH_W_LI[NodeTemp] + width_UnsTotal[Node]); }  // I used the 5 just as an example! I need to make a solid argument about the threshold!
	else
	{
		double MaxSky = maxValue(VSAWest[NodeTemp], BSAWest[NodeTemp], TSAWest[NodeTemp]);
		if (VSAWest[NodeTemp] == MaxSky) {
			delta1 = ((BankH_W_LI[NodeTemp] + TreeH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_W_LI[NodeTemp] + width_UnsTotal[Node]);
		}
		else if (BSAWest[NodeTemp] == MaxSky) {
			delta1 = ((BankH_W_LI[NodeTemp] + BuildH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_W_LI[NodeTemp] + width_UnsTotal[Node]);
		}
		else {
			delta1 = (BankH_W_LI[NodeTemp] *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(BankH_W_LI[NodeTemp] + width_UnsTotal[Node]);
		}
	}
	if (SolAltitude_LI_Uns[ts] == 0) { delta2 = -(width_UnsTotal[Node]); }
	else
	{
		double MaxSky = maxValue(VSAWest[NodeTemp], BSAWest[NodeTemp], TSAWest[NodeTemp]);
		if (VSAWest[NodeTemp] == MaxSky) {
			delta2 = ((BankH_W_LI[NodeTemp] + TreeH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}
		else if (BSAWest[NodeTemp] == MaxSky) {
			delta2 = ((BankH_W_LI[NodeTemp] + BuildH_W_LI[NodeTemp]) *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}
		else {
			delta2 = (BankH_W_LI[NodeTemp] *
				fabs(sin((SolAzimuth_LI_Uns[ts]) - StrAzimuth_LI[NodeTemp]) / tan(SolAltitude_LI_Uns[ts]))) -
				(width_UnsTotal[Node]);
		}

	}

	solarPhi = (cos(SolAltitude_LI_Uns[ts]) * fabs(sin(SolAzimuth_LI_Uns[ts] - StrAzimuth_LI[NodeTemp])));


	/* calculating the radiation extinction coefficient which is estimated as a function of LAI.
	Reference: http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract;  DeWalle (2010) */


	//Eq. #1 in Sun et al., (2015) and Sridhar et al. (2004)

	// The next two variables for calculating the extinction coefficient should be shortwave instead longwave based on the following paper
	double abovVegRadiation = SolDirW[ts] * (1 - SWreflVec_Uns[ts]) * ((sin(slope) * cos(SolAltitude_LI_Uns[ts]) * cos(SolAzimuth_LI_Uns[ts] -
		aspect)) + (cos(slope) * sin(SolAltitude_LI_Uns[ts])));

	double vegRadiation = SolDirW[ts] * (1 - SWreflVec_Uns[ts]);			// Direct shortwave radiation based on the Sridhar et al. 2004 ---> Eqn. 6 & 8

																			// Link address to Sridhar et al. (2004): 
																			//http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2004.tb01019.x/abstract
																			// Calculating the extinction coefficient based on (DeWalle, 2010 --> Eqn. 2)
																			// DeWalle (2010): http://onlinelibrary.wiley.com/doi/10.1111/j.1752-1688.2010.00423.x/abstract
	if (vegRadiation <= 0 || abovVegRadiation <= 0)
		extinctCoeff = 0;
	else
		extinctCoeff = -(log(abovVegRadiation / vegRadiation) / CanopyLAI);


	// caclulating the overhanging shade (like I3 in Ning Sun's work uisng following methodology:
	// http://ascelibrary.org/doi/abs/10.1061/%28ASCE%290733-9372%281998%29124%3A4%28304%29

	double overHangW_W = 0;
	double canDens = pm->get_can_dens();
	if (((0.1 * TreeH_W_LI[NodeTemp]) - CanDist_W_LI[NodeTemp]) < width_UnsTotal[Node]) {
		overHangW_W = ((0.1 * TreeH_W_LI[NodeTemp]) - CanDist_W_LI[NodeTemp]) * canDens;
	}
	else {
		overHangW_W = width_UnsTotal[Node] * canDens;
	}


	// calculating of the average path (Lavg) based on the table 1 of  Sun et al., (2015)
	// (1) No shade
	if (VSAWest[NodeTemp] > max(TSAWest[NodeTemp], BSAWest[NodeTemp])) {
		if ((delta1 <= 0.0) && (delta2 <= 0.0)) { avgPath = 0; }
		// (2) Partial shade, sun above buffer canopy
		else if ((delta1 <= 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * delta2) / solarPhi); }
		// (3) Partial shade, sun below buffer canopy
		else if ((delta1 <= 0.0) && (delta2 > Canbuffer)) { avgPath = ((0.5 * Canbuffer) / solarPhi); }
		// (4) Full shade, sun above buffer canopy
		else if ((delta1 > 0.0) && (delta2 <= Canbuffer)) { avgPath = ((0.5 * (delta1 + delta2)) / solarPhi); }
		// (5) Full shade, sun partially below buffer canopy
		else if ((delta1 <= Canbuffer) && (delta2 > Canbuffer)) { avgPath = ((0.5 * (delta1 + Canbuffer)) / solarPhi); }
		// (6) Full shade, sun entirely below buffer canopy
		else if ((delta1 > Canbuffer) && (delta2 > Canbuffer)) { avgPath = (Canbuffer / solarPhi); }
		//Eq. #6 in Sun et al., (2015)
		// The shadow length as the initial value for shadow (Eq. #6 in Sun et al., 2015) for Eastern side
		if (shadowLengthW < CanDist_E_LI[NodeTemp]) { effShadowLengthW = 0; }
		else {
			effShadowLengthW = ((shadowLengthW - CanDist_E_LI[NodeTemp] - overHangW_W)
				* (1 - exp(-(extinctCoeff * avgPath))));
		}
	}
	else {
		if (shadowLengthW < BuildDist_W_LI[NodeTemp]) { effShadowLengthW = 0; }
		effShadowLengthW = shadowLengthW - BuildDist_W_LI[NodeTemp] - overHangW_W;
	}

	return effShadowLengthW;
}


void StreamTemperature::netSolarDiffRadE_Uns(const vector<double> &SolDiffSW, int timeStep, int Node)
{
	DiffSW_UnsE = 0;
	switch (SolvingMethod)
	{
	case 1:
		// added by Reza for testing the Dr. Lautz's work: HFlux
		// I'diffuse in the calculations, Eq. #8 in Sun et al., 2015 for East side
		DiffSW_UnsE = SolDiffSW[timeStep] * SkyToView_UnsE[Node] * (1 - SWreflVec_Uns[timeStep]);
		break;

	case 2:
		// Using the fix coverage values
		if (calculation == 2) {
			DiffSW_UnsE = SolDiffSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec_Uns[timeStep]);
		}
		if (calculation == 3) {
			DiffSW_UnsE = SolDiffSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec[timeStep]);
		}
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");
	}
}

void StreamTemperature::netSolarDiffRadW_Uns(const vector<double> &SolDiffSW, int timeStep, int Node)
{
	DiffSW_UnsW = 0;
	switch (SolvingMethod)
	{
	case 1:
		// added by Reza for testing the Dr. Lautz's work: HFlux
		// I'diffuse in the calculations, Eq. #8 in Sun et al., 2015 for East side
		DiffSW_UnsW = SolDiffSW[timeStep] * SkyToView_UnsW[Node] * (1 - SWreflVec_Uns[timeStep]);
		break;

	case 2:
		// Using the fix coverage values
		if (calculation == 2) {
			DiffSW_UnsW = SolDiffSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec_Uns[timeStep]);
		}
		if (calculation == 3) {
			DiffSW_UnsW = SolDiffSW[timeStep] * (1 - SF_LI_Uns[Node]) * (1 - SWreflVec[timeStep]);
		}
		
		break;

	default:
		cout << "Wrong shortwave radiation methodology!!" << endl;
		AddLogComment("Wrong shortwave radiation methodology!!");
	}

}

void StreamTemperature::longWaveRadiation_Uns(const vector<double> &airTemperature, const vector<double> &relHumidity,
	const vector<double> &cloadinessCoeff, int timeStep, int Node) {
	double SBConst = 0.000000056696;			// Stefan-Boltzman constant, 5.6696*10-8 (kg�s-3�K-4) 

	LW_Atm_Uns = 0;
	LW_LC_Uns = 0;
	LW_Back_Uns = 0;
	LW_Uns = 0;
	double StrTemp;
	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node * dx_Interval) - 1; }

	if (calculation == 2) {
		StrTemp = Temp_unsteady[0][Node];
	}
	if (calculation == 3) {
		//StrTemp = Temp1_HRsize2[Node][timeStep];
		if (Node == 0) {
			StrTemp = Temp1_HRsize2[Node][timeStep];
		}
		else {
			StrTemp = Temp1_HRsize2[Node - 1][timeStep];
		}
	}
	double satVapPre_Uns = 0;
	double realVapPre_Uns = 0;
	double emis_Uns;
	switch (SolvingMethod)
	{
	case 1:
		// solving based on the calculated sky view factor

		satVapPre_Uns = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
		realVapPre_Uns = (relHumidity[timeStep] / 100.0) * satVapPre_Uns;
		emis_Uns = 1.72 * pow(((realVapPre_Uns) / (airTemperature[timeStep] + 273.2)), (1.0 / 7.0)) *
			(1 + (0.22 * (pow(cloadinessCoeff[timeStep], 2.0))));
		if (emis_Uns > 0.96) { emis_Uns = 0.96; }
		LW_Atm_Uns = 0.96 * emis_Uns * SBConst * pow((airTemperature[timeStep] + 273.2), 4) * SkyToView_UnsE[Node];
		// Land cover longwave radiation
		LW_LC_Uns = 0.96 * (1 - SkyToView_UnsE[Node]) * 0.96 * SBConst * pow((airTemperature[timeStep] + 273.2), 4.0);
		LW_Back_Uns = -0.96 * SBConst * pow((StrTemp + 273.2), 4.0);
		break;
	case 2:

		satVapPre_Uns = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
		realVapPre_Uns = (relHumidity[timeStep] / 100.0) * satVapPre_Uns;
		emis_Uns = 1.72 * pow(((realVapPre_Uns) / (airTemperature[timeStep] + 273.2)), (1.0 / 7.0)) *
			(1 + (pow((0.22 * cloadinessCoeff[timeStep]), 2.0)));		// Dingman p 282
		if (emis_Uns > 0.96) { emis_Uns = 0.96; }
		LW_Atm_Uns = 0.96 * emis_Uns * SBConst * pow((airTemperature[timeStep] + 273.2), 4) * SkyToView_UnsE[Node];
		// Land cover longwave radiation
		LW_LC_Uns = 0.96 * (1 - SkyToView_UnsE[Node]) * 0.96 * SBConst * pow((airTemperature[timeStep] + 273.2), 4.0);
		LW_Back_Uns = -0.96 * SBConst * pow((StrTemp + 273.2), 4.0);
		break;
	default:
		cout << "Wrong longwave radiation methodology!!" << endl;
	}

	LW_Uns = LW_Atm_Uns + LW_LC_Uns + LW_Back_Uns;
}

void StreamTemperature::latentHeat_Uns(const vector<double> &airTemperature, const vector<double> &relHumidity,
	const vector<double> &windSp, int timeStep, int Node) {

	double c_air = 1004;			// heat capacity of air (J/kg deg C)
	double rho_air = 1.2041;		// density of air at 20 deg C (kg/m^3)

	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node * dx_Interval) - 1; }

	latent_Uns = 0;
	evap_Rate = 0;
	double StrTemp;
	if (calculation == 2) {
		StrTemp = Temp_unsteady[0][Node];
	}
	if (calculation == 3) {
		//StrTemp = Temp1_HRsize2[Node][timeStep];
		if (Node == 0) {
			StrTemp = Temp1_HRsize2[Node][timeStep];
		}
		else {
			StrTemp = Temp1_HRsize2[Node - 1][timeStep];
		}
	}

	// <<<<<<<<< Evaporation section >>>>>>>>
	double L_e = 1000000 * (2.501 - (0.002361 * StrTemp));		// Calculate the latent heat of vaporization J/kg
																			// Calculate the slope of the saturated vapor pressure curve at a given air temperature
	double satVapPreLat = 0.611 * exp((17.27 * airTemperature[timeStep]) / (airTemperature[timeStep] + 237.3));
	double realVapPre = (relHumidity[timeStep] / 100.0) * satVapPreLat;
	double s = (4100.0 * satVapPreLat) / (pow((237.0 + airTemperature[timeStep]), 2.0)); //kPa / deg C
																				   // Calculate the aerodynamic resistance
	double r_a = 245.0 / ((0.54 * windSp[timeStep]) + 0.5); //[s / m]

														  // Calculate air pressure
														  // z = elevation of station where met data was obtained
	double Pa = 101.3 - (0.0105 * elev_LI[NodeTemp]);
	// Calculate psychrometric constant(kPa / deg C) (based on air pressure(Pa), (value should be adjusted for different site elevations),
	//ratio of water to dry air = .622, and the latent heat of water vaporization = 2.45E6 [J / kg deg C])
	double psy = (c_air * Pa) / (0.622 * 2450000.0);
	// Calculate the Penman open water evaporation
	double E = ((s * (SW_Uns + LW_Uns)) / (1000.0 * L_e * (s + psy)))
		+ ((c_air * rho_air * psy * (satVapPreLat - realVapPre)) / (1000.0 * L_e * r_a * (s + psy)));

	latent_Uns = (-rho_water * L_e * E);
	evap_Rate = E;
}

void StreamTemperature::sensibleHeat_Uns(const vector<double> &airTemperature, const vector<double> &windSp,
	const vector<double> &relHumidity, int timeStep, int Node) {
	Sensible_Uns = 0;
	int NodeTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node * dx_Interval) - 1; }

	double StrTemp;
	if (calculation == 2) {
		StrTemp = Temp_unsteady[0][Node];
	}
	if (calculation == 3) {
		//StrTemp = Temp1_HRsize2[Node][timeStep];
		// I don't know why I have this here!! Feb. 20
		if (Node == 0) {
			StrTemp = Temp1_HRsize2[Node][timeStep];
		}
		else {
			StrTemp = Temp1_HRsize2[Node - 1][timeStep];
		}
	}

	int method = pm->get_sens_method();
	double c_air = 1004;			// (J / kg deg C) value for the heat capacity of air
	double rho_air = 1.2041;		// (kg / m ^ 3) value for the density of air at 20 deg C

	double vaporLatHeat = 2499500;			// latent heat of vaporization (Joules�kg-1)
	double empiricalConst = 0.00000000159;       // empirical constant, (s�m-1�mb-1)

	sensible.resize(TotalDist);
	double z_veg, zd, z0, DH_DM, k, KH;
	double ews, ewa, Pa1, Br;
	switch (method)
	{
	case 1:
		z_veg = 0.25;		    // (m)  height of vegetation around stream
		zd = 0.7 * z_veg;			// zero - plane displacement, m
		z0 = 0.1 * z_veg;			//roughness height, m
		DH_DM = 1;               // ratio of diffusivity of sensible heat to diffusivity
								 // of momentum, m2 / s(1 under stable conditions)
		k = 0.4;                 //dimensionless constant
		KH = DH_DM * c_air * rho_air * ((pow(k, 2)) / (pow((log((elev_LI[NodeTemp] - zd) / z0)), 2))); // (J / C deg m3)			
		Sensible_Uns = -KH * windSp[timeStep] * (StrTemp - airTemperature[timeStep]); // W / m2
		break;
	case 2:
		ews = 0.61275 * exp((17.27 * StrTemp) / (237.3 + StrTemp)); //kPa
		ewa = (relHumidity[timeStep] / 100.0) * ews; //kPa
		Pa1 = 101.3 * pow(((293 - (0.0065 * elev_LI[NodeTemp])) / 293), 5.256);
		Br = 0.00061 * Pa1 * ((StrTemp - airTemperature[timeStep]) / (ews - ewa));
		if (Br > 1) { Br = 0.64; }
		Sensible_Uns = Br * latent_Uns;
		break;
	case 3:
		// Ning Sun's methodology
		ews = 0.61275 * exp((17.27 * StrTemp) / (237.3 + StrTemp)); //kPa
		ewa = (humidity / 100) * ews; //kPa
		Pa1 = 101.3 * pow(((293 - (0.0065 * elev_LI[NodeTemp])) / 293), 5.256);
		Br = 0.00061 * Pa1 * ((StrTemp - airTemperature[timeStep]) / (ews - ewa));
		if (Br > 1) { Br = 0.64; }
		Sensible_Uns = Br * rho_water * vaporLatHeat * empiricalConst * windSp[timeStep] * (airTemperature[timeStep] - StrTemp);
		break;
	default:
		cout << "Wrong sensible heat methodology!!" << endl;
	}
}

void StreamTemperature::bedSediment_Uns(const vector<double> &Ksed_index, const vector<double> &bedTemp,
	const vector<double> &depthMeas, int timeStep, int Node) {

	// streamTemp and sedimentTemp should be based on celsius
	bed_Uns = 0;
	int NodeTemp;
	double StrTemp;
	if (Node == 0) { NodeTemp = 0; }
	else { NodeTemp = (Node * dx_Interval) - 1; }

	if (calculation == 2) {
		StrTemp = Temp_unsteady[0][Node];
	}
	if (calculation == 3) {
		if (Node == 0) {
			StrTemp = Temp1_HRsize2[Node][timeStep];
		}
		else {
			StrTemp = Temp1_HRsize2[Node - 1][timeStep];
		}
	}

	bed_Uns = 2.0 * (Ksed_index[NodeTemp] * ((bedTemp[timeStep] - StrTemp) / (depthMeas[Node] / 2.0)));

	//bed_Uns = ((Pw_unsteady[Node] / width_UnsTotal[Node]) * (-Ksed_index[NodeTemp] * ((StrTemp - bedTemp[timeStep]) / (depthMeas[NodeTemp] / 2.0))));

}

void StreamTemperature::ConductionFlux_HR(vector<vector<double>>& thePorosity, const vector<double>& bedTemp,
	int timeStep, int Node, int RotationHR) {

	// ==========================================================
	// Variables used in bed conduction
	// Substrate Conduction Constants
	int	Sed_Density = 1600;							// kg/m3
	double	Sed_ThermalDiffuse = 0.0000045;			// m2/s
	int	Sed_HeatCapacity = 2219;					// J/(kg *C)
	// ======================================================
	// Variables used in bed conduction
	// Water Conduction Constants	
	double H2O_ThermalDiffuse = 0.00000014331;			// m2/s
	// ======================================================

	// Variables used in bed conduction
	// Calculate the sediment depth (conduction layer)
	double Sed_Depth;
	Sed_Depth = 10 * particleSize_Uns[Node] / 1000;
	if (Sed_Depth > 1) {
		Sed_Depth = 1;
	}
	if (Sed_Depth < 0.1) Sed_Depth = 0.1;

	double StrTemp;
	if (Node == 0) {
		StrTemp = Temp1_HRsize2[Node][timeStep];
	}
	else {
		StrTemp = Temp1_HRsize2[Node - 1][timeStep];
	}

	// ======================================================
	// Calculate Volumetric Ratio of Water and Substrate
	// Use this Ratio to Estimate Conduction Constants


	double Volume_Sediment = (1 - thePorosity[Node][timeStep]) * Pw_ALL_HR[Node][timeStep] * Sed_Depth * dx_Interval;
	double Volume_H2O = thePorosity[Node][timeStep] * Pw_ALL_HR[Node][timeStep] * Sed_Depth * dx_Interval;
	double Volume_Hyp = Pw_ALL_HR[Node][timeStep] * Sed_Depth * dx_Interval;
	double Ratio_Sediment = Volume_Sediment / Volume_Hyp;
	double Ratio_H2O = Volume_H2O / Volume_Hyp;
	double Density = (Sed_Density * Ratio_Sediment) + (rho_water * Ratio_H2O);
	double HeatCapacity = (Sed_HeatCapacity * Ratio_Sediment) + (c_water * Ratio_H2O);
	double ThermalDiffuse = (Sed_ThermalDiffuse * Ratio_Sediment) + (H2O_ThermalDiffuse * Ratio_H2O);

	// ======================================================
	// Calculate the conduction flux between water column & substrate

	if (Node == 0) {
		if (calculation == 2) {
			FluxConduction_HR[Node][timeStep] = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - Tobs_minBased[timeStep]) / (Sed_Depth / 2.0);
		}
		if (calculation == 3) {
			FluxConduction_HR[Node][timeStep] = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - obs_xo_LI[timeStep]) / (Sed_Depth / 2.0);
		}
		
	}
	else {
		FluxConduction_HR[Node][timeStep] = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - StrTemp) / (Sed_Depth / 2.0);
	}

	double Flux_Conduction_Alluvium = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - BedTn_LI_Uns[Node]) / (Sed_Depth / 2.0);

	// ======================================================
	// Calculate the amount of heat transfered to the sediments from stream water flowing into HR zone

	if (RotationHR > 0) {
		Flux_HEF = HyporheicExchange_HR[Node][timeStep] * rho_water * c_water * (Temp1_HRsize2[Node - 1][timeStep] - bedTemp[timeStep]) / (Pw_ALL_HR[Node][timeStep] * dx_Interval);
	}
	else {
		Flux_HEF = HyporheicExchange_HR[Node][timeStep] * rho_water * c_water * (Temp1_HRsize2[Node][timeStep] - bedTemp[timeStep]) / (Pw_ALL_HR[Node][timeStep] * dx_Interval);
	}

}



void StreamTemperature::bedSedimentHS(const vector<double>& bedTemp, int timeStep, int Node) {

	bed_Uns = 0;
	// ==========================================================
	// Variables used in bed conduction
	// Substrate Conduction Constants
	int	Sed_Density = 1600;							// kg/m3
	double	Sed_ThermalDiffuse = 0.0000045;			// m2/s
	int	Sed_HeatCapacity = 2219;					// J/(kg *C)
	// ======================================================
	// Variables used in bed conduction
	// Water Conduction Constants	
	double H2O_ThermalDiffuse = 0.00000014331;			// m2/s
	// ======================================================

	// Variables used in bed conduction
	// Calculate the sediment depth (conduction layer)
	double Sed_Depth;
	Sed_Depth = 10 * particleSize_Uns[Node] / 1000;
	if (Sed_Depth > 1) {
		Sed_Depth = 1;
	}
	if (Sed_Depth < 0.1) Sed_Depth = 0.1;

	double StrTemp = Temp_unsteady[0][Node];

	// ======================================================
	// Ratio Size of dominant substrate
	double Dummy1 = particleSize_Uns[Node] * (1.0 - embeddedness_Uns[Node]);
	// Ratio Conductivity of sand - low range
	double Dummy2 = 0.062 * embeddedness_Uns[Node];
	// Estimated Porosity
	double Porosity = 0.3683 * pow((Dummy1 + Dummy2), (-0.0641));
	// ======================================================
	// Calculate Volumetric Ratio of Water and Substrate
	// Use this Ratio to Estimate Conduction Constants


	double Volume_Sediment = (1 - Porosity) * Pw_unsteady[Node] * Sed_Depth * dx_Interval;
	double Volume_H2O = Porosity * Pw_unsteady[Node] * Sed_Depth * dx_Interval;
	double Volume_Hyp = Pw_unsteady[Node] * Sed_Depth * dx_Interval;
	double Ratio_Sediment = Volume_Sediment / Volume_Hyp;
	double Ratio_H2O = Volume_H2O / Volume_Hyp;
	double Density = (Sed_Density * Ratio_Sediment) + (rho_water * Ratio_H2O);
	double HeatCapacity = (Sed_HeatCapacity * Ratio_Sediment) + (c_water * Ratio_H2O);
	double ThermalDiffuse = (Sed_ThermalDiffuse * Ratio_Sediment) + (H2O_ThermalDiffuse * Ratio_H2O);

	// ======================================================
	// Calculate the conduction flux between water column & substrate

	if (Node == 0) {
		bed_Uns = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - Tobs_minBased[timeStep]) / (Sed_Depth / 2.0);
	}
	else {
		bed_Uns = ThermalDiffuse * Density * HeatCapacity * (bedTemp[timeStep] - StrTemp) / (Sed_Depth / 2.0);
	}
}