#include "InputShadingInfo.h"
#include <sstream>
Shading::Shading(Params* pm)
{
	
	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();
	totalts = hBankE.size();

	std::ifstream readShading(CurrDir + "\\Shading.dat");
	if (!readShading)
	{
		std::cout << "Shading.dat could not be opened!" << std::endl;
		return;
	}

	std::string temp;
	int tempId = -1.0;	
	int ID;
	double tempDistanc = -99999;

	double Temp_hBankE = -99999;
	double Temp_hTreeE = -99999;
	double Temp_hBuildingE = -99999;
	double Temp_bankDistE = -99999;
	double Temp_bankCanopyDistE = -99999;
	double Temp_bankBuildingDistE = -99999;
	double Temp_bufferWidthE = -99999;

	double Temp_hBankW = -99999;
	double Temp_hTreeW = -99999;
	double Temp_hBuildingW = -99999;
	double Temp_bankDistW = -99999;
	double Temp_bankCanopyDistW = -99999;
	double Temp_bankBuildingDistW = -99999;
	double Temp_bufferWidthW = -99999;

	double Temp_elev = -99999;

	double Temp_streamAzimuth = -99999;
	double tempInitialTemp = -99999;


	std::string startline;

	// getting the header line and the blank line out of the way
	//getline(readShading, temp);
	//getline(readShading, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	while (readShading.good())
	{
		getline(readShading, temp, ',');
		std::istringstream ss(temp);
		ss >> tempId;

		if (tempId <= distanceTotal)
		{
			sectionID.push_back(tempId);

			getline(readShading, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempDistanc;
			distanceShade.push_back(tempDistanc);

			getline(readShading, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> Temp_hBankE;
			hBankE.push_back(Temp_hBankE);
			getline(readShading, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> Temp_hTreeE;
			hTreeE.push_back(Temp_hTreeE);
			getline(readShading, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> Temp_hBuildingE;
			hBuildingE.push_back(Temp_hBuildingE);
			getline(readShading, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> Temp_bankDistE;
			bankDistE.push_back(Temp_bankDistE);
			getline(readShading, temp, ',');
			std::istringstream temp6(temp);
			temp6 >> Temp_bankCanopyDistE;
			bankCanopyDistE.push_back(Temp_bankCanopyDistE);
			getline(readShading, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> Temp_bankBuildingDistE;
			bankBuildingDistE.push_back(Temp_bankBuildingDistE);
			getline(readShading, temp, ',');
			std::istringstream temp9(temp);
			temp9 >> Temp_bufferWidthE;
			bufferWidthE.push_back(Temp_bufferWidthE);

			getline(readShading, temp, ',');
			std::istringstream temp10(temp);
			temp10 >> Temp_hBankW;
			hBankW.push_back(Temp_hBankW);
			getline(readShading, temp, ',');
			std::istringstream temp11(temp);
			temp11 >> Temp_hTreeW;
			hTreeW.push_back(Temp_hTreeW);
			getline(readShading, temp, ',');
			std::istringstream temp12(temp);
			temp12 >> Temp_hBuildingW;
			hBuildingW.push_back(Temp_hBuildingW);
			getline(readShading, temp, ',');
			std::istringstream temp13(temp);
			temp13 >> Temp_bankDistW;
			bankDistW.push_back(Temp_bankDistW);
			getline(readShading, temp, ',');
			std::istringstream temp14(temp);
			temp14 >> Temp_bankCanopyDistW;
			bankCanopyDistW.push_back(Temp_bankCanopyDistW);
			getline(readShading, temp, ',');
			std::istringstream temp15(temp);
			temp15 >> Temp_bankBuildingDistW;
			bankBuildingDistW.push_back(Temp_bankBuildingDistW);
			getline(readShading, temp, ',');
			std::istringstream temp17(temp);
			temp17 >> Temp_bufferWidthW;
			bufferWidthW.push_back(Temp_bufferWidthW);

			getline(readShading, temp, ',');
			std::istringstream temp16a(temp);
			temp16a >> Temp_elev;
			elev.push_back(Temp_elev);

			getline(readShading, temp, '\n');
			std::istringstream temp18a(temp);
			temp18a >> Temp_streamAzimuth;
			streamAzimuth.push_back(Temp_streamAzimuth);

		}
		else {
			getline(readShading, temp, '\n');
		}
	}
	
	totalts = bufferWidthW.size();
	readShading.close();
}