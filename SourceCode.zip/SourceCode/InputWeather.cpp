#include "InputWeather.h"
#include <sstream>
Weather::Weather(Params* pm)
{
	int StartDay = pm->get_starttime();
	int EndDay=pm->get_endtime();
	std::string CurrDir=pm->get_InputDir();
	totalts=WindSp.size();

	std::ifstream readWeather(CurrDir + "\\Weather.dat");
	if (!readWeather)
	{
		std::cout << "Weather.dat could not be opened!" << std::endl;
		//fileParseSuccess = false;
		return;
	}

	fstream infile(CurrDir + "\\Weather.dat");
	if (!infile.good()) {
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find Weather.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "Cannot find Weather.dat file" << std::endl;
		return;
	}
	std::cout << "Reading Weather.dat file\n" << std::endl;

	//yyyymmdd, Hr:Min:Sec, Tair(F), WndSpd(m / s), Cloudiness, Humidity, obsT_x0(*C), sedT(*C)
	std::string temp;
	int tempdate = -1.0;
	int HrMinSec;
	double tempTair = -99999;
	double tempWindSp = -99999;

	double tempCloadiness = -99999;
	double tempHumidity = -99999;
	double tempObsT = -99999;
	double tempSedT = -99999;
	
	
	std::string startline;

	// getting the header line and the blank line out of the way
	// getline(readWeather, temp);
	// getline(readWeather, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	bool insert = true;
	while (readWeather.good())
	{
		getline(readWeather, temp, ',');
		std::istringstream ss(temp);
		ss >> tempdate;
	
		if (tempdate <= EndDay && tempdate >= StartDay)
		{

			date.push_back(tempdate);
			getline(readWeather, temp, ',');
			std::istringstream time(temp);
			time >> HrMinSec;
			hour.push_back(HrMinSec);
			getline(readWeather, temp, ',');
			std::istringstream tair(temp);
			tair >> tempTair;
			tempTair = (tempTair - 32) * 5 / 9;
			Tair.push_back(tempTair); 
			getline(readWeather, temp, ',');
			std::istringstream wind(temp);
			wind >> tempWindSp;
			WindSp.push_back(tempWindSp);
			getline(readWeather, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempCloadiness;
			Cloadiness.push_back(tempCloadiness);

			getline(readWeather, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> tempHumidity;
			Humidity.push_back(tempHumidity);

			getline(readWeather, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> tempObsT;
			obsT_xo.push_back(tempObsT);

			getline(readWeather, temp, '\n');
			std::istringstream temp4(temp);
			temp4 >> tempSedT;
			sedT.push_back(tempSedT);
		
		}
		else
		{
			getline(readWeather, temp, '\n');
		}
	}


	date.push_back(tempdate);
	hour.push_back(HrMinSec);
	Tair.push_back(tempTair);
	WindSp.push_back(tempWindSp);
	Cloadiness.push_back(tempCloadiness);
	Humidity.push_back(tempHumidity);
	obsT_xo.push_back(tempObsT);
	sedT.push_back(tempSedT);

	totalts = WindSp.size();
	readWeather.close();
	std::cout << "Weather.dat reading done\n" << std::endl;
}



#ifdef TEST_WEATHER


int main( int argc, char* argv[])
{
	cout << "\n  Testing Weather class "
          << "\n===================================\n";

	std::string Path="";

	if(argc>1)
	{
		for(int i = 1;i<argc;i++)
		Path.append(argv[i]);		
	}
	else
	{
    cout << "\n  please enter path on which to find iTreeTempConfig file \n\n";
    return 1;
    }
	Path.append("\\iTreeTempConfig.xml");

	Params pm(Path);
	
	Weather wth(pm);

	double a=wth.getdate(5);


}

#endif