#ifndef INFLOW_H
#define INFLOW_H
///////////////////////////////////////////////////////////////
//  Inflow.h - read inflows from the input file              //
//               for the section we want to run the code     //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : Dec 2016
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Inflow class declarations                         //
///////////////////////////////////////////////////////////////

class Inflow
{
private:
	std::vector<int> count;

	std::vector<double> inflow_Q1;
	std::vector<double> inflow_Q2;
	std::vector<double> inflow_Q3;
	//std::vector<double> inflow_Q4;
	std::vector<double> inflow_T1;
	std::vector<double> inflow_T2;
	std::vector<double> inflow_T3;
	//std::vector<double> inflow_T4;
	

	int totalCount;

public:
	Inflow(Params* pm);
	~Inflow() {};

	double getInflowT_1(int i) { return inflow_T1[i]; }
	double getInflowT_2(int i) { return inflow_T2[i]; }
	double getInflowT_3(int i) { return inflow_T3[i]; }
	//double getInflowT_4(int i) { return inflow_T4[i]; }
	double getInflowQ_1(int i) { return inflow_Q1[i]; }
	double getInflowQ_2(int i) { return inflow_Q2[i]; }
	double getInflowQ_3(int i) { return inflow_Q3[i]; }
	//double getInflowQ_4(int i) { return inflow_Q4[i]; }



	int getCount() { return (totalCount - 2); }

};

#endif