#ifndef SOLARCALCULATION_H
#define SOLARCALCULATION_H
////////////////////////////////////////////////////////////////////
//  SOLARCALCULATION.h - Class to calculate the solar altitude    //
//                       solar Azimuth                            //
//             ver 1.0                                            //
//                                                                //
//  Language:     2015 Visual studio C++                          //
//  Platform:     Asus                                            //
//  Application:  iTree-StrealTemperature                         //
//  Author:       Reza Abdi,  SUNY-ESF                            //
//                reabdi@syr.edu                                  //
////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <vector>

#include "InputParams.h"
#include "InputSpatialData.h"
#include "TemperatureInputRepo.h"


#define PI			   3.14159265
#define MINPDEG        4.		    /* minutes per degree longitude */
#define DEGPRAD        57.29578	    /* degree per radian */
#define MINPHOUR       60
#define DAYPYEAR       365
#define RADPHOUR       0.2617994   /* radians per hour: Earth's Rotation 
                                   (2 PI rad/day) * (1 day/24 h) */
#define RADPDEG       (PI/180.0)	   /* radians per degree */
#define SOLARCON      1360.	        /* Solar constant (W/m^2) */

///////////////////////////////////////////////////////////////
//      SolarCalulation class declarations					 //   
//      Using the "CalcSolar.c" file in DHSVM model          //
///////////////////////////////////////////////////////////////

class SolarCalculation
{
public:
	
	SolarCalculation(TemperatureInputs* input);

	SolarCalculation() {};
	~SolarCalculation() {};

	void SolarDay();
	void SolarHour(int);
	//void SolarConst(float, float, float, float);
	void SolarConst();
	int DayOfYear();
	char IsLeapYear(int);

	double getSolarAzimuth() { return SolarAzimuth; }
	double getSolarAltitude() { return SolarAltitude; }
	// added by Reza for testing the Dr. Lautz's work: HFlux
	double getSolarZenith() { return SolarZenithHFlux; }

	double getSolAzimuth(int i) { return SolAzimuth[i]; }
	double getSolAltitude(int i) { return SolAltitude[i]; }
	vector<double> getSolZenith() { return SolZenith; }

private:
	TemperatureInputs* inp;
	Params *pm;
	SpatialData* SpaData;

	int startYear;
	int startMonth;
	int startDay;
	double latDeg;
	double latMin;
	double lngDeg;
	double lngMin;
	float stdMeridian;
	
	double SolarAzimuth = 0;
	double SolarAltitude = 0;		// SolarAltitude of sun from horizon (rads)
	int Jday;
	float Latitude;
	float Longitude;
	float NoonHour = 12.0;   //work in solar time
	float Sunrise;
	float Sunset;
	float Declination;
	float TimeAdjustment;
	float SunEarthDist;
	float SineSolarAltitude = 0.0;
	int DayLight;
	float SunMax = 0.0;
	float SolarTimeStep = 1.0;

	// added by Reza for testing the Dr. Lautz's work: HFlux
	double SolarZenith;		/* sun zenith angle (rads) */
	double SolarZenithHFlux;

	vector<double> SolAzimuth, SolAltitude, SolZenith;
};

#endif