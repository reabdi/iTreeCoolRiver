#ifndef SHADING_H
#define SHADING_H
///////////////////////////////////////////////////////////////
//  SHADING.h - read shading variables from input file       //
//                                                           //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : Nov 2016
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Shading class declarations                          //
///////////////////////////////////////////////////////////////

class Shading
{

private:
	std::vector<int> sectionID;
	std::vector<double> distanceShade;

	std::vector<double> hBankE;            // Bank hight in the Eastern stream side for each cross section
	std::vector<double> hTreeE;            // Tree hight in the Eastern stream side for each cross section
	std::vector<double> hBuildingE;		   // Building height 
	std::vector<double> bankDistE;		   // Distance between the edge of water and bank
	std::vector<double> bankCanopyDistE;    // The distance between Canopy and bank in eastern side
	std::vector<double> bankBuildingDistE;	// distance between the bank and the Building near the stream
	std::vector<double> bufferWidthE;      // Buffer width of the vegetation in Eastern side of the stream

	std::vector<double> hBankW;            // Bank hight in the Western stream side for each cross section
	std::vector<double> hTreeW;            // Tree hight in the Western stream side for each cross section
	std::vector<double> hBuildingW;		   // Building height 
	std::vector<double> bankDistW;		   // Distance between the edge of water and bank
	std::vector<double> bankCanopyDistW;    // The distance between Canopy and bank in Western side
	std::vector<double> bankBuildingDistW;	// distance between the bank and the Building near the stream
	std::vector<double> bufferWidthW;      // Buffer width of the vegetation in Western side of the stream

	std::vector<double> elev;

	std::vector<double> streamAzimuth;	   // Stream Azimuth for each section

	int totalts;


public:
	Shading(Params* pm);
	~Shading() {};

	double getsectionID(int i) { return sectionID[i]; }
	double gethDistanceShade(int i) { return distanceShade[i]; }

	double gethBankE(int i) { return hBankE[i]; }
	double gethTreeE(int i) { return hTreeE[i]; }
	double gethBuildingE(int i) { return hBuildingE[i]; }
	double getBankDistE(int i) { return bankDistE[i]; }
	double getBankCanopyDistE(int i) { return bankCanopyDistE[i]; }
	double getBankBuildingDistE(int i) { return bankBuildingDistE[i]; }
	double getBufferWidthE(int i) { return bufferWidthE[i]; }

	double gethBankW(int i) { return hBankW[i]; }
	double gethTreeW(int i) { return hTreeW[i]; }
	double gethBuildingW(int i) { return hBuildingW[i]; }
	double getBankDistW(int i) { return bankDistW[i]; }
	double getBankCanopyDistW(int i) { return bankCanopyDistW[i]; }
	double getBankBuildingDistW(int i) { return bankBuildingDistW[i]; }
	double getBufferWidthW(int i) { return bufferWidthW[i]; }

	
	double getElev(int i) { return elev[i]; }

	double getStreamAzimuth(int i) { return streamAzimuth[i]; }

	int gettotalts() { return (totalts - 2); }

};


#endif

