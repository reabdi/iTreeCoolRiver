#include "InputTime.h"
#include <sstream>
Time::Time(Params* pm)
{
	int totalTime = pm->get_total_time();
	std::string CurrDir = pm->get_InputDir();
	totalts = TimeMin.size();
	std::string temp;
	int date = 0;
	int tempTime = -99999;


	std::ifstream readTime(CurrDir + "\\Time.dat");
	if (!readTime.good())
	{
		std::cout << "Time.dat could not be opened!" << std::endl;
		//fileParseSuccess = false;
		return;
	}

	getline(readTime, temp);
	while (readTime.good())
	{
		getline(readTime, temp, ',');
		std::istringstream ss(temp);
		ss >> date;

		if (date <= (totalTime+1))
		{
			count.push_back(date);

			getline(readTime, temp, '\n');
			std::istringstream TimeDummy(temp);
			TimeDummy >> tempTime;
			TimeMin.push_back(tempTime);

		}
		else
		{
			getline(readTime, temp, '\n');
		}
	}

	totalts = TimeMin.size();
	readTime.close();

}
