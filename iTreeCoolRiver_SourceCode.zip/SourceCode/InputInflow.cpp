#include "InputInflow.h"
#include <sstream>
Inflow::Inflow(Params* pm)
{
	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();
	totalCount = inflow_T1.size();

	std::ifstream readInflow(CurrDir + "\\Inflow.dat");
	if (!readInflow)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find Inflow.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "Inflow.dat could not be opened!" << std::endl;
		return;
	}

	std::string temp;
	int tempDummy = -1.0;

	double temp_inflowT_1 = -99999;
	double temp_inflowT_2 = -99999;
	double temp_inflowT_3 = -99999;
	//double temp_inflowT_4 = -99999;
	double temp_inflowQ_1 = -99999;
	double temp_inflowQ_2 = -99999;
	double temp_inflowQ_3 = -99999;
	//double temp_inflowQ_4 = -99999;


	// reading in a CSV
	while (readInflow.good())
	{
		getline(readInflow, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			count.push_back(tempDummy);

			getline(readInflow, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> temp_inflowQ_1;
			inflow_Q1.push_back(temp_inflowQ_1);
			getline(readInflow, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> temp_inflowT_1;
			inflow_T1.push_back(temp_inflowT_1);
			getline(readInflow, temp, ',');
			std::istringstream temp3(temp);
			temp3 >> temp_inflowQ_2;
			inflow_Q2.push_back(temp_inflowQ_2);
			getline(readInflow, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> temp_inflowT_2;
			inflow_T2.push_back(temp_inflowT_2);
			getline(readInflow, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> temp_inflowQ_3;
			inflow_Q3.push_back(temp_inflowQ_3);
			getline(readInflow, temp, '\n');
			std::istringstream temp6(temp);
			temp6 >> temp_inflowT_3;
			inflow_T3.push_back(temp_inflowT_3);
			/*getline(readInflow, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> temp_inflowQ_4;
			inflow_Q4.push_back(temp_inflowQ_4);
			getline(readInflow, temp, '\n');
			std::istringstream temp8(temp);
			temp8 >> temp_inflowT_4;
			inflow_T4.push_back(temp_inflowT_4);*/

		}
		else {
			getline(readInflow, temp, '\n');
		}
	}
	totalCount = inflow_T1.size();
	readInflow.close();
}
