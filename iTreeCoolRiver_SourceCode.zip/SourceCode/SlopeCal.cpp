#include "SlopeCal.h"


SlopeCal::SlopeCal(TemperatureInputs* input) :inp(input)
{
	SpatialData* SpData = inp->getSpData();
	Params* pm = inp->getPM();
	DEM = SpData->getDEM2D();
	NODATA = SpData->getNODATA();
	rows = SpData->getrows();
	cols = SpData->getcols();
	cellsize = SpData->getcellsize();
	xllcorner = SpData->getxllcorner();
	yllcorner = SpData->getyllcorner();
	Slope.resize(rows*cols, NODATA);
	Aspect.resize(rows*cols, NODATA);
	NATB = 0;
	calSlopeAspect();							// Added by Reza Abdi (Feb. 17)
}

void SlopeCal::calSlopeAspect()
{

	std::cout << "\n  Calculating Slope and Aspect\n";
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j <cols; j++)
		{

			if (DEM[i][j] == NODATA)
			{
				NATB += 1;
				continue;
			}
			double fx = 0;
			double fy = 0;

			if (i - 1 > 0 && j - 1 > 0 && DEM[i - 1][j - 1] != NODATA)
			{
				fx += (DEM[i - 1][j - 1] - DEM[i][j]) / 8 / cellsize;
				fy += (DEM[i][j] - DEM[i - 1][j - 1]) / 8 / cellsize;
			}

			if (i - 1 > 0 && DEM[i - 1][j] != NODATA)
			{
				fx += (DEM[i - 1][j] - DEM[i][j]) / 4 / cellsize;
				//fy +=DEM[i][j]-DEM[i-1][j]/4/cellsize;
			}

			if (i - 1 > 0 && j + 1 < cols && DEM[i - 1][j + 1] != NODATA)
			{
				fx += (DEM[i - 1][j + 1] - DEM[i][j]) / 8 / cellsize;
				fy += (DEM[i - 1][j + 1] - DEM[i][j]) / 8 / cellsize;
			}

			if (i + 1<rows && j - 1 > 0 && DEM[i + 1][j - 1] != NODATA)
			{
				fx += (DEM[i][j] - DEM[i + 1][j - 1]) / 8 / cellsize;
				fy += (DEM[i][j] - DEM[i + 1][j - 1]) / 8 / cellsize;
			}

			if (i + 1 < rows && DEM[i + 1][j] != NODATA)
			{
				fx += (DEM[i][j] - DEM[i + 1][j]) / 4 / cellsize;
			}

			if (i + 1 < rows && j + 1 < cols && DEM[i + 1][j + 1] != NODATA)
			{
				fx += (DEM[i][j] - DEM[i + 1][j + 1]) / 8 / cellsize;
				fy += (DEM[i + 1][j + 1] - DEM[i][j]) / 8 / cellsize;
			}
			if (j + 1<cols && DEM[i][j + 1] != NODATA)
			{
				fy += (DEM[i][j + 1] - DEM[i][j]) / 4 / cellsize;
			}
			if (j - 1 > 0 && DEM[i][j - 1] != NODATA)
			{
				fy += (DEM[i][j] - DEM[i][j - 1]) / 4 / cellsize;
			}

			//for(int l = -1; l < 2; l++)
			//{
			//	if( i + l < 0 || i + l >= rows) break;
			//	for(int k = 1; k > -2; k--)
			//	{
			//		if( j + k < 0 || j + k >= cols || DEM[i+l][j+k] == NODATA) break;
			//	}			
			//		
			//   }

			//fx=(DEM[i-1][j-1]+2*DEM[i-1][j]+DEM[i-1][j+1]-DEM[i+1][j-1]-2*DEM[i+1][j]-DEM[i+1][j+1])/8/cellsize;
			//fy=(DEM[i+1][j+1]+2*DEM[i][j+1]+DEM[i-1][j+1]-DEM[i+1][j-1]-2*DEM[i][j-1]-DEM[i-1][j-1])/8/cellsize;
			////if ((i*cols+j)>(rows*cols-1))
			////	std::cout<<"\n  out of range";
			if (abs(fx) < 0.0000001)
				fx = 0;
			if (abs(fy) < 0.0000001)
				fy = 0;
			Slope[i*cols + j] = atan(sqrt(fx*fx + fy*fy));   // in rad
			if (fx == 0 && fy == 0)
				Aspect[i*cols + j] = 0;
			else if (fx == 0 && fy != 0)
				Aspect[i*cols + j] = 4.7123889 + atan(fy / fx);
			else
				Aspect[i*cols + j] = 4.7123889 + atan(fy / fx) - 1.5707963*fx / abs(fx);   // in rad

			//if (fx==0)
			//{std::cout<<"wait  "<<Slope[i*cols+j]<<"  "<<Aspect[i*cols+j]<<std::endl;}
			
			Slope.push_back(Slope[i*cols + j]);			// Added by Reza (Jan. 17)
			Aspect.push_back(Aspect[i*cols + j]);			// Added by Reza (Jan. 17)
		}

	}
	std::cout << "\n  Slope and Aspect Calculation Complete\n\n";
}
