
# include "InputParams.h"

Params::Params(std::string XmlFilename){

	//WinTools_Extracts::FileHandler _fh;
	//_fh.setCurrentDirectory(XmlFilename);

	//std::vector<std::string> PETFileV = _fh.getFiles(XmlFilename);
	//if(PETFileV.size()==0)
	//{
	//	cout<<"Unable to Find iTreeTempConfig File"<<endl;
	//	exit(1);
	//}

	// Load Xml configuration file in memory
	root = NULL;
	root = doc.Load(XmlFilename);
	t.setRoot(root);
	Inputs = t.GetElementByTagName("Inputs");
	Outputs = t.GetElementByTagName("Outputs");
	Temporal_Domain = t.GetElementByTagName("Temporal_Domain");
	Shading_inputs = t.GetElementByTagName("Shading_inputs");
	Unsteady_inputs = t.GetElementByTagName("Unsteady_inputs");
}


void Params::EatDoubleQuote(std::string& Dir)
{
	int i = 0;
	while (i < Dir.size())
	{
		if (Dir[i] == '\"')
			Dir.erase(i, 1);
		i++;
	}
}
std::string Params::get_InputDir()
{
	std::pair<std::string, std::string> inputFolder = Inputs[0]->GetAttributes(0);
	this->EatDoubleQuote(inputFolder.second);
	return inputFolder.second;

	//std::pair<std::string, std::string> stringpair = Dir[0]->GetAttributes(0);
	//this->EatDoubleQuote(stringpair.second);
	//return stringpair.second;
}

std::string Params::get_OutputDir()
{
	std::pair<std::string, std::string> outputFolder = Outputs[0]->GetAttributes(0);
	this->EatDoubleQuote(outputFolder.second);
	return outputFolder.second;

	//std::pair<std::string, std::string> stringpair = Dir[0]->GetAttributes(1);
	//this->EatDoubleQuote(stringpair.second);
	//return stringpair.second;

}




// Time Control          %set simulation time frame  
int Params::get_starttime()
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(0);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}
int Params::get_endtime()
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(1);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}



int Params::get_interval_hours()         //simulation time step in hour, such as 2
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(2);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}


// Added by Reza (Jun. 17)
int Params::get_starting_hour()         // starting hour in h
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(3);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}

// Added by Reza (Jun. 17)
int Params::get_SW_method()         // starting hour in h
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(4);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}


// Added by Reza (Jun. 17)
double Params::get_initial_temp()         // distance between the results m
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(5);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

double Params::get_can_dens()         // canopy density
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(6);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

double Params::get_roughness()         // roughness coefficient for Manning's equation
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(7);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

double Params::get_LAI()         // LAI value for the study site
{
	std::pair<std::string, std::string> stringpair = Temporal_Domain[0]->GetAttributes(8);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

// Added by Reza Abdi for reading in the required inputs from the XML file line#23 "shading_inputs" (Nov. 2016)
double Params::get_tar_lat()
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(0);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

double Params::get_tar_long()
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(1);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

int Params::get_tarRow()
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(2);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}

int Params::get_tarCol()
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(3);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}

// Added by Reza Abdi for reading in the required inputs from the XML file line#23 "shading_inputs" (Nov. 2016)
int Params::get_standardMeridian()
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(4);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}


// Added by Reza Abdi May. 17)
double Params::get_total_dist()							//  total distance of the stream (m) 
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(5);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

// Added by Reza Abdi May. 17)
double Params::get_caculation_method()							//  total distance of the stream (m) 
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(6);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}


// Added by Reza Abdi May. 17)
double Params::get_depth_bed()						// depth of measurment of bed data 
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(7);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}

// Added by Reza Abdi May. 17)
int Params::get_total_time()						// total time of running the model in min 
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(8);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}


// Added by Reza Abdi (May. 17)
int Params::get_sens_method()						// total time of running the model in min 
{
	std::pair<std::string, std::string> stringpair = Shading_inputs[0]->GetAttributes(9);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}

// Added by Reza Abdi (Aug. 17)
int Params::get_unsteady_dx()
{
	std::pair<std::string, std::string> stringpair = Unsteady_inputs[0]->GetAttributes(0);
	this->EatDoubleQuote(stringpair.second);
	return atoi(stringpair.second.c_str());
}

// Added by Reza Abdi (Aug. 17)
double Params::get_unsteady_dt()
{
	std::pair<std::string, std::string> stringpair = Unsteady_inputs[0]->GetAttributes(1);
	this->EatDoubleQuote(stringpair.second);
	return atof(stringpair.second.c_str());
}



#ifdef TEST_INPUTPARAMS

void display(double data, std::string param)
{

	std::cout<<"\n"<<"param"<<": \t"<<data;


}

int main( int argc, char* argv[])
{
	cout << "\n  Testing Weather class "
		<< "\n===================================\n";

	std::string Path="";

	if(argc>1)
	{
		for(int i = 1;i<argc;i++)
			Path.append(argv[i]);		
	}
	else
	{
		cout << "\n  please enter path on which to find iTreeTempConfig.xml file \n\n";
		return 1;
	} 


	Path.append("\\iTreeTempConfig.xml");
	Params pm(Path);
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_InputDir();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_OutputDir();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_GeoDBDir();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_WeatherDBDir();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_SoilDBDir();

	// iTree_hydro physics
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_iTree_hydro(); //"1" to triger the iTree-Hydro simulation for a watershed simulation

	//domain paramters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_cell_size(); //simulation cell size
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_nw_lat();                 //the north-west corner latitude
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_nw_long();                //the north-west corner longitude
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_rows();                   //total number of rows
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_cols();                   //total number of cols

	// Time Control          %set siimullation time frame  
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_starttime();             //simulaltion start time yyyymmdd
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_endtime();           //simulation end time yyyymmdd
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_interval_hours();          //simulation time step in hour, such as 2

	std::cout<<"\n"<<"param"<<": \t"<<pm.get_ref_row();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_ref_col();
	// Urban Parameters              %set urban related parameters
	//// urban category 21           %set urban category 21 parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_building_height21();                 //average building height in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_albedo21();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_emissivity21();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_road_width21();                   //averge road width in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_depression_storage21();              //averge depression storage for rain
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban21_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban21_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban21_a3();

	//// urban category 22           %set urban category 22 parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_building_height22();                 //average building height in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_albedo22();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_emissivity22();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_road_width22();                   //averge road width in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_depression_storage22();              //averge depression storage for rain
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban22_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban22_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban22_a3();

	//// urban category 23           %set urban category 23 parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_building_height23();                 //average building height in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_albedo23();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_emissivity23();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_road_width23();                   //averge road width in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_depression_storage23();              //averge depression storage for rain
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban23_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban23_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban23_a3();

	//// urban category 24           %set urban category 24 parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_building_height24();                 //average building height in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_albedo24();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_emissivity24();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_road_width24();                   //averge road width in meter
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_depression_storage24();           //averge depression storage for rain
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban24_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban24_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_urban24_a3();

	//// Vegetation Parameters         %set vegetation parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_LeafOnDay();                       //leaf on day (1-365)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_LeafOffDay();                      //leaf off day (1-365)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_LeafTransDays();                   //leaf transition day (1-365)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_veg_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_veg_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_veg_a3();
	//// Tree parameters              %set Tree parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_tree_height();                         //average tree height
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_tree_albedo();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_tree_emissivity();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_tree_resistance();              //canopy minimum resistance
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_TreeSL();                          //canopy maximum water storage depth (mm)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_TMax_LAI();                         //tree maximum Leaf Area Idex
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_TBarkLAI();                         // tree Bark LAI


	//// Short Vegetation parameters           %set short vegetation parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_short_height();                          //average tree height
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_short_albedo();                          //effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_short_emissivity();                      //emissivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_short_resistance();              //canopy minimum resistance
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_shortSL();                          //canopy maximum water storage depth (mm)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_SMax_LAI();                        //maximum Leaf Area Idex
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_SBarkLAI();                         // Bark LAI

	//// Soil parameters                       %set soil parameters
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_soil_albedo();                                  // soil effective albedo
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_soil_emissivity();                             // soil emissivity                       // soil saturation point 
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_SD0();                                    // initial root zone storage deficit   
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_Q0();                                      // stream initial discharge, only required for iTree-Hydro simulation
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_DWSMI();                                   // wetted mositure content
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_K0();                                      // surface hydraulic conductivity
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_m();                                       // decay factor, only required for iTree-Hydro simulation
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_MSD();                                     // maxmum root zone storage deficit
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_N();                                       //power of the power function decay, only required for iTree-Hydro simulation
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_WFS();                                     //wetting front suction factor (m)
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_T0();                                      //surface transmissivity 
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_Td();                                      //unsaturated zone time delay
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_wilting_point();                          // soil wilting point 
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_field_capacity();                         // soil field capacity 
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_saturation_point(); 
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_soil_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_soil_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_soil_a3();

	std::cout<<"\n"<<"param"<<": \t"<<pm.get_water_albedo();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_water_emissivity();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_water_a1();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_water_a2();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_water_a3();

	std::cout<<"\n"<<"param"<<": \t"<<pm.get_snow_albedo();
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_snow_emissivity();
	/// Routing Parameters                    %routing parameters, only required for iTree-hydro simulation
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_b();                                      //the time constant of Criss model
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_alfha();                                   //one of the time constant of YE model
	std::cout<<"\n"<<"param"<<": \t"<<pm.get_beta(); 

}

#endif