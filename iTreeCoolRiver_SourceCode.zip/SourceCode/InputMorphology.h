#ifndef MORPHOLOGY_H
#define MORPHOLOGY_H
///////////////////////////////////////////////////////////////
//  Morphology.h - read average velocity from input file     //
//               for the section we want to run the code     //
//  ver 1.0                                                  //
//                                                           //
//  Language:     2015 Visual studio C++                     //
//  Application:  iTree-Stream Temperature                   //
//  Author:       Reza Abdi,  SUNY-ESF                       //
//                reabdi@syr.edu                             //
///////////////////////////////////////////////////////////////
/*
Module Operations:
==================

Maintenance History:
====================
ver 1.0 : Dec 2016
- first release

*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "InputParams.h"
///////////////////////////////////////////////////////////////
//       Velocity class declarations                         //
///////////////////////////////////////////////////////////////

class Morphology
{
private:
	std::vector<int> count;

	std::vector<double> Distance;
	std::vector<double> Area;			// Area (m2)
	std::vector<double> Width;			// Stream width (m)
	std::vector<double> Depth;			// depth (m)
	std::vector<double> Discharge;
	std::vector<double> RowNumber;
	std::vector<double> ColNumber;
	std::vector<double> Longitude;
	std::vector<double> Latitude;

	std::vector<double> slope;			// for unsteady situation
	std::vector<double> Z_value;		// the Bankfull width to depth ratio

	int totalCount;

public:
	Morphology(Params* pm);
	~Morphology() {};

	double getDsitance(int i) { return Distance[i]; }
	double getArea(int i) { return Area[i]; }
	double getWidth(int i) { return Width[i]; }
	double getDepth(int i) { return Depth[i]; }
	double getDischarge(int i) { return Discharge[i]; }
	double getRowNumber(int i) { return RowNumber[i]; }
	double getColNumber(int i) { return ColNumber[i]; }
	double getLongitude(int i) { return Longitude[i]; }
	double getLatitude(int i) { return Latitude[i]; }

	double getSlope(int i) { return slope[i]; }
	double getZvalue(int i) { return Z_value[i]; }

	int getCount() { return (totalCount - 2); }

};











#endif



