#ifndef STREAMTEMPERATURE_H
#define STREAMTEMPERATURE_H
////////////////////////////////////////////////////////////////////
//  STREAMTEMPERATURE.h - Class to calculate the fluctuations     //
//                        of riperian shading effect on stream    //
//             ver 1.0                                            //
//                                                                //
//  Language:     2015 Visual studio C++                          //
//  Platform:     Asus                                            //
//  Application:  iTree-StrealTemperature                         //
//  Author:       Reza Abdi,  SUNY-ESF                            //
//                reabdi@syr.edu                                  //
////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <algorithm>	// std::min_element, std::max_element
#include <numeric>		// std::accumulate
#include <string>

#include <time.h>		// UNSTEADY STATE SITUATION
#include <stdlib.h>

#include "SolarCalculation.h"
#include "SlopeCal.h"						// For accessing thr aspect values of the domain
#include "InputSolarData.h"				// To get access the number of columns 

#include "TemperaturePrime.h"
#include "InputParams.h"

#define PI 3.14159265

#define rho_water  1000   // Density of water (kg / m ^ 3)
#define c_water 4182      // Specific heat capacity of water (J / kg deg C)


///////////////////////////////////////////////////////////////
//      StreamTemperature class declarations                 //
///////////////////////////////////////////////////////////////



class StreamTemperature
{
public:

	double sectionNr;       // Number of the cross section in the reach
	double eastBank;        // The height of bank in the eastern side
	double eastTree;        // The height of tree in the eastern side
	double eastDistance;    // The distance between bank and Canopy in the eastern side
	double westBank;        // The height of bank in the western side
	double westTree;        // The height of tree in the eastern side
	double westDistance;    // The distance between bank and Canopy in the western side
	
	double dirrectSW;        // Direct shortwave radiation
	double diffuseSW;        // Diffuse shortwave radiation
	double sectionWidth;     // The width of the stream in the desired location
	double downRadLW;        // longwave atmospheric radiation to the down
	double upRadLW;          // longwave atmospheric radiation to up, we need the net longwave radiation
	double windSpeed;        // Wind speed in desired time step based on initial inputs of i-Tree Air
	double sectiondx;		 // The length of the river reach
	double waterDepth;	     // The depth of the water
	double secArea;			 // cross sectional area (m^2)

	double avgVel;			 // average velocity of the section


	double satVaporPressure;			 // saturated vapor pressure (absolute humidity Kg/m^3) at Ta
	double realVaporPressure;			 // real vapor pressure (absolute humidity Kg/m^3 at Td)
	double satVapPre;
	double sedExchange;
	double cl;		//Cloudiness
	double humidity;

	double netDiffuseE;       // Net solar radiation (I'diffuse) in (Eq. #8 in Sun et al., 2015) for Eastern side
	double netDiffuseW;       // Net solar radiation (I'diffuse) in (Eq. #8 in Sun et al., 2015) for Western side
	double adjustedNetRadE;   // Adjusted direct radiation by topographic shading (I"direct) for Eastern side
	double adjustedNetRadW;   // Adjusted direct radiation by topographic shading (I"direct) for Western side


 
	double effShadowLengthW;      // The shadow length as the initial value for shadow (Eq. #6 in Sun et al., 2015) for Western side
	
	double sedimentHeat;        // Heat exchanged between stream and sediment bed (kcal�m-2�s-1)
	double nexThermalEnergyE;   // net exchange of thermal energy (Joules�m-1�s-1) for Eastern side
	double nexThermalEnergyW;  // net exchange of thermal energy (Joules�m-1�s-1) for Western side

	std::vector<double> qEast;			// added in May 17
	std::vector<double> qWest;
	
	double sedimentTemp;       // sediment temperature (C)
	double airTemp;            // air temprature (C)
	double dewTemp;	           // dew point temperature , the input file is in F but shoud be change to c
	double surfaceTemp;         // cross sectionally averaged surface temperature (C)
	double deltaT;

	double solarAzimuth;
	double solarAltitude;
	double streamAzimuth;

	// added by Reza for testing the Dr. Lautz's work: HFlux
	double solarZenith;
	double SWrefl;
	double depthMeasBed;
	int TotalTime;
	int TotalDist;
	int SolvingMethod;				// The methodology for solving the SW radiation flux, 1 is based on sky view factor and 2 is based on fixed values like 0.25 and 0.75 as the SF and sky view
	double CanopyLAI;
	vector<vector<double>> solarSW_Dir_LI2D, solarSW_Diff_LI2D, aitTemp_LI2D, rela_humidity_LI2D, windSp_LI2D, cloudiness_LI2D;
	vector<double> hourlyTime, SWreflVec;
	vector<double> adjustedDirSW_E, adjustedDirSW_W, adjustedDiffSW_E, adjustedDiffSW_W, atmLW, lcLW, backLW, latent, sensible, bed;
	vector<double> BankH_E_LI, TreeH_E_LI, BankH_W_LI, TreeH_W_LI, BuildH_E_LI, BuildH_W_LI, CanDist_E_LI, 
		CanDist_W_LI, BanDist_E_LI, BanDist_W_LI, BuildDist_E_LI, BuildDist_W_LI, Buff_E_LI, Buff_W_LI, elev_LI, 
		StrAzimuth_LI;
	vector<double> colNum_Dist, rowNum_Dist, LongValue_Dist, latValue_Dist;
	vector<double> SolAzimuth_LI, SolAltitude_LI;
	vector<double> SF_LI;
	vector<double> SkyToView_LI;
	vector<double> secWidth_LI, secDepth_LI, secSlope_LI, secArea_LI, Z_LI;
	vector<vector<double>> heat_flux_2D, SWDir_2D, SWDiff_2D, SW_2D, LW_2D, atmLW_2D, LCLW_2D, backLW_2D, Latent_2D, Sensible_2D, Bed_2D;
	vector<vector<double>> T;  // T: temperature array


	vector<double> fluxxx, tNew;
	// added by Reza, Jun. 17
	vector<double> SkyV_E, SkyV_W, VSAEast, TSAEast, BSAEast, VSAWest, TSAWest, BSAWest;
	
	// ANALYSING THE ENTERIOR RESULTS AND VECTOR - REZA
	vector<vector<double>> a_c, b_c, c_c, o, p, q, o_c, p_c, q_c, d, g, k, m, a, b, c;
	vector<vector<double>> depth_total, width_total, area_total, wp_total, ksed1;
	vector<vector<double>> t_minBased;

	vector<vector<double>> Q_half_min1, volume1, discharge_time1;
	 

	vector<vector<double>> A;
	vector<double> x, b_copy;


	// UNSTEADY STATE VARIABLES =============================================== (Aug. 17)
	double dx_unsteady, dtime_unsteady;
	int TotalTime_min, TotalDist_stable, TotalTime_Uns;
	int time_Uns, Node_Uns;
	int flag_BC;
	vector<double> delta_t, S1, S2;
	vector<double> SkyToView_UnsE, SkyToView_UnsW, SF_LI_Uns,
		SWreflVec_Uns, SolAzimuth_LI_Uns, SolAltitude_LI_Uns;
	vector<int> Flag_SkipNode;
	vector<vector<double>> Q, Temp_unsteady, depth_unsteady, AreaX, velocity_unsteady, inflow_Rate, inflow_Temp;
	vector<double> Q_minBased, inflow_Q_2_min, inflow_Q_3_min, Tobs_minBased, inflow_temp_2_temp, inflow_temp_3_temp, 
		width_unsteady, Pw_unsteady, Rh_unsteady, Z_unsteady, n_unsteady, s_unsteady, width_UnsTotal, discharge_Unsteady;
	vector<double> Q_GW, Temp_GW, depth_AvgUns;
	vector<vector<double>> Q_In, T_In, T_trib_shift;
	vector<double> conductivity_Uns, particleSize_Uns, embeddedness_Uns, Hyporheic_Exchange, BedTn_LI_Uns, hyp_Slope_Uns;
	vector<double> dispersion, T_unsTemporary;
	double Porosity, Froude_Densiometric;
	double evap_Rate = 0;
	double DirSW_UnsE, DirSW_UnsW, DiffSW_UnsE, DiffSW_UnsW, LW_Atm_Uns, LW_LC_Uns, LW_Back_Uns, LW_Uns,
		latent_Uns, DirSW_Uns_temp, DiffSW_Uns_temp, SW_Uns, Sensible_Uns, bed_Uns;
	vector<vector<double>> Flux_Total, Flux_Conduction, Flux_Evaporation, Flux_Convection, FLux_AtmLW, Flux_LCLW, Flux_BackLW, Flux_LW, Flux_DirSW,
		Flux_DiffSW, Flux_SW, T_Uns, depth_Uns;

	vector<vector<double>> hour_Flux_Total, hour_Flux_Conduction, hour_Flux_Evaporation, hour_Flux_Convection, hour_FLux_AtmLW,
		hour_Flux_LCLW, hour_Flux_BackLW, hour_Flux_LW, hour_Flux_DirSW,
		hour_Flux_DiffSW, hour_Flux_SW, hour_T_Uns, hour_depth_Uns;

	double slope;
	double aspect;
	
	
	double SenHeat;
	double SenHeatRes;
	double skyViewGeneral;
	double skyViewFacW;
	double skyViewFacE;
	


	double treeP;
	double soilP;
	double shortVegP;
	double imperP;
	double waterP;



	vector<double> totAirTemp;  // A vector for accessing the generated air temperature for the targeted cell in Cell.h and TemperaturePrime class

	Params* pm;
	TemperatureInputs* inp;

	SolarCalculation *solarCal;

	SlopeCal* TI;
	SpatialData* SpaData;
	

	
	
	// For calculating the avertage deltaT
	//Time* tim;
	//Inflow* inf;


	StreamTemperature(TemperatureInputs* inp, SolarCalculation* solarCal);
	StreamTemperature() {}
	//~StreamTemperature() {}
	void clear();
	// For calling the input files fomr the shading class and the required parameters which is already exist.
	//void initialVariable(int ts, int id);	
	// Calculating the sky view factor adjusted by riparian vegetation buffer considering Eastern info
	// and then calculating the "net solar radiation" using Eastern data (Eq. #8 in Sun et al., 2015)
	void netSolarDiffRadE(const vector<double> &, int);

	// Calculating the sky view factor adjusted by riparian vegetation buffer considering Western info
	// and then calculating the "net solar radiation" using Western data (Eq. #8 in Sun et al., 2015)
	void netSolarDiffRadW(const vector<double> &, int);

	/* Here uisng the equation in Sun et al., (2015), I am going to calculate the "effective shading width (Xeff)" 
	   This function covers equations 1, 3, 4, 5 and 6 and also table 1 of the mentioned paper.
	   Like the previous set of functions, I am going to define two similar fuctions for east and west side.*/
	double effectiveShadingE(const vector<double> &, int, int);		// editted by Reza (Jun. 17)
	double effectiveShadingW(const vector<double> &, int, int);		// editted by Reza (Jun. 17)

	


	/* Here, using two following function, I am going to calculate the adjusted direct radiation by topographic shading.
	   This term (I"direct) is represented in equation #07 in Sun et al., (2015) */
	// modified by Reza for testing the Dr. Lautz's work: HFlux
	void adjustedDirRadE(const vector<double> &, int);  // editted by Reza (Aug. 17)
	void adjustedDirRadW(const vector<double> &, int);  // editted by Reza (Jun. 17)

	/* For the stream segments of the heat exchange between stream and sediment bed (qsed) 
	Chapra et al. (2008) - QUAL2K model  */
	//double streamBedTransfer(int);

	/* Calculating the surface temperature. Surface temperature is a function of the surface sensible heat and resistance, as well as
	the air temperature, specific heat, and density. So we can calculate the Surface temperature based on the the mentioned terms. 
	According to the Yang et al., (2013) --> Eqn. 3, 5 and 7 we can argue that: 
	Ts = (H*rH + airDensity * Specific Heat of air) / airDensity * Specific Heat of air */
	//double surTemperature(int, double, double);

	/* Sky view factor:
	 calculating the sky view factor above the riparian vegetation 
	 for Eastern bank 
	 Reference: DHSVM model, CanopyShading.c CPP Line #197 */
	//double CalcCanopySkyViewE();

	// Sky view factor: for Western bank
	//double CalcCanopySkyViewW();

	/* The net transfer of thermal energy (qw) due to shortwave solar radiation, longwave atmospheric radiation,
	blackbody radiation from the water surface, latent and sensible heat conduction and sediment heat flux 
	(e.g., Chen et al, 1998; Chapra et al, 2008; Yearsley, 2009)*/
	//void netExchangeE(int, double, double);    //East side
	//void netExchangeW(int);    // West side

	// this function will calculate the saturation vapor pressure based on the surface temperature (mb)
	//double satVapPressure(int, double, double);
	// this function will calculate the real vapor pressure based on the air temperature (mb)
	//double realVapPressure();

	// The last equation for calculating the cross-sectionally averaged water temperature difference (dt) (degree C)
	void avgTemperature();
	// added by Reza for testing the Dr. Lautz's work: HFlux
	void solarReflectivity();
	void longWaveRadiation(const vector<double> &, const vector<double> &, const vector<double> &, const vector<double> &, int);
	void latentHeat(const vector<double> &, const vector<double> &, const vector<double> &, const vector<double> &, int);
	void sensibleHeat(const vector<double> &, const vector<double> &, const vector<double> &, const vector<double> &, int);
	void bedSediment(const vector<vector<double>> &, const vector<vector<double>> &, const vector<double> &, const vector<double> &,
		const vector<double> &, const vector<double> &, int);
	void minToHour(int, int, vector<int> &);
	double interpolate(vector<double>&, vector<double>&, double, bool);
	vector<double> gauss(vector<vector<double>> &);
	double maxValue(double, double, double);

	vector<double> interp1(std::vector<double> &, std::vector<double> &, std::vector<double> &);	//Nearest interpolation

	// UNSTEADY STATE FUNCTIONS =============================================== (Aug. 17)
	void hydroStability();
	void initialConditions(int);
	void hydraulics(int, int);
	void McCormick_Temp1(const vector<double> &, int);
	void McCormick_Temp2(const vector<double> &, int);
	void mixing(int, int, int);
	void adjustedDirRadE_Uns(const vector<double> &, int, int);
	void adjustedDirRadW_Uns(const vector<double> &, int, int);
	double effectiveShadingE_Uns(const vector<double> &, int, int);
	double effectiveShadingW_Uns(const vector<double> &, int, int);
	void netSolarDiffRadE_Uns(const vector<double> &, int, int);
	void netSolarDiffRadW_Uns(const vector<double> &, int, int);
	void longWaveRadiation_Uns(const vector<double> &, const vector<double> &, const vector<double> &, int, int);
	void latentHeat_Uns(const vector<double> &, const vector<double> &, const vector<double> &, int, int);
	void sensibleHeat_Uns(const vector<double> &, const vector<double> &, const vector<double> &, int, int);
	void bedSediment_Uns(const vector<double> &, const vector<double> &, const vector<double> &, int, int);

	void skyViewE();
	void skyViewW();

	void AddLogComment(std::string comment);
	int getTotalTime() { return TotalTime; }
	double getTotalDist() { return TotalDist; }
	vector<vector<double>> getModT() { return T; }
	vector<vector<double>> getSWDir_2D() { return SWDir_2D; }
	vector<vector<double>> getSWDiff_2D() { return SWDiff_2D; }
	vector<vector<double>> getAtmLW() { return atmLW_2D; }
	vector<vector<double>> getLcLW() { return LCLW_2D; }
	vector<vector<double>> getBackLW() { return backLW_2D; }
	vector<vector<double>> getLatent() { return Latent_2D; }
	vector<vector<double>> getSensible() { return Sensible_2D; }
	vector<vector<double>> getBed() { return Bed_2D; }
	vector<vector<double>> getSW() { return SW_2D; }
	vector<vector<double>> getLW() { return LW_2D; }
	vector<vector<double>> getHeatFlux() { return heat_flux_2D; }
	vector<vector<double>> getT_MinBased() { return t_minBased; }

	vector<vector<double>> get_TotalFlux() { return Flux_Total; }
	vector<vector<double>> get_Conduction() { return Flux_Conduction; }
	vector<vector<double>> get_Evaporation() { return Flux_Evaporation; }
	vector<vector<double>> get_Convection() { return Flux_Convection; }
	vector<vector<double>> get_AtmLW() { return FLux_AtmLW; }
	vector<vector<double>> get_LCLW() { return Flux_LCLW; }
	vector<vector<double>> get_BackLW() { return Flux_BackLW; }
	vector<vector<double>> get_Flux_LW() { return Flux_LW; }
	vector<vector<double>> get_Flux_DirSW() { return Flux_DirSW; }
	vector<vector<double>> get_Flux_DiffSW() { return Flux_DiffSW; }
	vector<vector<double>> get_Flux_SW() { return Flux_SW; }
	vector<vector<double>> get_T_Uns() { return T_Uns; }
	vector<vector<double>> get_depth_Uns() { return depth_Uns; }

	vector<vector<double>> get_hour_TotalFlux() { return hour_Flux_Total; }
	vector<vector<double>> get_hour_Conduction() { return hour_Flux_Conduction; }
	vector<vector<double>> get_hour_Evaporation() { return hour_Flux_Evaporation; }
	vector<vector<double>> get_hour_Convection() { return hour_Flux_Convection; }
	vector<vector<double>> get_hour_AtmLW() { return hour_FLux_AtmLW; }
	vector<vector<double>> get_hour_LCLW() { return hour_Flux_LCLW; }
	vector<vector<double>> get_hour_BackLW() { return hour_Flux_BackLW; }
	vector<vector<double>> get_hour_Flux_LW() { return hour_Flux_LW; }
	vector<vector<double>> get_hour_Flux_DirSW() { return hour_Flux_DirSW; }
	vector<vector<double>> get_hour_Flux_DiffSW() { return hour_Flux_DiffSW; }
	vector<vector<double>> get_hour_Flux_SW() { return hour_Flux_SW; }
	vector<vector<double>> get_hour_T_Uns() { return hour_T_Uns; }
	vector<vector<double>> get_hour_depth_Uns() { return hour_depth_Uns; }

	vector<double> getHypEx() { return Hyporheic_Exchange; }
	vector<double> getQ_GW() { return Q_GW; }

	double getSkyViewFactorW(int i) { return SkyV_W[i]; }
	double getSkyViewFactorE(int i) { return SkyV_E[i]; }


	double getSenHeat(int) { return SenHeat; }
	double getSenHeatRes(int) { return SenHeatRes; }
	double getAirTemp(int) { return airTemp; }
	double getSurfaceTemp(int) { return surfaceTemp; }
	double getRealVapPressure(int) { return realVaporPressure; }
	double getSatVapPressure(int) { return satVaporPressure; }
	double getSedimentTransprt(int) { return sedimentHeat; }
	double getSkyView(int i) { return SkyV_E[i]; }

	double getNexThermalEnergyE(int) { return nexThermalEnergyE; }
	double getNexThermalEnergyW(int) { return nexThermalEnergyW; }


	double getDeltaTemp(int) { return deltaT; }

	

};

#endif