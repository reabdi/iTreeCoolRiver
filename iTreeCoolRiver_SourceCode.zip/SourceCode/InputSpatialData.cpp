#include "InputSpatialData.h"


// constructor of watershedData
SpatialData::SpatialData(Params* pa)
{   

	std::string inputDir=pa->get_InputDir();
	readDEMdata(inputDir); 
}



void SpatialData::readDEMdata(string& inputDir)
{

	const int MAX = 80;
	char buffer[MAX];

	ifstream infile(inputDir+"\\DEM.txt");    
	if(!infile.good()){
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find DEM.txt file needed to run simulation.\n";
		logfile.close();
		std::cout<<"Cannot find DEM.txt file"<<std::endl;
		return;}
	std::cout<<"Reading DEM.txt file\n"<<std::endl;

	infile	>>buffer>> cols 
		>>buffer>> rows 
		>>buffer>>xllcorner 
		>>buffer>>yllcorner 
		>>buffer>> cellsize 
		>>buffer>> NODATA;

	DEM2D.reserve(rows);
	for(int k=0; k<rows; k++)
	{
		std::vector<double> temp(cols);
		DEM2D.push_back(temp);
	}

	double tempdata = 0.0;
	for(int i=0; i<rows; i++)
	{
		for (int j=0; j<cols; j++)
		{ 
			infile >> tempdata;
			DEM2D[i][j]=tempdata;
			DEM1D.push_back(tempdata);
		}
	}
	infile.close(); 
		//std::cout<<"DEM.txt file done"<<std::endl;

}



