#ifndef INPUTSPATIALDATA_H
#define INPUTSPATIALDATA_H
//////////////////////////////////////////////////////////////////////////////////////
//																		            //
// InputWatershed.h - read in spatial data of a watershed                           //																		   
// ver 1.0                                                                          //
// Language:    Visual C++ 2010                                                     //
// Platform:                     										            //
// Application: iTree-Temperature, Winter 2013                                      //
// Programmer: Yang Yang, yyang3117@gmail.com				                        //																	   	
//////////////////////////////////////////////////////////////////////////////////////
/*
  

  Module Operations: 
  ==================
  constructor: WatershedData(Params &pa)  
  This class is to read the spatial information of a watershed
  DEM
  Land cover
  Impervious cover
  Tree canopy cover
  calculate the slope, aspect, accumulation area, TIe, TIn
  and assign these values to cells within the watershed

  Public Interface:
  =================
  WatershedData waterD(&pa);
  

  Build Process:
  ==============
  Required files
    - InputWatershed.cpp
	
  Build commands 
    - devenv PASATH.sln
   
  Maintenance History:
  ====================

 */



#include <string>
#include <iomanip>
#include <cstdlib>
#include <sys/stat.h>

#include <vector>
#include <math.h>
#include "InputParams.h"





class SpatialData
{

  public:
	    
		SpatialData(Params* pa);
	
		int getcols () {return cols;}
		int getrows () {return rows;}
		double getNODATA () {return NODATA;}
		double getxllcorner(){return xllcorner;}
		double getyllcorner(){return yllcorner;}
		double getcellsize(){return cellsize;}
		std::vector<std::vector<double>> getDEM2D(){return DEM2D;}
		//void writeOutputTest(std::string outputDir);
		double getDEM1D(int i){return DEM1D[i];}

		friend class TemperatureInputs;
		//void furtherInitialize(Params &pa, Solar& sl, Urban& urb21, Urban& urb22, Urban& urb23, Urban& urb24, Vegetation& tr, Vegetation& shortveg);
		//friend class HydroHeatSim;
	 //    friend class OutputWriter;
   private:
	    
	//	std::vector<std::vector<Cell*>> Cells;
		int rows;
		int cols;
		double xllcorner;
		double yllcorner;
        double cellsize;    // cell edge length  
	    double NODATA;    // the nodata value in the DEM
      

		std::vector<std::vector<double>> DEM2D;
		std::vector<double> DEM1D;

	   void readDEMdata(string& inputDir); 


	
};

#endif