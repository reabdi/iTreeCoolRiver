#include"Tree.h"
#include <cctype>
/////////////////////////////////////////////////////////////////////////////////////////////////
// Tree.cpp  - Uses Node data type to create a tree. Implements/tests what is defined in tree.h                                             //
// version 1.4                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:         Provides functionality for traversing, building and 
//                        //
// Author:              Sanyam Chaudhary ,                                                     //
//                                                                                             //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////


void Tree::WalkTree(Node * pParent, std::map<std::string, double> &dict)
{
	nodes.push_back(pParent);
	Node * pChild;
	for (int i = 0; i < (pParent->CountChildren()); i++)
	{
		pChild = pParent->NextUnmarkedChild();
		//std::cout << pChild->getNodeName();
		if (pChild != 0)
		{
			pChild->isVisited() = true;
			WalkTree(pChild, dict);
		}
		if (pChild->getNodetype() == "TextNode")
		{
			std::string key = pParent->getNodeName();
			double value = atof(pChild->getNodeName().c_str());
			dict.insert(std::pair<std::string, double>(key, value));
		}

	}
}

void Tree::WalkTree(Node * pParent, std::map<std::string, std::string> &dict)
{
	nodes.push_back(pParent);
	Node * pChild;
	for (int i = 0; i < (pParent->CountChildren()); i++)
	{
		pChild = pParent->NextUnmarkedChild();
		//std::cout << pChild->getNodeName();
		if (pChild != 0)
		{
			pChild->isVisited() = true;
			WalkTree(pChild, dict);
		}
		if (pChild->getNodetype() == "TextNode")
		{
			std::string key = pParent->getNodeName();
			std::string value = pChild->getNodeName();
			value.erase(0, 1);
			dict.insert(std::pair<std::string, std::string>(key, value));
		}

	}
}

void Tree::WalkTree(Node * pParent, std::vector<std::vector<std::map<std::string, double> > > &vofomaps, std::vector<std::string> &names)
{
	nodes.push_back(pParent);
	Node * pChild;
	Node * pGrandChild;
	for (int i = 0; i < (pParent->CountChildren()); i++)
	{
		pChild = pParent->GetChild(i);
		std::vector<std::map<std::string, double> > temp;
			for (int j = 0; j < pChild->CountChildren(); ++j)
			{
			
				pGrandChild = pChild->GetChild(j);
				std::map<std::string, double> tDict;
				WalkTree(pGrandChild, tDict, names);
				temp.push_back(tDict);
			}
		  vofomaps.push_back(temp);
		}

}



//-----------------------<Walks the tree in Depth First Order>--------------------------------------

void Tree::WalkTree(Node * pParent, std::map<std::string, double> &dict, std::vector<std::string> &names)
{
	nodes.push_back(pParent);
	Node * pChild;
	for (int i = 0; i < (pParent->CountChildren()); i++)
	{
		pChild = pParent->NextUnmarkedChild();
		//std::cout << pChild->getNodeName();
		if (pChild != 0)
		{
			pChild->isVisited() = true;
			WalkTree(pChild, dict, names);
		}
		if(pChild->getNodetype() == "TextNode")
		{
			std::string key = pParent->getNodeName();
			if (!std::isalpha(pChild->getNodeName()[1]))
			{
				double value = atof(pChild->getNodeName().c_str());
				dict.insert(std::pair<std::string, double>(key, value));
			}
			else
			{
				std::string value = pChild->getNodeName();
				value.erase(0, 1);
				names.push_back(value);
			}
		}

	}
}


//-----------------------<Walks the tree in Depth First Order>--------------------------------------

void Tree::WalkTree(Node * pParent)
{
	nodes.push_back(pParent);
	Node * pChild;
	for (int i = 0; i < (pParent->CountChildren()); i++)
	{
		pChild = pParent->NextUnmarkedChild();
		if (pChild != 0)
		{
			pChild->isVisited() = true;
			WalkTree(pChild);
		}

	}
}

//------------------------<returns a vector of nodes for elements with given tag name>---------------

vector<Node *> Tree::GetElementByTagName(std::string Element)
{

	ClearMarks();
	ClearNodes();
	Elements.clear();
	WalkTree(this->GetRoot());
	vector<Node *>::iterator itr = nodes.begin();
	int i = 0;
	while (itr != nodes.end())
	{
		if (nodes[i]->getNodeName() == Element && nodes[i]->getNodetype() == "Element")
			Elements.push_back(nodes[i]);
		itr++;                 // itr is used to iterate as using i will generate warning
		i++;                   // i is used to access element
	}
	if (Elements.size() == 0)
		cout << "No Element with the specified tag name can be found in the tree" << endl;
	return this->Elements;
}

//-------------------<Removes All Children for the given parent>---------------------------------- 

void Tree::RemoveChild(Node *pParent)
{
	while (pParent->CountChildren() != 0)
	{
		delete pParent->GetChild(0);
		pParent->RemoveChild(0);
	}
}

//--------------------<Display Complete tree starting from parent, uses Node's DisplayNode() >------------------------------------------------------

void Tree::DisplayTree(Node * pParent)
{
	ClearMarks();
	ClearNodes();
	WalkTree(pParent);
	vector<Node *>::iterator itr = nodes.begin();
	int i = 0;
	while (itr != nodes.end())
	{
		if (nodes[i]->getNodetype() == "Element")   // comment this to display FULL TREE including document, comments as DFS traversal
			nodes[i]->DisplayNode();
		i++;
		itr++;
	}
	ClearMarks();
}

//--------<Clear marks from every node, in the tree, as marking scheme is used for traversal>-----------------

void Tree::ClearMarks()
{
	vector<Node *>::iterator itr = nodes.begin();
	int i = 0;
	while (itr != nodes.end())
	{
		nodes[i]->isVisited() = false;
		itr++;
		i++;
	}
}

//--------<Clear the nodes, private member of tree>-----------------------------------------
void Tree::ClearNodes()
{
	nodes.clear();
}

//-------------------------<Sets the root of the tree>---------------------------------------

void Tree::setRoot(Node * root)
{
	this->root = root;
}

//-------------------------<returns the root of a tree>-------------------------------------

Node * Tree::GetRoot()
{
	if (this->root != NULL)
		return this->root;
	else
	{
		cout << "Root is set to NULL" << endl;
		return 0;
	}
}

//-------------------------<removes the element with the specified tag name--------------------
void Tree::RemoveElement(string TagName)
{
	Tree::GetElementByTagName(TagName);
	vector<Node *>::iterator itr = Elements.end();
	while (itr != Elements.begin())
	{
		itr--;
		if ((*itr) != NULL)
			Tree::Remove(*itr);
	}
	Elements.clear();
}

//--------<Removes the node, from the heap using the Node destructor, uses RemoveChild()>----------------

void Tree::Remove(Node* pChild)
{
	Tree::ClearMarks();
	Tree::ClearNodes();
	Tree::WalkTree(this->GetRoot());
	vector<Node *>::iterator itr = nodes.begin();
	int i = 0;
	while (itr != nodes.end())
	{
		for (int j = 0; j<nodes[i]->CountChildren(); j++)
		{
			if (nodes[i]->GetChild(j) == pChild)
			{
				delete nodes[i]->GetChild(j);
				nodes[i]->RemoveChild(j);
				break;
			}
		}
		i++;
		itr++;
	}
}

//--------------------------<returns the node ptr to the element with specified id>------------------

Node * Tree::GetElementById(std::string value)
{
	value = "\"" + value + "\"";
	Tree::WalkTree(this->GetRoot());
	vector<Node *>::iterator itr = nodes.begin();
	int i = 0;
	while (itr != nodes.end())
	{
		for (int j = 0; j<nodes[i]->CountAttributes(); j++)
		{
			if (((nodes[i]->GetAttributes(j)).first == "id") || ((nodes[i]->GetAttributes(j)).first == "ID") || ((nodes[i]->GetAttributes(j)).first == "Id"))
			{
				if ((nodes[i]->GetAttributes(j)).second == value)
				{
					this->NodeWithId = nodes[i];
					ClearMarks();
					ClearNodes();
					return NodeWithId;
				}
			}
		}
		i++;
		itr++;
	}
	return 0;
}

//-----------------------------<Adds the child to the parent Node ,and sets nodetype as Element>------

void Tree::AddChild(std::string TagName, Node *parent)
{
	try {
		if (parent != 0)
		{
			Node *NewChild = new Node("Element", TagName);
			parent->AddChild(NewChild);
		}
		else
			cout << "Unable to process the null parent node" << endl;
	}
	catch (std::exception e)
	{
		cout << e.what() << endl;
	}
}

// Test stub for Tree Class

#ifdef TEST_TREE

void main()
{
	cout << "=========================" << endl;
	cout << "    Testing Tree Class   " << endl << "=========================" << endl << endl;
	Tree xmltree;
	Node* root = new Node;
	root->setNodetype("Element");
	root->AddAttributes("Lecture", "CSE687");
	root->AddTextBody("This is a test node");
	Node * child = new Node;
	child->setNodetype("Element");
	child->AddAttributes("Lecture", "CSE681");
	child->setNodeName("LectureNote");
	child->AddTextBody("This is a child test node");
	Node * child1 = new Node;
	child1->setNodeName("LectureNotes");
	child1->AddTextBody("This is the body of a Child1 node");
	child1->setNodetype("TextBody");
	cout << std::string(1, '=');
	Node * GrandChild1 = new Node;
	GrandChild1->setNodetype("TextBody");
	GrandChild1->AddTextBody("This is a grand child of child node");
	child->AddChild(GrandChild1);
	Node *GrandChild11 = new Node;
	GrandChild11->setNodetype("TextBody");
	GrandChild11->AddTextBody("This is a grand child of child1 Node");
	child1->AddChild(GrandChild11);
	root->AddChild(child);
	root->AddChild(child1);
	xmltree.setRoot(root);
	xmltree.DisplayTree(xmltree.GetRoot());
	xmltree.RemoveElement("LectureNotes");
	xmltree.DisplayTree(xmltree.GetRoot());
	xmltree.RemoveElement("LectureNote");
	xmltree.DisplayTree(xmltree.GetRoot());
}

#endif