#ifndef XMLDOCUMENT_H
#define XMLDOCUMENT_H

/////////////////////////////////////////////////////////////////////////////////////////////////
// XMLDocument.h  -   This module is used to return a xml file/string in a tree form contained// 
//                    in memory                                                               
//                    to demonstrate the project requirement.
// version 1.2                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:        Builds an XML tree from a string or a file and demonstrates req.       //                        //
// Author:              Sanyam Chaudhary                                                      //
//                                                                                             //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////

/*
    Module Operations
   ===================
   This module defines a XMLDocument class, useful in building a tree from the parsed XML tokens.

   Public Interface
  ====================
  XMLDocument doc;
  Node *N =doc.Load(string filename);
  // other two functions CreateNode(Node * N, XmlParts parts) and ShowComment() is used by Load()

  Build details
  =============
  devenv XMLDocument.sln /rebuild
  
  Required Files
  ==============
  XMLDocument.h and all other files required by XMLDocument.h
      
  Maintenance History
  ====================
 ver 1.2 : 7th Feb. 2009
  - Reduced Complexities in Create Node function, after analysis from ANAL.EXE provided by Dr. Fawcett.
 ver 1.1 : 6th Feb. 2009
  - Added a ShowComment() function that removes spaces from comments and preprocessing instruction
    that enables Internet explorer to correctly open XML file.
 ver 1.0 : 1st Feb 2009
  -first release


*/

#include "xmlElementParts.h"
#include "Tree.h"
#include <stack>
#include "FileSystem.h"
class XMLDocument
{
public:
	XMLDocument(void);
	~XMLDocument(void);
	Node * Load(std::string);
	void CreateNode(Node *, XmlParts);
	std::string ShowComment(XmlParts &parts);
	Node * ParseString(std::string XMLstring);

private:
	stack<Node*> ScopeStack;
	Node * Document;
	
};

#endif
