#ifndef TREE_H
#define TREE_H

/////////////////////////////////////////////////////////////////////////////////////////////////
// Tree.h  - Uses Node data type to create a tree.                                             //
// version 1.1                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:         Provides functionality for traversing, building and modifying a tree   //                        //
// Author:              Sanyam Chaudhary                                                      //
//                                                                                             //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////

/*
    Module Operations
   ===================
   This module defines a Tree class, useful in providing creating Node data type for building a tree.

   Public Interface
  ====================
  Tree t;
  Node *N =t.GetRoot();
  t.Walktree(Node *N);
  t.DisplayTree(Node *N);
  vector<Node *> Nodes=t.GetElementByTagName(string TagName);
  Node *N = t.GetElementById(string IdValue);
  t.Remove(Node *N);
  t.RemoveChild(int index);
  t.ClearMarks();
  t.ClearNodes();
  t.RemoveElement(string TagName);
  t.AddChild(string TagName, Node * parent);
  t.setRoot(Node *N);
    
  Maintenance History
  ====================
 ver 1.1 : 2nd Feb. 2009
 - Added various member functions, which helped in performing operations on Tree data structure.
 ver 1.0 : 31st Jan 2009
  -first release


*/

#include "Node.h"
#include <map>

class Tree{
private:
	Node * root;
	std::vector<Node *> nodes;
	vector<Node *> Elements;
	Node * NodeWithId;
public:
	void WalkTree(Node *);
	void WalkTree(Node *, std::map<std::string, std::string>&);
	void WalkTree(Node *, std::map<std::string, double>&);
	void WalkTree(Node *, std::map<std::string, double>&, std::vector<std::string> &names);
	void WalkTree(Node * pParent, std::vector<std::vector<std::map<std::string, double> > > &vofomaps, std::vector<std::string> &names);
	void ClearNodes();
	Node * GetRoot();
	void Remove(Node*);
	void DisplayTree(Node *);
	void ClearMarks();
	void setRoot(Node *);
	vector<Node *> GetElementByTagName(string );
	void RemoveElement(string );
	void RemoveChild(Node * pChild);
	Node * GetElementById(string value);
	void AddChild(string TagName, Node *parent);
	
};

#endif
