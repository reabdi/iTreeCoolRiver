#ifndef NODE_H
#define NODE_H
/////////////////////////////////////////////////////////////////////////////////////////////////
// Node.h  - Create a Node data type, to be used by trees                                      //
// version 1.4                                                                                 //
//                                                                                             //
// Language:            Visual C++ 2008                                                        //
// Platform:            HP Pavilion dv2000                                                     //
// Application:         Basic Data Structure for building a XML Tree                           //
// Author:              Sanyam Chaudhary , with ideas from Help_Node code                      //
//                      provided by Dr.Fawcett                                                 //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////

/*
    Module Operations
   ===================
   This module defines a Node class, useful in creating Node data type for building a tree.

   Public Interface
  ====================
  Node N;
  Node N(string Nodetype, string NodeName);
  N.SetNodeName(string NodeName);
  string NodeName = N.GetNodeName();
  N.SetNodeType(string NodeType);
  string NodeType = N.GetNodeType();
  Node * child = N.GetChild(int indexChild);
  pair<string,string> attrib = N.GetAttribute(int indexAttrib);
  int number = N.CountChildren();
  N.AddAttributes(string Name, string Value);
  N.RemoveChild(int indexChild);
  N.DisplayNode();
  N.ShowAttributes();
  int attribCount= N.CountAttributes();
  Node * child= N.NextUnmarkedChild();
  
  Maintenance History
  ====================
 ver 1.4  : 7th February
  -  Changed attribute data type from map to a vector, as former was creating problems in accessing.
 ver 1.3 : 5th Feburary,
  - Added Destructor so as to remove the nodes recursivly, with help from Dr. Fawcett's friday help session.
 ver 1.2: 25th February
  - Added various member functions, which helped in accessing private members of Node data type.
 ver 1.1 : 22nd Jan 2009
  - Added Marking Scheme, visited boolean for traversing a tree, with help from Dr. Fawcett's Help_Node
 ver 1.0 : 16th Jan 2009
  -first release


*/

#include<iostream>
#include<vector>
#include<string>
using namespace std;
class Node{
private:
	bool visited;
	string Nodetype;
	string NodeName;//Applies in case, the Node type is element
	vector<Node *> Children;
	vector<pair<string,string>> Attributes;
public:
     Node();
	Node(string NodeType,string NodeName);
	~Node();
	bool& isVisited();  //this will enable isVisited to behave like a property.
	void setNodeName(string);
	string getNodeName();
	void setNodetype(string);
	string getNodetype();
	Node * NextUnmarkedChild();
	Node * GetChild(int);
	bool RemoveChild(int);
	void AddChild(Node *);
	int CountChildren();		
	void AddAttributes(string,string);
	void ShowAttributes();
	void AddTextBody(string Body);
	void DisplayNode();
	pair<string,string> GetAttributes(int index);
	int CountAttributes();
	Node* getChildByTagName(string tagName);
};

#endif 

