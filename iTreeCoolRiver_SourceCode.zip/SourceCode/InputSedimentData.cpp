#include "InputSedimentData.h"
#include <sstream>
Sediment::Sediment(Params* pm) {

	double distanceTotal = pm->get_total_dist();
	std::string CurrDir = pm->get_InputDir();

	totalBedCount = depthOfMeas.size();

	std::ifstream readBedData(CurrDir + "\\BedData.dat");
	if (!readBedData)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot find BedData.dat file needed to run simulation.\n";
		logfile.close();
		std::cout << "BedData.dat could not be opened!" << std::endl;
		//fileParseSuccess = false;
		return;
	}


	std::string temp;
	int tempDummy = -1.0;
	double tempDistance = -99999;
	double tempDepthOfMeas = -99999;
	double tempT0_temperature = -99999;
	double tempTEnd_temperature = -99999;
	double tempConductivity = -99999;
	double tempParticleSize = -99999;
	double tempEmbeddedness = -99999;

	std::string tempSedType = "";

	std::string startline;

	// getting the header line and the blank line out of the way
	// getline(readBedData, temp);
	// getline(readWeather, temp);				// this second getline handles the extra spaces between the header and the start of data,
	// right now it has been commented out because the GUI isn't producing files with the extra space

	// reading in a CSV
	while (readBedData.good())
	{
		getline(readBedData, temp, ',');
		std::istringstream ss(temp);
		ss >> tempDummy;

		if (tempDummy <= distanceTotal)
		{
			number.push_back(tempDummy);
			getline(readBedData, temp, ',');
			std::istringstream temp1(temp);
			temp1 >> tempDistance;
			distance.push_back(tempDistance);

			getline(readBedData, temp, ',');
			std::istringstream temp2(temp);
			temp2 >> tempDepthOfMeas;
			depthOfMeas.push_back(tempDepthOfMeas);

			getline(readBedData, temp, ',');
			std::istringstream temp4(temp);
			temp4 >> tempTEnd_temperature;
			tEnd_temperature.push_back(tempTEnd_temperature);

			getline(readBedData, temp, ',');
			std::istringstream temp5(temp);
			temp5 >> tempSedType;
			sedType.push_back(tempSedType);

			getline(readBedData, temp, ',');
			std::istringstream temp6(temp);
			temp6 >> tempConductivity;
			conductivity.push_back(tempConductivity);

			getline(readBedData, temp, ',');
			std::istringstream temp7(temp);
			temp7 >> tempParticleSize;
			particleSize.push_back(tempParticleSize);

			getline(readBedData, temp, '\n');
			std::istringstream temp8(temp);
			temp8 >> tempEmbeddedness;
			embeddedness.push_back(tempEmbeddedness);
		}
		else
		{
			getline(readBedData, temp, '\n');
		}
	}
	totalBedCount = depthOfMeas.size();
	readBedData.close();


}