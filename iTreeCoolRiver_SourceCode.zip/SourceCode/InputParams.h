#pragma once
//////////////////////////////////////////////////////////////////////////////////////
//																		            //
// InputParams.h - Parses "param".dat and stores input data                       //																		   
// ver 1.0                                                                          //
// Language:    Visual C++ 2010                                                     //
// Platform:    									                                //
// Application: iTree-Temperature, Winter 2013                                      //
// Programmer: Yang Yang, yyang3117@gmail.com				                        //																	   	
//////////////////////////////////////////////////////////////////////////////////////
/*


  Module Operations:
  ==================
  Input iTreeTempConfig.xml


  Public Interface:
  =================
  Params(std::string xmlfile,WriteLogFile &wl);
  please see the test stub in the cpp file for the use of the functions

  Build Process:
  ==============
  Required files
  - InputParams.cpp, WriteLogFile.h
  Build commands
  - devenv PASATH.sln

  Maintenance History:
  ====================

  */

#include <string>
#include "XMLReader\XMLDocument.h"

//#include "InputSolarData.h"
//#include "InputRefweather.h"
//#include "InputWeather.h"
//#include "InputSpatialData.h"

class Params
{
public:

	//constructor
	Params(std::string XmlFilename);


	std::string get_InputDir();
	std::string get_OutputDir();



	// Time Control          %set siimullation time frame  
	int get_starttime();             //simulaltion start time yyyymmdd
	int get_endtime();           //simulation end time yyyymmdd
	int get_interval_hours();          //simulation time step in hour, such as 2




	void EatDoubleQuote(std::string& Dir);

	// Added by Reza Abdi
	double get_tar_lat();
	double get_tar_long();
	int get_tarRow();
	int get_tarCol();
	int get_standardMeridian();						// To read in the Standard Meridian
	double get_total_dist();				// total distance of the stream (m) May 17
	double get_caculation_method();		 // for 1: Solution Method=Crank-Nicolson and for 2: Solution Method=Runge-Kutta and for 3: Solution Method=Explicit finite difference 
	double get_depth_bed();				// depth of measurment of bed data
	int get_total_time();
	int get_sens_method();		// which methodology 1=wind speed based, 2=Bowen ratio base
	double get_can_dens();				// in "Spatial_Domain" section (0 to 1)
	double get_roughness();
	double get_LAI();
	int get_starting_hour();    // in "Temporal_Domain" section
	int get_SW_method();		// in "Temporal_Domain" section
	double get_initial_temp();		// in "Temporal_Domain" section
	int get_unsteady_dx();
	double get_unsteady_dt();
	 
private:
	Tree t;
	XMLDocument doc;
	Node *root;


	bool fileParseSuccess;

	std::vector<Node*> Inputs;
	std::vector<Node*> Outputs;
	std::vector<Node*> Temporal_Domain;
	// Added by Reza Abdi to read in a set of required inputs (Non. & Dec. 2016)
	std::vector<Node*> Shading_inputs; 
	std::vector<Node*> Unsteady_inputs;


};