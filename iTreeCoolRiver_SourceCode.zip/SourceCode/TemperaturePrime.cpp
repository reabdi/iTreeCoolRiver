/////////////////////////////////////////////////////////////////////////////////////////////////////// 
//  TemperaturePrime.cpp -  performs temperature modeling analysis			 						 //                                                                                          //
// Language:    Visual C++ 2013                                                                     //
// Application: HydroPrime/iHydro Version6				                                            //
//  Author:       Yang Yang,  SUNY-ESF & USDA FS, yyang31@syr.edu									//
//				  Pallavi Iyengar, piyengar@syr.edu													//
///////////////////////////////////////////////////////////////////////////////////////////////////////

#include "TemperaturePrime.h"
#include "SolarCalculation.h"		// Added by Vamsi for Reza's work (Jan.17)
#include "StreamTemperature.h"		// Added by Reza Abdi (Jan. 17)



// added by Reza (Jun. 17)
void Temperature::twoDwriter(int sizeX, int sizeY, vector<vector<double>>&vector, string title, string OutputDir) {


	title = OutputDir + "\\2D_" + title + ".csv";
	ofstream outfileC(title);

	if (!outfileC.good())
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Cannot write the output file: " + title;
		logfile << "\n";
		logfile.close();
		std::cout << "Cannot write the output file" << std::endl;
		return;
	}
	vector.resize(sizeX);
	for (int i = 0; i < sizeX; i++)
	{
		vector[i].resize(sizeY);
		for (int j = 0; j < sizeY; j++)
		{
			outfileC << vector[i][j] << ",";
		}
		outfileC << '\n';
	}
	std::ofstream logfile2("log.txt", ios::app);
	logfile2 << "Finished Writing Output file: " + title;
	logfile2 << "\n";
	logfile2.close();

}


void Temperature::run() //for each process in vector call route operation
{
	std::cout << std::endl << std::endl;

	std::vector<double> solarAzimuth;
	std::vector<double> solarAltitude;

	SolarCalculation* sc = new SolarCalculation(inp);			// Added by Vamsi for Reza's work (Jan.17)
	int timeSteps = inp->getWeat()->gettotalts();
	
	//check that SolarRadiation.dat & Weather.dat have enough rows for totTime param in config
	if (inp->getWeat()->getTS()-1 != timeSteps)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "Weather.dat data entries should equal totTime param in config";
		logfile << "\n";
		logfile.close();
		return;
	}
	if (inp->getS()->gettotalts()-2 != timeSteps)
	{
		std::ofstream logfile("log.txt", ios::app);
		logfile << "SolarRadiation.dat data entries/rows should be equal totTime param in config";
		logfile << "\n";
		logfile.close();
		return;
	}


	for (int ts = 0; ts < timeSteps; ++ts)
	{
		sc->SolarHour(ts);
		solarAltitude.push_back(sc->getSolarAltitude());
		solarAzimuth.push_back(sc->getSolarAzimuth());
	}

	StreamTemperature *st = new StreamTemperature(inp, sc);		// Added by Reza Abdi (Jan. 17)
	st->avgTemperature();



	//Params* pm = new Params();
	int TotalTimeMod = inp->pm->get_total_time();
	int TotalDistMod = inp->pm->get_total_dist();
	int dx_Uns = inp->pm->get_unsteady_dx();
	int TotalDist_Uns = (TotalDistMod / dx_Uns) + 1;

	//std::vector<vector<double>> modeledT_x0(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> skyViewFactorE(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> skyViewFactorW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> atmLW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> landCoverLW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> upToAirLW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> LW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> latent(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> sensible(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> sediment(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	thermalExchange(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> SW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> dirSW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> diffSW(TotalDistMod, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> t_minBased1(TotalDistMod, std::vector<double>(TotalTimeMod*60));
	
	int TotalTimeUns = TotalTimeMod * 60;
	//std::vector<vector<double>> Flux_Total_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_Conduction_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_Evaporation_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_Convection_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> FLux_AtmLW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_LCLW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_BackLW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_LW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_DirSW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_DiffSW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Flux_SW_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> T_Uns_copy(TotalDistMod, std::vector<double>(TotalTimeUns));
	//std::vector<vector<double>> Depth_Uns_copy(TotalDistMod, std::vector<double>(TotalTimeUns));

	std::vector<vector<double>> temp_Flux_Total(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>> temp_Flux_Conduction(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_Evaporation(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_Convection(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_FLux_AtmLW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_LCLW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_BackLW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_LW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_DirSW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_DiffSW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_Flux_SW(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_T_Uns(TotalDist_Uns, std::vector<double>(TotalTimeMod));
	//std::vector<vector<double>>	temp_depth_Uns(TotalDist_Uns, std::vector<double>(TotalTimeMod));

	//std::vector<double> temp_Hyporheic_Exchange(TotalDist_Uns);
	//std::vector<double> temp_Q_GW(TotalDist_Uns);


	// For Steady State
	//modeledT_x0 = st->getModT();
	//dirSW = st->getSWDir_2D();
	//diffSW = st->getSWDiff_2D();
	//atmLW = st->getAtmLW();
	//landCoverLW = st->getLcLW();
	//upToAirLW = st->getBackLW();
	//LW = st->getLW();
	//latent = st->getLatent();
	//sensible = st->getSensible();
	//sediment = st->getBed();
	//thermalExchange = st->getHeatFlux();
	//SW = st->getSW();
	//t_minBased1 = st->getT_MinBased();

	// For Unsteady state
	//Flux_Total_copy = st->get_TotalFlux();
	//Flux_Conduction_copy = st->get_Conduction();
	//Flux_Evaporation_copy = st->get_Evaporation();
	//Flux_Convection_copy = st->get_Convection();
	//FLux_AtmLW_copy = st->get_AtmLW();
	//Flux_LCLW_copy = st->get_LCLW();
	//Flux_BackLW_copy = st->get_BackLW();
	//Flux_LW_copy = st->get_Flux_LW();
	//Flux_DirSW_copy = st->get_Flux_DirSW();
	//Flux_DiffSW_copy = st->get_Flux_DiffSW();
	//Flux_SW_copy = st->get_Flux_SW();
	//T_Uns_copy = st->get_T_Uns();
	//Depth_Uns_copy = st->get_depth_Uns();

	//temp_Flux_Total = st->get_hour_TotalFlux();
	//temp_Flux_Conduction = st->get_hour_Conduction();
	//temp_Flux_Evaporation = st->get_hour_Evaporation();
	//temp_Flux_Convection = st->get_hour_Convection();
	//temp_FLux_AtmLW = st->get_hour_AtmLW();
	//temp_Flux_LCLW = st->get_hour_LCLW();
	//temp_Flux_BackLW = st->get_hour_BackLW();
	//temp_Flux_LW = st->get_hour_Flux_LW();
	//temp_Flux_DirSW = st->get_hour_Flux_DirSW();
	//temp_Flux_DiffSW = st->get_hour_Flux_DiffSW();
	//temp_Flux_SW = st->get_hour_Flux_SW();
	//temp_T_Uns = st->get_hour_T_Uns();
	//temp_depth_Uns = st->get_hour_depth_Uns();

	//temp_Hyporheic_Exchange = st->getHypEx();
	//temp_Q_GW = st->getQ_GW();

	//writeSolarValues(solarAltitude, solarAzimuth);
	int calcMethod = inp->pm->get_caculation_method();
	std::string outputDir = inp->pm->get_OutputDir();
	
	switch (calcMethod)
	{
	case 1:
		// Writing the results for the steady state condition
		twoDwriter(TotalDistMod, TotalTimeMod, st->T, "Temperature", outputDir);
		/*twoDwriter(TotalDistMod, TotalTimeMod, dirSW, "DirSW");
		twoDwriter(TotalDistMod, TotalTimeMod, diffSW, "DiffSW");
		twoDwriter(TotalDistMod, TotalTimeMod, atmLW, "AtmLW");
		twoDwriter(TotalDistMod, TotalTimeMod, landCoverLW, "LcLW");
		twoDwriter(TotalDistMod, TotalTimeMod, upToAirLW, "UpToAirLW");
		twoDwriter(TotalDistMod, TotalTimeMod, LW, "TotalLW");
		twoDwriter(TotalDistMod, TotalTimeMod, latent, "Latent");
		twoDwriter(TotalDistMod, TotalTimeMod, sensible, "Sensible");*/
		twoDwriter(TotalDistMod, TotalTimeMod, st->heat_flux_2D, "EnergyFlux", outputDir);
		/*twoDwriter(TotalDistMod, TotalTimeMod, SW, "TotalSW");
		twoDwriter(TotalDistMod, TotalTimeMod, sediment, "Sediment");
		twoDwriter(TotalDistMod, (TotalTimeMod * 60), t_minBased1, "minBasedT");*/
		
		break;
	case 3:
		
		break;
	case 2:
		// Writing the unsteady state vectors.
		twoDwriter(TotalDistMod, TotalTimeUns, st->Flux_Total, "Minutely_TotalFlux", outputDir);
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_Conduction_copy, "Minutely_Conduction");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_Evaporation_copy, "Minutely_Evaporation");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_Convection_copy, "Minutely_Convection");
		//twoDwriter(TotalDistMod, TotalTimeUns, FLux_AtmLW_copy, "Minutely_AtmLW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_LCLW_copy, "Minutely_LCLW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_BackLW_copy, "Minutely_BackLW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_LW_copy, "Minutely_LW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_DirSW_copy, "Minutely_DirSW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_DiffSW_copy, "Minutely_DiffSW");
		//twoDwriter(TotalDistMod, TotalTimeUns, Flux_SW_copy, "Minutely_SW");
		twoDwriter(TotalDistMod, TotalTimeUns, st->T_Uns, "Minutely_Temperature", outputDir);
		//twoDwriter(TotalDistMod, TotalTimeUns, Depth_Uns_copy, "Minutely_Depth");
		
		twoDwriter(TotalDist_Uns, TotalTimeMod, st->hour_Flux_Total, "Hourly_TotalFlux", outputDir);
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_Conduction, "Hourly_Conduction");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_Evaporation, "Hourly_Evaporation");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_Convection, "Hourly_Convection");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_FLux_AtmLW, "Hourly_AtmLW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_LCLW, "Hourly_LCLW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_BackLW, "Hourly_BackLW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_LW, "Hourly_LW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_DirSW, "Hourly_DirSW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_DiffSW, "Hourly_DiffSW");
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_Flux_SW, "Hourly_SW");
		twoDwriter(TotalDist_Uns, TotalTimeMod, st->hour_T_Uns, "Hourly_Temperature", outputDir);
		//twoDwriter(TotalDist_Uns, TotalTimeMod, temp_depth_Uns, "Hourly_Depth");

		//writeSolarValues(temp_Hyporheic_Exchange, temp_Q_GW);

		break;

	default:
		std::ofstream logfile3("log.txt", ios::app);
		logfile3 << "Wrong modeling methodology code! Check the methodology code and try again.";
		logfile3 << "\n";
		logfile3.close();
		cout << "Wrong modeling methodology code! Check the methodology code and try again." << endl;
		break;
	}
	
	delete sc;
	std::ofstream logfile4("log.txt", ios::app);
	logfile4 << "End of Simulation...";
	logfile4 << "\n";
	logfile4.close();
	std::cout << "End of Simulation..." << std::endl;
}


